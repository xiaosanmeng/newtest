mmDefineModule(function(pkg) {
	'use strict';
	var kCGBackCanvasSize = 512;

	function ColorGenerator(currentDocument) {
		this.currentDocument = currentDocument;
		this.backCanvas = null;
		this.backCanvasG = null;
		
		this.backCanvasImageData = null;
		this.cssColorCache = null;
		
		this.colorStopList = null;

		this.prepareBackCanvas();
		this.initColorStopList();
		this.redrawBackCanvas();
	}

	ColorGenerator.prototype = {
		prepareBackCanvas: function() {
			this.backCanvas  = this.currentDocument.createElement('canvas');
			this.backCanvasG = this.backCanvas.getContext('2d');
			
			this.backCanvas.width  = kCGBackCanvasSize;
			this.backCanvas.height = 8;
			
			this.cssColorCache = new Array(kCGBackCanvasSize);
			
			this.backCanvas.style.border = '1px solid #000';
			this.updateImageData();
		},
		
		initColorStopList: function() {
			this.colorStopList = [null, null];

			this.colorStopList[0] = new MMColor(  0,0,255, 255);
			this.colorStopList[1] = new MMColor(255,0,  0, 255);
			
			this.colorStopList[0].stop = 0;
			this.colorStopList[1].stop = 1;
		},

		setNumOfColorStops: function(newCount) {
			var oldCount = this.colorStopList.length;
			if (oldCount === newCount) {
				return;
			}
			
			if (newCount < oldCount) {
				this.colorStopList.length = newCount;
			} else {
				var ex = newCount - oldCount;
				for (var i = 0;i < ex;++i) {
					var clr = new MMColor(0,0,255, 255);
					clr.stop = 1;
					this.colorStopList.push(clr);
				}
			}
		},

		setupHueGradient: function(reverseOrder) {
			var n = 12;
			this.setNumOfColorStops(n);
			for (var i = 0;i < n;++i) {
				var t = i / (n-1);
				this.colorStopList[i].stop = t;
			}
			
			ColorGenerator.writeHueGradient(this.colorStopList, 220, !!reverseOrder);
		},

		setTwoBlendColors: function(c1, c2) {
			var dirty = false;
			if (this.colorStopList.length !== 2) {
				dirty = true;
			} else {
				if (!this.colorStopList[0].equalsRGBA(c1)  ||
				    !this.colorStopList[1].equalsRGBA(c2) ) {
					dirty = true;
				}
			}
			
			this.setNumOfColorStops(2);
			this.colorStopList[0].copyFrom(c1);
			this.colorStopList[1].copyFrom(c2);
			
			this.colorStopList[0].stop = 0;
			this.colorStopList[1].stop = 1;
			
			return dirty;
		},

		redrawBackCanvas: function() {
			var g = this.backCanvasG;
			var w = this.backCanvas.width  | 0;
			var h = this.backCanvas.height | 0;
			
			g.clearRect(0, 0, w, h);
			var gradient = g.createLinearGradient(0,0, w,0);
			
			var stops = this.colorStopList;
			for (var i = 0;i < stops.length;++i) {
				var clr = stops[i];
				gradient.addColorStop(clr.stop, clr.toCSSRGBA());
			}
			
			g.save();
			g.fillStyle = gradient;
			g.fillRect(0, 0, w, h);
			g.restore();
			
			this.updateImageData();
		},

		updateImageData: function() {
			var w = this.backCanvas.width | 0;
			this.backCanvasImageData = this.backCanvasG.getImageData(0, 1, w, 1);
			var p = this.backCanvasImageData.data;
			
			for (var i = 0;i < w;++i) {
				var k = i << 2;
				this.cssColorCache[i] = 'rgba('+ p[k] +','+ p[k+1] +','+ p[k+2] +','+ (p[k+3] / 255.0) +')';
			}
		},

		pick: function(outColor, pos) {
			var w = this.backCanvas.width | 0;
			var x = pos * (w-1);
			if (x < 0) {x = 0;}
			else if (x >= w) {x = w-1;}


			var p = this.backCanvasImageData.data;
			var i = x << 2;
			
			outColor.r = p[i  ];
			outColor.g = p[i+1];
			outColor.b = p[i+2];
			outColor.a = p[i+3];
		},
		
		pickCSSColor: function(pos) {
			var n = this.cssColorCache.length;
			var i = Math.floor(pos * (n-1));

			if (i < 0) { i = 0; }
			else if (i >= n) { i = n-1; }
			
			return this.cssColorCache[i];
		}
	};

	ColorGenerator.writeHueGradient = function(outColorArray, hueMax, reverseOrder) {
		var n = outColorArray.length;
		var tmpC = [0,0,0];

		for (var i = 0;i < n;++i) {
			var index = reverseOrder ? ((n-1) - i) : i;
			var t = index / (n - 0.99);
			var hue = Math.floor(hueMax * (1-t));
			tmpC[0] = hue;
			tmpC[1] = 0.9;
			tmpC[2] = 0.8;

			hsvToRGB(tmpC);
			outColorArray[i].r = tmpC[0];
			outColorArray[i].g = tmpC[1];
			outColorArray[i].b = tmpC[2];
		}
	};

	pkg.ColorGenerator = ColorGenerator;
});