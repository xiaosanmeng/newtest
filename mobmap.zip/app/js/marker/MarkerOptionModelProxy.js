mmDefineModule(function(pkg) {
	'use strict';

	var kDefaultMarkerSize = 2;
	var kSmallMarkerSize   = 2;
	var kMidMarkerSize     = 6.5;
	var kLargeMarkerSize   = 12.5;

	function MarkerOptionModelProxy(markerGenerator, ownerLayer) {
		this.textureDirty = true;
		this.ownerLayer = ownerLayer;
		
		this.markerGenerator = markerGenerator;
		this.options = {
			showTail: false,
			tailDuration: 180,
			showSelectedOnly: false,
			boundAttribute: null,
			composition: MarkerOptionModelProxy.Composition_Normal,
			markerSizeMin: kDefaultMarkerSize,
			markerSizeMax: kDefaultMarkerSize,
			numOfMarkers: 4,
			indexScaling: 1,
			coloringScheme:   mobmap.MarkerColoringScheme.Hue,
			coloringReversed: false,
			blendColors: [
				new MMColor(  0,0,255, 255),
				new MMColor(  255,0,0, 255)
			],
			
			autoSizing: MarkerOptionModelProxy.Sizing.Default,
			perceptualScaling: true
		};

		this.updateGeneratorConfiguration();
	}

	MarkerOptionModelProxy.Sizing = {
		Default: 0,
		Mid:     1,
		Large:   2,
		ToLarge: 3,
		ToSmall: 4
	};

	MarkerOptionModelProxy.CHANGE_EVENT = 'marker-option-change-event';
	MarkerOptionModelProxy.GRADIENT_SET_CHANGE_EVENT = 'marker-gradient-set-change-event';

	MarkerOptionModelProxy.Composition_Normal = 0;
	MarkerOptionModelProxy.Composition_Add    = 1;
	
	MarkerOptionModelProxy.prototype = {
		getOwnerLayer: function() {
			return this.ownerLayer;
		},
		
		getMarkerGenerator: function() {
			return this.markerGenerator;
		},

		setTailEnabled: function(val) {
			if (this.options.showTail !== val) {
				this.options.showTail = val;
				this.fireChange(false);
			}
		},

		getTailEnabled: function() {
			return this.options.showTail;
		},

		getTailLength: function() {
			return 1;
		},
		
		getTailDuration: function() {
			return this.options.tailDuration;
		},
		
		setTailDuration: function(val) {
			if (this.options.tailDuration !== val) {
				this.options.tailDuration = val;
				this.fireChange(false);
			}
		},

		setShowSelectedOnly: function(val) {
			if (this.options.showSelectedOnly !== val) {
				this.options.showSelectedOnly = val;
				this.fireChange(false);
			}
		},
		
		getShowSelectedOnly: function() {
			return this.options.showSelectedOnly;
		},

		setMarkerAutoSizing: function(s) {
			if (this.options.autoSizing !== s) {
				this.options.autoSizing = s;

				this.markDirty();
				this.updateGeneratorConfiguration();

				this.fireChange(false);
			}
		},

		getMarkerAutoSizing: function() {
			return this.options.autoSizing;
		},
		
		setPerceptualScalingEnabled: function(enabled) {
			if (this.options.perceptualScaling !== enabled) {
				this.options.perceptualScaling = enabled;
				this.markDirty();
				this.updateGeneratorConfiguration();
				this.fireChange(false);
			}
		},
		
		getPerceptualScalingEnabled: function() {
			return this.options.perceptualScaling;
		},

		setAddCompositionEnabled: function(enabled) {
			var newVal = enabled ? MarkerOptionModelProxy.Composition_Add
			                     : MarkerOptionModelProxy.Composition_Normal ;

			if (this.options.composition !== newVal) {
				this.options.composition = newVal;

				this.markDirty();
				this.updateGeneratorConfiguration();

				this.fireChange(false);
			}
		},

		isAddCompositionEnabled: function() {
			return ( this.options.composition === MarkerOptionModelProxy.Composition_Add ) ;
		},



		setMarkserSizeMin: function(s) {
			if (isNumbersNear(s, this.options.markerSizeMin)) { return; }
			this.markDirty();

			this.options.markerSizeMin = s;
			this.updateGeneratorConfiguration();

			this.fireChange(false);
		},

		setMarkserSizeMax: function(s) {
			if (isNumbersNear(s, this.options.markerSizeMax)) { return; }
			this.markDirty();

			this.options.markerSizeMax = s;
			this.updateGeneratorConfiguration();

			this.fireChange(false);
		},

		setNumOfMarkers: function(n) {
			n = Math.floor(n);
			if (this.options.numOfMarkers === n) { return; }
			this.markDirty();

			this.options.numOfMarkers = n;
			this.updateGeneratorConfiguration();
			this.fireChange(true);
		},
		getNumOfMarkers: function() {
			return this.options.numOfMarkers;
		},

		setIndexScaling: function(n) {
			n = Math.floor(n);
			if (this.options.indexScaling === n) { return; }
			this.markDirty();

			this.options.indexScaling = n;
			this.updateGeneratorConfiguration();
			this.fireChange(true);
		},
		getIndexScaling: function() {
			return this.options.indexScaling;
		},

		setColoringScheme: function(s) {
			if (this.options.coloringScheme === s) { return; }
			this.markDirty();

			this.options.coloringScheme = s;
			this.updateGeneratorConfiguration();
			this.fireChange(true);
		},

		updateGeneratorConfiguration: function() {
			var mg = this.markerGenerator;
			
			if (this.options.coloringScheme === mobmap.MarkerColoringScheme.Hue) {
				mg.setColoringScheme(this.options.coloringScheme);
			} else {
				mg.setBlendColoringScheme(this.options.blendColors[0], this.options.blendColors[1]);
			}

			this.applyMarkerAutoSizing();

			mg.numOfMarkers      = this.options.numOfMarkers;
			mg.indexScaling      = this.options.indexScaling;
			mg.markerBodySizeMin = this.options.markerSizeMin;
			mg.markerBodySizeMax = this.options.markerSizeMax;
			mg.perceptualScaling = this.options.perceptualScaling;
			mg.coloringReversed  = this.options.coloringReversed;
			
			mg.shape = this.isAddCompositionEnabled() ? mobmap.MarkerGenerator.SHAPE_SPOT
			                                          : mobmap.MarkerGenerator.SHAPE_CIRCLE ;

			mg.updateCanvasSize();
		},

		applyMarkerAutoSizing: function() {
			var SZ = MarkerOptionModelProxy.Sizing;
			var o = this.options;

			switch( o.autoSizing ) {
			case SZ.Mid:
				o.markerSizeMin = kMidMarkerSize;
				o.markerSizeMax = kMidMarkerSize;
				break;

			case SZ.Large:
				o.markerSizeMin = kLargeMarkerSize;
				o.markerSizeMax = kLargeMarkerSize;
				break;

			case SZ.ToLarge:
				o.markerSizeMin = kSmallMarkerSize;
				o.markerSizeMax = kLargeMarkerSize;
				break;

			case SZ.ToSmall:
				o.markerSizeMin = kLargeMarkerSize;
				o.markerSizeMax = kSmallMarkerSize;
				break;

			default:
				o.markerSizeMin = kDefaultMarkerSize;
				o.markerSizeMax = kDefaultMarkerSize;
				break;
			}
		},

		setMarkerColorBoundAttribute: function(attrName) {
			this.options.boundAttribute = attrName;
			this.fireChange(true);
		},
		
		getMarkerColorBoundAttribute: function() {
			return this.options.boundAttribute;
		},

		fireChange: function(affects_coloring) {
			this.fire(MarkerOptionModelProxy.CHANGE_EVENT, [this, (!!affects_coloring)]);
		},
		fireGradientSetChange: function(affects_coloring) {
			this.fire(MarkerOptionModelProxy.GRADIENT_SET_CHANGE_EVENT, this);
		},


		// preset operation
		changeNumOfBlends: function(newNum) {
			//var oldNum 
		},

		loadMarkerSetDirect: function(src) {
			this.options.coloringScheme = src.scheme;
			this.options.coloringReversed = !!(src.reversed);
			if (src.fromColor) {
				this.options.blendColors[0].copyFrom( src.fromColor );
				this.options.blendColors[1].copyFrom( src.toColor );
			}

			this.markDirty();
			this.updateGeneratorConfiguration();

			this.fireChange(true);
		},

		loadMarkerSetPreset: function(name) {
			var src = this.findPreset(name);
			if (!src) { return; }

			this.loadMarkerSetDirect(src);
		},

		reverseMarkerSetPresetOrder: function(name) {
			var src = this.findPreset(name);
			if (src) {
				src.reversed = !(src.reversed);
			}
		},
		
		setMarkerSetPresetReversed: function(name, bReversed) {
			var src = this.findPreset(name);
			if (src && src.reversed !== bReversed) {
				this.reverseMarkerSetPresetOrder(name);
			}
		},

		// Dirty flag operation
		markDirty: function() {
			this.textureDirty = true;
		},

		getTextureDirty: function(autoReset) {
			var oldValue = this.textureDirty;
			if (autoReset) {
				this.textureDirty = false;
			}

			return oldValue;
		},

		resetTextureDirty: function() {
			this.textureDirty = false;
		},
		
		getCustomColoringList: function() {
			return mobmap.getMarkerSetPresetCustomList();
		},
		
		findPreset: function(name) {
			var m = mobmap.MarkerSetPreset[name];
			if (!m) {
				var customs = this.getCustomColoringList();
				for (var i in customs) if (customs.hasOwnProperty(i)) {
					if (customs[i].id === name) {
						m = customs[i];
						break;
					}
				} 
			}
			
			return m;
		}
	};

	// Exported constants
	pkg.MarkerColoringScheme = {
		Hue: 0,
		Blend: 1
	};

	mobmap.installBaseMethods(  MarkerOptionModelProxy.prototype, mobmap.PseudoEventNodeBase  );
	pkg.MarkerOptionModelProxy = MarkerOptionModelProxy;
});