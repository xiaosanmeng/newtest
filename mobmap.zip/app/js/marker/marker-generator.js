mmDefineModule(function(pkg) {
	'use strict';

	var kMGMaxMarkerSize = 32;
	var kPerceptualConstant = 0.5716;

	function MarkerGenerator(currentDocument) {
		this.backCanvas   = null;
		this.backCanvasG  = null;

		this.textureCanvas  = null;

		this.numOfMarkers = 4;
		this.indexScaling = 1;
		this.markerBodySizeMin = 3.5;
		this.markerBodySizeMax = 3.5;
		this.markerOuterSize = kMGMaxMarkerSize;
		this.coloringScheme = mobmap.MarkerColoringScheme.Hue;
		this.coloringReversed = false;
		this.shape = MarkerGenerator.SHAPE_CIRCLE;
		this.perceptualScaling = false;

		this.renderer = MarkerGenerator.getSingletonStandardMarkerRenderer();

		this.currentDocument = currentDocument;
		this.colorGen = new mobmap.ColorGenerator(currentDocument);

		this.updateColorGenerator();
		this.prepareBackCanvas();
		this.updateCanvasSize();
	}

	MarkerGenerator.SHAPE_CIRCLE = 0;
	MarkerGenerator.SHAPE_SPOT   = 1;

	MarkerGenerator.prototype = {
		setColoringScheme: function(s) {
			if (this.coloringScheme === s) { return; }

			this.coloringScheme = s;
			this.updateColorGenerator();
		},

		setBlendColoringScheme: function(c1, c2) {
			var modeDirty   = (this.coloringScheme !== mobmap.MarkerColoringScheme.Blend);
			var colorsDirty = this.colorGen.setTwoBlendColors(c1, c2);

			if (modeDirty || colorsDirty) {
				this.coloringScheme = mobmap.MarkerColoringScheme.Blend;
				this.updateColorGenerator();
			}
		},

		getColorGenerator: function() {
			return this.colorGen;
		},

		pickColorByIndex: function(outColor, index) {
			var npos = index / (this.numOfMarkers-1);
			if (this.coloringReversed) {
				npos = 1.0 - npos;
			}
			
			return this.colorGen.pick(outColor, npos);
		},

		pickCSSColorByIndex: function(outColor, index) {
			var npos = index / (this.numOfMarkers-1);
			if (this.coloringReversed) {
				npos = 1.0 - npos;
			}
			
			return this.colorGen.pickCSSColor(npos);
		},

		updateColorGenerator: function() {
			var cs = this.coloringScheme;
			if (cs === mobmap.MarkerColoringScheme.Hue) {
				this.colorGen.setupHueGradient();
				this.colorGen.redrawBackCanvas();
			} else {
				this.colorGen.redrawBackCanvas();
			}
		},

		prepareBackCanvas: function() {
			this.backCanvas  = this.currentDocument.createElement('canvas');
			this.backCanvasG = this.backCanvas.getContext('2d');

			this.backCanvas.style.border = '1px solid #000';
			this.backCanvas.style.backgroundColor = '#a98';
		},

		setCanvasWidth: function(w) {
			this.backCanvas.width = w | 0;
		},

		setCanvasHeight: function(h) {
			this.backCanvas.height = h | 0;
		},
		
		updateCanvasSize: function() {
			var s = this.markerOuterSize;
			
			this.setCanvasWidth( s * this.numOfMarkers );
			this.setCanvasHeight( s * 2 );
		},

		clearBackCanvas: function() {
			var g = this.backCanvasG;
			g.clearRect(0, 0, this.backCanvas.width | 0, this.backCanvas.height | 0);
		},

		generate: function() {
			this.switchRenderer();
			
			this.clearBackCanvas();
			this.generateMarkerSequence(this.backCanvasG, 0,                    0, this.numOfMarkers, false);
			this.generateMarkerSequence(this.backCanvasG, 0, this.markerOuterSize, this.numOfMarkers, true);
		},
		
		switchRenderer: function() {
			if (this.shape === MarkerGenerator.SHAPE_CIRCLE) {
				this.renderer = MarkerGenerator.getSingletonStandardMarkerRenderer();
			} else {
				this.renderer = MarkerGenerator.getSingletonSpotMarkerRenderer();
			}
		},
		
		generateMarkerSequence: function(g, ox, oy, n, inactive) {
			var x = ox;
			for (var i = 0;i < n;++i) {
				if (this.renderer) {
					var npos = i / (n-1);
					this.colorGen.pick(this.renderer.baseColor, this.coloringReversed ? (1.0-npos) : npos);
					this.renderer.setSize( this.calcInterpolatedMarkerSize(npos) );

					g.save();
					g.translate(x, oy);
					this.renderer.render(g, inactive);
					g.restore();
				}

				x += this.markerOuterSize;
			}
		},

		calcInterpolatedMarkerSize: function(t) {
			var _t = 1.0 - t;
			if (isNumbersNear(this.markerBodySizeMin, this.markerBodySizeMax)) {
				return this.markerBodySizeMin;
			}
			
			if (this.perceptualScaling) {
				if (this.markerBodySizeMin > this.markerBodySizeMax) {
					t = 1.0 - t;
					_t = 1.0 - _t;
				}

				var rmin = Math.min(this.markerBodySizeMin, this.markerBodySizeMax);
				var rmax = Math.max(this.markerBodySizeMin, this.markerBodySizeMax);
				var Rbase = (rmin / rmax);
				var s = Rbase * _t + t;
				
				return rmax * Math.pow(s, kPerceptualConstant);
			} else {
				return this.markerBodySizeMin*_t + this.markerBodySizeMax*t;
			}
		},

		renderPreview: function(targetCanvas) {
			var g = targetCanvas.getContext('2d');
			g.clearRect(0, 0, targetCanvas.width, targetCanvas.height);
			
			var sz = this.markerOuterSize;
			var r = (targetCanvas.width-sz) / this.backCanvas.width;
			var n = this.numOfMarkers;
			
			var hMargin = Math.floor((targetCanvas.width - (n-1) * r*sz - sz) * 0.5);
			
			var skipMarker = (sz*r) < 18;
			var labelShiftY = Math.max(Math.max(1, this.markerBodySizeMax - 1), this.markerBodySizeMin - 1) | 0;
			
			var backgroundIsDark = (this.shape === MarkerGenerator.SHAPE_SPOT);
			
			var x, sx;
			for (var i = 0;i < n;++i) {
				x  = Math.floor(r * sz * i) + hMargin;
				sx = sz * i;
				
				g.drawImage(this.backCanvas, sx, 0, sz, sz, x, 0, sz, sz);
				
				if (!skipMarker || (i%5) == 0)
				this.drawMarkerPreviewLabel(g, x + (sz>>1), sz + labelShiftY, i * this.indexScaling, backgroundIsDark);
			}
		},

		renderLayerPreview: function(outCanvas, varyingMarker) {
			var w = outCanvas.width  | 0;
			var h = outCanvas.height | 0;
			var g = outCanvas.getContext('2d');
			g.save();
			if (this.shape === MarkerGenerator.SHAPE_SPOT) {
				g.globalCompositeOperation = 'lighter';
			}
			
			g.clearRect(0, 0, w, h);
			
			var n = 28;
			for (var i = 0;i < n;++i) {
				var t = i / (n-1);
				var cy = h*0.5 + Math.sin(t * Math.PI * 7.0 + 0.2) * h * -0.2 + Math.cos(t * Math.PI * 3.0) * h * -0.2;
				var cx = t * (w-32) + 16 + Math.sin(t * Math.PI * 13.0) * this.markerOuterSize;
				
				this.renderMarkerWithIndex(g, cx | 0, cy | 0, varyingMarker ? (i % this.numOfMarkers) : 0);
			}

			g.restore();
		},

		renderMarkerWithIndex: function(g, cx, cy, markerIndex) {
			if (markerIndex >= this.numOfMarkers) {
				markerIndex = this.numOfMarkers - 1;
			}

			var sx = markerIndex * this.markerOuterSize;
			var sy = 0 ; //* this.markerOuterSize;
			var w = this.markerOuterSize;
			var h = this.markerOuterSize;

			cx -= (w >> 1);
			cy -= (h >> 1);

			g.drawImage(this.backCanvas, sx, sy, w, h, cx, cy, w, h);
		},

		drawMarkerPreviewLabel: function(g, x, y, label, backgroundIsDark) {
			g.save();
			g.textAlign = 'center';
			g.fillStyle = backgroundIsDark ? '#fff' : '#000';
			g.fillText(label, x, y);
			g.restore();
		},
		
		// for GL

		ensureTextureCanvas: function() {
			if (!this.textureCanvas) {
				this.textureCanvas = this.currentDocument.createElement('canvas');
			}

			return this.textureCanvas;
		},
		
		updateTextureCanvas: function() {
			var tx = this.ensureTextureCanvas();
			var tsize = this.calcTextureSize( this.backCanvas ) | 0;
			
			tx.width = tsize;
			tx.height = this.markerOuterSize * 2;
			
			var g = tx.getContext('2d');
			g.clearRect(0, 0, tsize, tsize);
			g.drawImage(this.backCanvas, 0, 0);
			
			return this.textureCanvas;
		},
		
		calcTextureSize: function(sourceCanvas) {
			var w = sourceCanvas.width | 0;
			var e = Math.ceil(Math.LOG2E * Math.log(w));
			
			return Math.pow(2, e);
		}
	};

	// MARKER RENDERERS - - - - - - - - - - - -
	function initialize_markerRendererProperties(that) {
		that.cx = 15.5;
		that.cy = 15.5;
		that.size = 3.5;
		that.baseColor      = new MMColor(20,100,240, 255);
		that.highlightColor = new MMColor(100,180,255, 255);
	}


	function SpotMarkerRenderer() {
		initialize_markerRendererProperties(this);
		this.midColor = new MMColor(20,100,240, 96);
	}

	SpotMarkerRenderer.prototype = {
		// Required APIs
		setSize: function(s) {
			this.size = s;
		},

		render: function(g, disabledColor) {
			if (disabledColor) {
				this.baseColor.blendRGB(70, 70, 70, 0.9);
			}
			this.updateHighlightColor(disabledColor);

			g.save();
			this.setSphereGradient(g);

			g.beginPath();
			g.arc(this.cx, this.cy, this.size-1, 0, Math.PI * 2, false);
			g.fill();

			g.restore();

		},

		// internal
		updateHighlightColor: function(disabledColor) {
			this.highlightColor.copyFrom(this.baseColor);
			this.midColor.copyFrom(this.baseColor);

			this.highlightColor.a = 0;
			this.midColor.a = 96;
			
			this.midColor.addRGB(12, 12, 12);
			this.baseColor.addRGB(96, 96, 96);
		},

		setSphereGradient: function(g) {
			var gradient = g.createRadialGradient(
				this.cx, this.cy, 0,
				this.cx, this.cy, this.size);

			gradient.addColorStop(0   , this.baseColor.toCSSRGBA());
			gradient.addColorStop(0.125, this.midColor.toCSSRGBA());
			gradient.addColorStop(1   , this.highlightColor.toCSSRGBA());

			g.fillStyle = gradient;
		}
	};


	//  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


	function StandardMarkerRenderer() {
		initialize_markerRendererProperties(this);
	}
	
	StandardMarkerRenderer.prototype = {
		// Required APIs
		setSize: function(s) {
			this.size = s;
		},
		
		render: function(g, disabledColor) {
			if (disabledColor) {
				this.baseColor.blendRGB(70, 70, 70, 0.9);
			}
			this.updateHighlightColor(disabledColor);
			g.save();

			g.fillStyle = disabledColor ? '#444' : '#000';
			g.beginPath();
			g.arc(this.cx, this.cy, this.size , 0, Math.PI * 2, false);
			g.fill();

			this.setSphereGradient(g);
			g.beginPath();
			g.arc(this.cx, this.cy, this.size-1, 0, Math.PI * 2, false);
			g.fill();

			g.restore();
		},

		// internal
		updateHighlightColor: function(disabledColor) {
			this.highlightColor.copyFrom(this.baseColor);
			
			if (disabledColor) {
				this.highlightColor.addRGB(80, 80, 80);
			} else {
				this.highlightColor.addRGB(130, 130, 130);
			}
		},

		setSphereGradient: function(g) {
			var gradient = g.createRadialGradient(
				this.cx * 0.9, this.cy * 0.9, this.size * 0.25,
				this.cx, this.cy, this.size);

			gradient.addColorStop(1, this.baseColor.toCSSRGBA());
			gradient.addColorStop(0, this.highlightColor.toCSSRGBA());

			g.fillStyle = gradient;
		}
	};
	
	// Singleton objects [] [] [] [] [] [] [] [] [] [] [] [] [] [] []

	var sStdRenderer = null;
	var sSpotRenderer = null;
	MarkerGenerator.getSingletonStandardMarkerRenderer = function() {
		if (!sStdRenderer) {
			sStdRenderer = new StandardMarkerRenderer();
		}

		return sStdRenderer;
	};

	MarkerGenerator.getSingletonSpotMarkerRenderer = function() {
		if (!sSpotRenderer) {
			sSpotRenderer = new SpotMarkerRenderer();
		}

		return sSpotRenderer;
	};


	// export
	pkg.MarkerGenerator = MarkerGenerator;
});