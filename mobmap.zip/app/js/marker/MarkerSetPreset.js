mmDefineModule(function(pkg) {
	'use strict';
	
	var MarkerSetPreset = {
		'Hue': {
			priority: 0,
			title: 'Hue wheel',
			scheme: mobmap.MarkerColoringScheme.Hue,
			reversed: false,
			previewImage: null,
			id: null
		},

		// 'HueR': {
		// 	priority: 0,
		// 	title: 'Hue wheel(rev)',
		// 	scheme: mobmap.MarkerColoringScheme.Hue,
		// 	reversed: true,
		// 	previewImage: null,
		// 	id: null
		// },

		'WhiteTogGreen': {
			priority: 2,
			title: 'White to Green',
			scheme: mobmap.MarkerColoringScheme.Blend,
			fromColor: new MMColor(255, 255, 255),
			toColor:   new MMColor(0, 255, 0),
			previewImage: null,
			id: null
		},

		'WhiteToBlue': {
			priority: 2,
			title: 'White to Blue',
			scheme: mobmap.MarkerColoringScheme.Blend,
			fromColor: new MMColor(255, 255, 255),
			toColor:   new MMColor(0, 0, 255),
			previewImage: null,
			id: null
		},

		'WhiteToRed': {
			priority: 4,
			title: 'White to Red',
			scheme: mobmap.MarkerColoringScheme.Blend,
			fromColor: new MMColor(255, 255, 255),
			toColor:   new MMColor(255, 0, 0),
			previewImage: null,
			id: null
		},

		'GreenToBlack': {
			priority: 4,
			title: 'White to Black',
			scheme: mobmap.MarkerColoringScheme.Blend,
			fromColor: new MMColor(0, 255, 0),
			toColor:   new MMColor(30, 30, 30),
			previewImage: null,
			id: null
		}
	};
	
	// Custom gradients =====================================================
	var generateNewCustomGradientId = (function() {
		var nextIndex = 0;
		return function() {
			return 'user-defined-' + (++nextIndex);
		} ;
	})();

	var CustomPresetList = [ ];
	pkg.getMarkerSetPresetCustomList = function() { return CustomPresetList; }
	pkg.clearMarkerSetPresetCustomList = function() {
		CustomPresetList.length = 0;
	};
	pkg.addToMarkerSetPresetCustomList = function(gradientData) {
		gradientData.id = generateNewCustomGradientId();
		gradientData.title = gradientData.id; 

		CustomPresetList.push( gradientData );
	};
	
	pkg.saveMarkerSetPresetCustomList = function() {
		var j = JSON.stringify( CustomPresetList );
		try {
			localStorage.setItem('mm-custom-gradients', j);
		} catch(e) {
			console.log("WARNING: Failed to access localStorage (set)");
		}
	};

	pkg.loadMarkerSetPresetCustomList = function() {
		var s = null;
		try {
			s = localStorage.getItem('mm-custom-gradients');
		} catch(e) {
			console.log("WARNING: Failed to access localStorage (get)");
		}
		
		if (s && s.indexOf(']') >= 0) {
			var j = JSON.parse(s);
			var num = j.length;
			for (var i = 0;i < num;++i) {
				var loadedItem = j[i];
				var fC = loadedItem.fromColor;
				var tC = loadedItem.toColor;
				
				pkg.addToMarkerSetPresetCustomList({
					id: null,
					title: null,
					previewImage: null,
					priority: loadedItem.priority,
					scheme: loadedItem.scheme,
					fromColor: new MMColor(fC.r, fC.g, fC.b),
					toColor:   new MMColor(tC.r, tC.g, tC.b)
				});
			}
		}
	};
	// ======================================================================
	
	// Data source for kendo
	function generateMarkerSetPresetDataSource() {
		var previewMarkerGenerator = new mobmap.MarkerGenerator(document);
		var mopt = new mobmap.MarkerOptionModelProxy(previewMarkerGenerator);
		mopt.updateGeneratorConfiguration();
	
		var ls = [];
		for (var i in MarkerSetPreset) if (MarkerSetPreset.hasOwnProperty(i)) {
			var item = MarkerSetPreset[i];
			mopt.loadMarkerSetPreset(i);
			
			item.previewImage = generatePresetPreviewImage(item, previewMarkerGenerator);
			item.id = i;
			ls.push(item);
		}

		ls.sort(function(a,b) { return a.priority - b.priority; });

		var ds = new kendo.data.DataSource({
			data: ls
		});

		ds.read();
		return ds;
	}

	function generateMarkerSetPreviewImageByPID(pid) {
		var previewMarkerGenerator = new mobmap.MarkerGenerator(document);
		var mopt = new mobmap.MarkerOptionModelProxy(previewMarkerGenerator);
		mopt.updateGeneratorConfiguration();
		mopt.loadMarkerSetPreset(pid);

		return generateMarkerColorsPreviewImage(previewMarkerGenerator.colorGen, previewMarkerGenerator.coloringReversed);
	}

	function generateMarkerSetPresetPreviewImages(callback, customList) {
		var previewMarkerGenerator = new mobmap.MarkerGenerator(document);
		var mopt = new mobmap.MarkerOptionModelProxy(previewMarkerGenerator);
		mopt.updateGeneratorConfiguration();

		var allCount = countMarkerSetPreset();
		if (customList) {
			allCount += customList.length;
		}

		var index = 0;
		var i, item;

		// Preset(fixed)
		for (i in MarkerSetPreset) if (MarkerSetPreset.hasOwnProperty(i)) {
			item = MarkerSetPreset[i];
			item.id = i;
			mopt.loadMarkerSetPreset(i);

			callback(
				item,
				generateMarkerColorsPreviewImage(previewMarkerGenerator.colorGen),
				index, allCount);

			++index;
		}
		
		// Custom
		if (customList) {
			for (i = 0;i < customList.length;++i) {
				item = customList[i];
				mopt.loadMarkerSetDirect(item);
				
				callback(
					item,
					generateMarkerColorsPreviewImage(previewMarkerGenerator.colorGen),
					index, allCount);
				
				++index;
			}
		}
	}
	
	function countMarkerSetPreset() {
		var n = 0;
		for (var i in MarkerSetPreset) if (MarkerSetPreset.hasOwnProperty(i)) { ++n; }
		return n;
	}

	
	var kPresetPreviewWidth  = 32;
	var kPresetPreviewHeight = 8;
	function generatePresetPreviewImage(preset, markerGenerator) {
		var cv = document.createElement('canvas');
		var w = kPresetPreviewWidth;
		var h = kPresetPreviewHeight;
		var n = 7;
		var clr = new MMColor();
		
		cv.width  = w;
		cv.height = h;
		var g = cv.getContext('2d');
		
		g.clearRect(0, 0, w, h);
		
		for (var i = 0;i < n;++i) {
			var t = i / (n-1);
			markerGenerator.colorGen.pick(clr, t);
			
			g.save();
			g.fillStyle = clr.toCSSRGBA();
			g.fillRect(i*4, 0, 3, h);
			
			g.fillStyle = 'rgba(50,50,50,0.2)';
			g.fillRect(i*4, 0, 3, h);

			g.fillStyle = clr.toCSSRGBA();
			g.fillRect(i*4+1, 1, 1, h-2);
			g.restore();
		}
		
		return cv.toDataURL();
	}

	var kColorPreviewWidth  = 76;
	var kColorPreviewHeight = 12;
	function generateMarkerColorsPreviewImage(colorGenerator, reversed) {
		var cv = document.createElement('canvas');
		var w = kColorPreviewWidth;
		var h = kColorPreviewHeight;
		var n = 7;
		var clr = new MMColor();
		
		cv.width  = w;
		cv.height = h;
		var g = cv.getContext('2d');

		for (var i = 0;i < n;++i) {
			var t = i / (n-1);
			colorGenerator.pick(clr, reversed ? (1.0-t) : t);

			g.save();
			
			g.shadowColor = 'rgba(0,0,0,0.5)';
			g.shadowBlur = 2;
			g.shadowOffsetX = 0;
			g.shadowOffsetY = 1;
			
			g.fillStyle = clr.toCSSRGBA();
			g.lineWidth = 0.5;
			g.strokeStyle = '#fff';
			g.beginPath();
			g.arc(8 + i*10, 5, 4, 0, Math.PI*2, false);
			g.fill();
			
			g.shadowBlur = 0;
			g.shadowOffsetY = 0;
			g.stroke();
			g.restore();
		}
		
		return cv;
	}

	pkg.generateMarkerSetPresetDataSource  = generateMarkerSetPresetDataSource;
	pkg.generateMarkerSetPreviewImageByPID = generateMarkerSetPreviewImageByPID;
	pkg.generateMarkerColorsPreviewImage      = generateMarkerColorsPreviewImage;
	pkg.generateMarkerSetPresetPreviewImages  = generateMarkerSetPresetPreviewImages;
	pkg.MarkerSetPreset = MarkerSetPreset;
});