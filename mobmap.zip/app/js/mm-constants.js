window.ENABLE_MOBMAP_LAZY_LOAD = true;

var kBooleanOpNames = {
	And: 'a', 
	Or:  'o',
	Not: 'n'
};

var kInfoPaneTabNames = {
	Layers:     'layers',
	Data:       'data_detail',
	Analysis: 'ana'
};

var AppToolbarButtonName = {
	ClearSel:  'clear-sel',
	RectSel:   'rect-sel',
	GateDock:  'gate-dock',
	Plugin:    'plug-in',
	Clock:     'clock',
	Theater:   'theater',
	TLViz:     'tl-viz',
	TLV_Config:'tlv-config'
};

var DataToolbarButtonName = {
	ExportCSV: 'export-csv'
};

var AttributeType = {
	STRING:   0,
	FLOAT:    1,
	CFLOAT:   2,
	INTEGER:  3,
	DATETIME: 4
};

var AttributeTypeNameMap = {
	'string': AttributeType.STRING,
	'float':  AttributeType.FLOAT,
	'cfloat': AttributeType.CFLOAT,
	'int':    AttributeType.INTEGER,
	'datetime': AttributeType.DATETIME
};

var kInitialValueTypeEmpty      = 0;
var kInitialValueTypeVelocityMS = 1;

var SelectionSession = {
	Rect: 1
};

var kRequiredMovingObjectAttributes = [
	{name: 'id',   type: AttributeType.INTEGER},
	{name: 'time', type: AttributeType.DATETIME},
	{name: 'x',    type: AttributeType.CFLOAT},
	{name: 'y',    type: AttributeType.CFLOAT}
];

var kRequiredMovingObjectAttributeQuickMap = {
	'id':   1,
	'time': 1,
	'x':    1,
	'y':    1
};

var kDateRegExp = /([0-9]+)[-\/]([0-9]+)[-\/]([0-9]+)/ ;
var kTimeRegExp = /([0-9]+):([0-9]+)(:([0-9]+))?/ ;
var kDefaultDayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
var kDefaultMonthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
var kDefaultShortMonthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];


var kMarkerCompositionNormal = 0;
var kMarkerCompositionAdd    = 1;
var kMarkerPresetIncludeBW   = 0x80;
var kMarkerPresetUseScaling  = 0x40;

var kTrajLineStyle_Normal = 0;
var kTrajLineStyle_Fat    = 1;