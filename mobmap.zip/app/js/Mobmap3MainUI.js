mmDefineModule(function(pkg) {
	'use strict';
	
	function Mobmap3MainUI(app, appScreen, mapExtender) {
		this.appScreen = appScreen;
		this.tlvConfigScreen   = null;
		this.colorConfigScreen = null;
		this.csvExporterScreen = null;
		this.csvLoaderScreen   = null;
		this.liveMovScreen     = null;
		this.sampleDataScreen = null;
		this.progressScreen = null;
		this.shapeImporterScreen = null;
		this.setOwnerApp(app);
		this.nullInitProperties();
		
		this.initSubViews(mapExtender);
	}
	
	Mobmap3MainUI.prototype = {
		// ============ Initialization ============
		nullInitProperties: function() {
			this.toolPane = this.mapPane = this.infoPane = this.extPane =
				this.dataDetailView = this.layersListView = this.aoListView = this.annView = null;
		},
		
		// getters
		getToolPane: function() { return this.toolPane; },
		getMapPane: function() { return this.mapPane; },
		getExtPane: function() { return this.extPane; },
		getLayersListView: function() { return this.layersListView; },
		getDataDetailView: function() { return this.dataDetailView; },
		getAnalysisObjectListView: function() { return this.aoListView; },
		
		// [][][] User interface setup [][][]
		initSubViews: function(mapExtender) {
			this.initToolPane();
			this.initMapPane(mapExtender);
			this.initInfoPane();
			this.initExtPane();

			this.fillInfoPane();
		},

		initExtPane: function() {
			var targetPaneElement = this.appScreen.getExtPaneElement();
			this.extPane = new mobmap.ExtPane(targetPaneElement);
			mobmap.Mobmap3PanesScreen.observeScreenResize(this.extPane, this.appScreen);
		},

		initInfoPane: function() {
			var targetPaneElement = this.appScreen.getInfoPaneElement();
			this.infoPane = new mobmap.InfoPane(targetPaneElement);
			mobmap.Mobmap3PanesScreen.observeScreenResize(this.infoPane, this.appScreen);
			
			this.infoPane.eventDispatcher().bind(
				mobmap.InfoPane.INFOPANE_EVENT_PAGE_SELECTED ,
				this.onInfoPaneTabChanged.bind(this)
			);
		},

		observeDetailViewEvents: function(eventType, handler) {
			this.dataDetailView.eventDispatcher().bind(
				eventType, handler
			);
		},

		fillInfoPane: function() {
			// setup inner views
			this.layersListView = this.initInfoPaneLayersListView(this.infoPane);
			this.dataDetailView = this.initInfoPaneDataDetailView(this.infoPane);
			this.aoListView = this.initInfoPaneAnalysisObjectListView(this.infoPane);
		},
		
		onInfoPaneTabChanged: function() {
			this.appScreen.fireResize();
		},

		initInfoPaneLayersListView: function(infoPane) {
			var boxElement = infoPane.getBoxByName( kInfoPaneTabNames.Layers );
			var v = new mobmap.LayerListView( boxElement );
			v.setOwnerApp( this.getOwnerApp() );
			return v;
		},
		
		initInfoPaneDataDetailView: function(infoPane) {
			var boxElement = infoPane.getBoxByName( kInfoPaneTabNames.Data );
			return new mobmap.DataDetailView( boxElement );
		},
		
		initInfoPaneAnalysisObjectListView: function(infoPane) {
			var boxElement = infoPane.getBoxByName( kInfoPaneTabNames.Analysis );
			return new mobmap.AnalysisObjectListView( boxElement );
		},


		initMapPane: function(mapExtender) {
			var targetPaneElement = this.appScreen.getContentPaneElement();
			this.mapPane = new mobmap.MapPane(targetPaneElement, mapExtender);
		},
		
		initToolPane: function() {
			var targetPaneElement = this.appScreen.getToolsPaneElement();
			this.toolPane = new mobmap.ToolPane(targetPaneElement);
			this.toolPane.observeScreenResize(this.appScreen);
		},
		
		bindResizeEvent: function(callback) {
			this.appScreen.eventDispatcher().bind(mobmap.Mobmap3PanesScreen.RESIZE_EVENT, callback);
		},
		
		// TLV
		ensureTLVConfigScreen: function() {
			if (!this.tlvConfigScreen) {
				this.tlvConfigScreen = new mobmap.TLVConfigScreen();
				this.tlvConfigScreen.setOwnerApp( this.getOwnerApp() );
			}
			return this.tlvConfigScreen;
		},
		
		// COLOR
		ensureColorConfigScreen: function() {
			if (!this.colorConfigScreen) {
				this.colorConfigScreen = new mobmap.ColorConfigScreen();
				this.colorConfigScreen.setOwnerApp( this.getOwnerApp() );
			}
			return this.colorConfigScreen;
		},
		
		// LIVE
		
		ensureLiveMovScreen: function() {
			if (!this.liveMovScreen) {
				this.liveMovScreen = new mobmap.LiveMovScreen();
			}
			
			return this.liveMovScreen;
		},
		
		// EXPORTER
		ensureCSVExporterScreen: function() {
			if (!this.csvExporterScreen) {
				this.csvExporterScreen = new mobmap.CSVExporterScreen();
			}

			return this.csvExporterScreen;
		},
		
		openCSVExporterScreen: function(listener, sourceLayer) {
			var s = this.ensureCSVExporterScreen();
			s.setListener(listener || null);
			s.createSorter(sourceLayer.attributeList);
			s.open();
		},
		
		closeCSVExporterScreen: function() {
			if (this.csvExporterScreen) {
				this.csvExporterScreen.hide();
				this.csvExporterScreen.destroySorter();
				this.csvExporterScreen.revokeLastResult();
			}
		},
		
		showCSVExporterResult: function(blob) {
			if (this.csvExporterScreen) {
				this.csvExporterScreen.showResult(blob);
			}
		},
		
		showCSVExporterProgress: function(ratio) {
			if (this.csvExporterScreen) {
				this.csvExporterScreen.showProgress(ratio);
			}
		},
		
		// LOADER
		ensureCSVLoaderScreen: function() {
			if (!this.csvLoaderScreen) {
				this.csvLoaderScreen = new mobmap.CSVPreviewScreen();
				this.getOwnerApp().dataLoadController.bindView( this.csvLoaderScreen );
			}
			
			return this.csvLoaderScreen;
		},
		
		openCSVLoaderScreen: function() {
			var s = this.ensureCSVLoaderScreen();
			s.openFileDialog();
		},
		
		ensureSampleDataScreen: function(callbackFunc) {
			if (!this.sampleDataScreen) {
				this.sampleDataScreen = new mobmap.SampleDataLoaderScreen(callbackFunc);
			}
			
			return this.sampleDataScreen;
		},

		ensureShapeImporterScreen: function() {
			if (!this.shapeImporterScreen) {
				this.shapeImporterScreen = new mobmap.ShapeImportScreen();
			}
			
			return this.shapeImporterScreen;
		},

		showProgressScreen: function() {
			if (!this.progressScreen) {
				this.progressScreen = new mobmap.WaitScreen();
			}
			
			this.setProgressScreenPercentage(0);
			this.progressScreen.show();
			return this.progressScreen;
		},
		
		hideProgressScreen: function() {
			if (this.progressScreen) {
				this.progressScreen.hide();
			}
		},
		
		setProgressScreenPercentage: function(v, senderJob, progress) {
			if (this.progressScreen) {
				this.progressScreen.setPercentage(v, senderJob, progress);
			}
		},
		
		toggleExtPane: function() {
			this.appScreen.toggleExtPane();
		}
	};
	
	// base classes
	mobmap.installBaseMethods(  Mobmap3MainUI.prototype, mobmap.AppOwnedBase  );
	
	pkg.Mobmap3MainUI = Mobmap3MainUI;
});
