mmDefineModule(function(pkg) {
	'use strict';
	
	function Mobmap3App(appScreen) {
		this.appScreen = appScreen;
		this.nullInitProperties();

		this.mapExtender = new mobmap.MapExtender();
		this.mainUI = new mobmap.Mobmap3MainUI(this, appScreen, this.mapExtender);
		this.showWelcomeMessage();
		this.initControllers();
		this.observeAppGlobalEvents();
		this.observeAppMainToolBar();
		this.syncAppMainToolBarStates();
		this.checkSampleDataViewerMode();
		
		this.popupManager = new mobmap.PopupManager();
		mobmap.loadMarkerSetPresetCustomList();

		appScreen.fireResize(50);
	}

	Mobmap3App.Events = {
		ProjectCreated: 'mobmap-app-event-project-created'
	};

	Mobmap3App.prototype = {
		eventDispatcher: function()   { return this.appScreen.eventDispatcher(); },
		getCurrentProject: function() { return this.currentProject; },
		getLayerController: function(){ return this.layerController; },

		// ============ Initialization ============
		nullInitProperties: function() {
			this.currentProject = null;
			this.tempPickRec = null;
			
			// UI controllers
			this.gateViewController      = null;
			this.mapDockController       = null;
			this.dataLoadController      = null;
			this.gridDataLoadController  = null;
			this.liveMovLoadController   = null;
			this.selectionController     = null;
			this.layerListViewController = null;
			this.ddvController           = null;
			this.toolPaneController      = null;
			this.layerController         = null;
			this.autoplayController      = null;
			this.analysisObjListViewController = null;
			this.confirmDialog           = null;
		},

		showWelcomeMessage: function() {
			var lv = this.mainUI.getLayersListView();
			var el = $H('div');
			el.innerHTML = '<img src="images/welcome-arrow.png" width="48" height="48" alt="^"><p class="start-here-disp">Start from here.</p><p class="start-logo-disp"><img alt="" src="icons/v3icon-256.png" width="128" height="128"><br>Mobmap Web</p>';

			lv.addWelcomePanel(el);
		},

		initControllers: function() {
			// Map Pane
			var mapPane = this.mainUI.getMapPane();
			mapPane.setOwnerApp(this);
			this.mainUI.bindResizeEvent(mapPane.onContainerResize.bind(mapPane));
			
			//  for Dock
			this.mapDockController = new mobmap.MapDockController( this.mainUI.getMapPane() );
			this.mapDockController.setOwnerApp(this);

			//  for Gate
			this.gateViewController = new mobmap.GateViewController();
			this.gateViewController.setOwnerApp(this);
			this.gateViewController.setSelectionStateProviderFunc( this.isAnySelectedOnCurrentLayer.bind(this) );
			this.gateViewController.connectModelAndView(
				this.mainUI.getMapPane(),
				this.eventDispatcher()
			); 

			// for Info pane
			//  - - LayerList
			this.layerListViewController = new mobmap.LayerListViewController();
			this.layerListViewController.setOwnerApp(this);
			this.layerListViewController.connectModelAndView(
				this.mainUI.getLayersListView(),
				this.eventDispatcher() );
				
			// - - Data View - - - - - - - - - - - - - - - -
			var dvc = new mobmap.DataDetailViewController();
			dvc.setOwnerApp(this);
			dvc.connectModelAndView(
			  this.mainUI.getDataDetailView(),
			  this.eventDispatcher() );
			this.ddvController = dvc;
			// - - - - - - - - - - - - - - - - - - - - - - -
	
			this.mainUI.bindResizeEvent(this.layerListViewController.afterContainerResize.bind( this.layerListViewController ) );

			//  - - AnalysisObjectList
			this.analysisObjListViewController = new mobmap.AnalysisObjectListViewController();
			this.analysisObjListViewController.setOwnerApp(this);
			this.analysisObjListViewController.connectModelAndView(
				this.mainUI.getAnalysisObjectListView(),
				this.eventDispatcher() );

			// for Tool pane
			this.toolPaneController = new mobmap.ToolPaneController();
			this.toolPaneController.connectModelAndView(
				this.mainUI.getToolPane(),
				this.eventDispatcher()
			);
			
			this.layerController = new mobmap.LayerController();
			this.layerController.setOwnerApp(this);
			this.layerController.connectModelAndView(
				this.mainUI.getMapPane(),
				this.eventDispatcher());

			//	Data loading
			//    mov
			this.dataLoadController = new mobmap.DataLoadController();
			this.dataLoadController.setOwnerApp(this);

			//    grid
			this.gridDataLoadController = this.setupGridDataLoading();

			// selection
			this.selectionController = new mobmap.SelectionController();
			this.selectionController.setOwnerApp(this);
			this.selectionController.setMap( this.mainUI.getMapPane() );

			// autoplay
			this.autoplayController = new mobmap.AutoplayController();
			this.autoplayController.setOwnerApp(this);
			this.autoplayController.setPlayControllerUI( this.mainUI.getToolPane().getPlayControllerUI() );
			this.autoplayController.observeGlobalEvents( this.eventDispatcher() );
		},
		
		newProject: function() {
			this.currentProject = new mobmap.MMProject();
			this.currentProject.setOwnerApp(this);
			this.currentProject.setParentEventDispatcher( this.eventDispatcher() );
			this.fire(Mobmap3App.Events.ProjectCreated, this);
		},

		autoConnect: function(parameters) {
			if (parameters && parameters.auto_connect && parameters.read_token) {
				this.openLiveMovSetupScreen(parameters);
			}
		},

		fire: function(eventType, arg1) {
			this.eventDispatcher().trigger(eventType, arg1);
		},
		
		observeAppGlobalEvents: function() {
			this.eventDispatcher().
			 bind( mobmap.LayerEvent.DataTimeRangeChange, this.onDataTimeRangeChange.bind(this) ).
			 bind( mobmap.DateTime.CURRENT_TIME_CHANGE_EVENT, this.onDateTimeChange.bind(this) ).
			 bind( Mobmap3App.Events.ProjectCreated, this.onProjectCreated.bind(this) );
			
			this.mainUI.observeDetailViewEvents(
				mobmap.DataDetailView.DATAROW_HOVER_EVENT,
				this.onDataDetailViewRowHover.bind(this)
			);
		},
		
		onProjectCreated: function() {
			if (this.currentProject && this.autoplayController) {
				this.autoplayController.setDateTimeModel( this.currentProject.currentDateTime );
			}
		},
		
		onDateTimeChange: function(e, senderDateTime) {
			if (this.currentProject && (this.currentProject.currentDateTime === senderDateTime)) {
				this.redrawMapPane();
			}
		},
		
		onDataTimeRangeChange: function(e) {
			var pj = this.getCurrentProject();
			pj.currentDateTime.capMin( pj.calcMinTimeAmongAllLayers() );
			pj.currentDateTime.capMax( pj.calcMaxTimeAmongAllLayers() );
		},
		
		getAnalysisListView: function() {
			return this.mainUI.getAnalysisObjectListView();
		},

		getConfirmDialog: function() {
			if (!this.confirmDialog) {
				this.confirmDialog = new mobmap.ConfirmDialog();
			}
			
			return this.confirmDialog;
		},

		setupGridDataLoading: function() {
			var f = new mobmap.FileFormWrapper();
			document.body.appendChild(f.getElement());
			
			var ctrl = new mobmap.GridDataLoadController(f);
			ctrl.setOwnerApp(this);
			
			return ctrl;
		},
		
		onDataDetailViewRowHover: function(e, objId) {
			this.aimMapToId(objId);
		},

		// Main tool bar commands [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []

		observeAppMainToolBar: function() {
			var tb = this.mainUI.getToolPane().getAppToolBar();
			tb.eventDispatcher().
			 bind( mobmap.MMToolbar.TOGGLE_CHANGE_EVENT, this.onAppMainToolBarToggle.bind(this) ).
			 bind( mobmap.MMToolbar.CLICK_EVENT, this.onAppMainToolBarClick.bind(this) );
		},

		onAppMainToolBarClick: function(e, button) {
			if (button.name === AppToolbarButtonName.TLV_Config) {
				this.onAppMainToolbarTLVizConfig();
			} else if (button.name === AppToolbarButtonName.Plugin) {
				this.mainUI.toggleExtPane();
			} else if (button.name === AppToolbarButtonName.ClearSel) {
				this.clearSelectedLayerSelection();
			}
		},

		onAppMainToolBarToggle: function(e, button) {
			switch(button.name) {
			case AppToolbarButtonName.RectSel:
				this.onAppMainToolbarRectSelectToggle(button.selected);
				break;
			case AppToolbarButtonName.GateDock:
				this.onAppMainToolbarGateDockToggle(button.selected);
				break;
			case AppToolbarButtonName.Clock:
				this.onAppMainToolbarClockToggle(button.selected);
				break;
			case AppToolbarButtonName.TLViz:
				this.onAppMainToolbarTLVizToggle(button.selected);
				break;
			case AppToolbarButtonName.Theater:
				this.onAppMainToolbarTheaterToggle(button.selected);
				break;
			default:
				break;
			}
		},
		
		onAppMainToolbarRectSelectToggle: function(buttonSelected) {
			if (buttonSelected) {
				this.selectionController.beginRectSelection();
			} else {
				this.selectionController.endSelection();
			}
		},
		
		onAppMainToolbarGateDockToggle: function (buttonSelected) {
			this.mapDockController.setVisibility(buttonSelected);
		},

		onAppMainToolbarClockToggle: function(buttonSelected) {
			var mapPane = this.mainUI.getMapPane();
			mapPane.setClockVisibility(buttonSelected);
		},
		
		onAppMainToolbarTheaterToggle: function(buttonSelected) {
			var mapPane = this.mainUI.getMapPane();
			mapPane.showMapControls(!buttonSelected);
			
			if (buttonSelected) {
				this.forceGateDockVisibility(false);
			}
		},

		// Timeline viz
		onAppMainToolbarTLVizConfig: function() {
			var s = this.mainUI.ensureTLVConfigScreen();
			s.open();
		},

		onAppMainToolbarTLVizToggle: function(buttonSelected) {
			this.layerController.updateTimelineVizIf();
		},
		isTimelineVizEnabled: function() {
			var tb = this.mainUI.getToolPane().getAppToolBar();
			return tb.getSelectedStateByName(AppToolbarButtonName.TLViz);
		},

		forceClockVisibility: function(shown) {
			var tb = this.mainUI.getToolPane().getAppToolBar();
			tb.setSelectedStateByname(AppToolbarButtonName.Clock, shown);
		},

		forceGateDockVisibility: function(shown) {
			var tb = this.mainUI.getToolPane().getAppToolBar();
			tb.setSelectedStateByname(AppToolbarButtonName.GateDock, shown);
		},


		deactivateRectSelectButton: function() {
			var tb = this.mainUI.getToolPane().getAppToolBar();
			if (tb) {
				tb.setSelectedStateByname(AppToolbarButtonName.RectSel, false);
			}
		},
		
		syncAppMainToolBarStates: function() {
			var tb = this.mainUI.getToolPane().getAppToolBar();
			if (tb) {
				tb.setSelectedStateByname(AppToolbarButtonName.GateDock,
					this.mainUI.getMapPane().getDock().getVisibility() );
			}
		}
	};

	// base classes
	mobmap.installBaseMethods(  Mobmap3App.prototype, mobmap.Mobmap3AppFunctionBase  );
	mobmap.installBaseMethods(  Mobmap3App.prototype, mobmap.Mobmap3MessageHandlerBase  );
	
	pkg.Mobmap3App = Mobmap3App;
});
