mmDefineModule(function(pkg) {
	'use strict';
	
	var Mobmap3MessageHandlerBase = {
		onMessage_loadDynamicScript: function(params) {
			var b = new Blob([params.content]);
			var url = window.URL.createObjectURL(b);
			
			var s = document.createElement('script');
			s.src = url;
			document.body.appendChild(s);
		},
		
		onMessage_notifyPopupOnload: function(params) {
			this.popupManager.onOnloadMessageReceived(params.windowId);
		}
	};
	
	pkg.Mobmap3MessageHandlerBase = Mobmap3MessageHandlerBase;
});
