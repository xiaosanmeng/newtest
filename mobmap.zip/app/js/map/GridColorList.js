mmDefineModule(function(pkg) {
	'use strict';

	var kListLength = 100;
	
	var tempCanvas = null;
	var kTempCanvasWidth = kListLength;
	
	function GridColorList() {
		this.styleList = [];
	}
	
	GridColorList.prototype = {
		// generic API
		copyFrom: function(source) {
			if (!source.styleList) { return; }
			var sls = source.styleList;
			var len = sls.length;
			
			this.styleList.length = 0;
			for (var i = 0;i < len;++i) {
				this.styleList.push( sls[i] );
			}
		},
		
		// consumer API
		
		// position: 0.0-1.0
		getColor: function(position) {
			var i = Math.floor(position * kListLength);
			if (i < 0) { i = 0; }
			else if (i >= kListLength) { i = kListLength-1; }
			
			return this.styleList[i] || '#000';
		},

		generatePreviewImage: function() {
			var n = 10;
			var cellSize = 7;
			
			var previewCanvas = document.createElement('canvas');
			previewCanvas.width = (cellSize * n) + (n - 1);
			previewCanvas.height = cellSize;

			var g = previewCanvas.getContext('2d');

			for (var i = 0;i < n;++i) {
				var t = i / (n - 1);
				g.fillStyle = '#000';
				g.fillRect(i * (cellSize+1), 0, cellSize, cellSize);
				g.fillStyle = '#654';
				g.fillRect(i * (cellSize+1) +1, 1, cellSize-2, cellSize-2);

				g.fillStyle = this.getColor(t);
				g.fillRect(i * (cellSize+1) +1, 1, cellSize-2, cellSize-2);
			}
			
			return previewCanvas;
		},

		// provider's APIs
		generateHueWheel: function(alpha) {
			this.clearList();
			var cv = ensureTempCanvas();
			var g  = cv.getContext('2d');

			g.save();
			this.setHueWheelGradient(g, cv.width | 0, alpha, false);
			this.fill(g);
			g.restore();

			this.pickColors(this.styleList, g, kListLength);
		},

		generateAplhaGradient: function(colorR, colorG, colorB) {
			this.clearList();
			var cv = ensureTempCanvas();
			var g  = cv.getContext('2d');

			g.save();
			this.setBlendGradient(g, cv.width | 0, colorR, colorG, colorB);
			this.fill(g);
			g.restore();

			this.pickColors(this.styleList, g, kListLength);
		},

		// internal APIs
		clearList: function() {
			this.styleList.length = 0;
		},
		
		fill: function(g) {
			g.clearRect(0, 0, kTempCanvasWidth, 8);
			g.fillRect(0, 0, kTempCanvasWidth, 8);
		},

		setHueWheelGradient: function(g, width, alpha, reversed) {
			var tmp = [0,0,0];
			var grd = g.createLinearGradient(0, 0, width, 0);
			for (var i = 0;i < 21;++i) {
				tmp[0] = (reversed ? i : (20-i)) * 11;
				tmp[1] = 1;
				tmp[2] = 1;

				hsvToRGB(tmp);

				grd.addColorStop(i / 20.0, 'rgba('+ tmp.join(',') +','+ alpha +')');
			}

			g.fillStyle = grd;
		},

		setBlendGradient: function(g, width, colorR, colorG, colorB) {
			var grd = g.createLinearGradient(0, 0, width, 0);

			grd.addColorStop(0, 'rgba('+ colorR +','+ colorG +','+ colorB +',0)');
			grd.addColorStop(1, 'rgba('+ colorR +','+ colorG +','+ colorB +',1)');

			g.fillStyle = grd;
		},
		
		pickColors: function(outArray, g, n) {
			var imgdat = g.getImageData(0, 0, n, 1);
			var p = imgdat.data;
			
			for (var i = 0;i < n;++i) {
				var cR = p[i*4    ];
				var cG = p[i*4 + 1];
				var cB = p[i*4 + 2];
				var cA = p[i*4 + 3];

				outArray.push( 'rgba('+ cR +','+ cG +','+ cB +','+ (cA / 255.0) +')' );
			}
		}
	};
	
	
	
	function ensureTempCanvas() {
		if (!tempCanvas) {
			tempCanvas = document.createElement('canvas');
			tempCanvas.width  = kTempCanvasWidth;
			tempCanvas.height = 8;
		}
		
		return tempCanvas;
	}
	
	pkg.GridColorList = GridColorList;
});