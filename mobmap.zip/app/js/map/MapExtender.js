mmDefineModule(function(pkg) {
	'use strict';

	var CustomMapTypes = {
		'Dark' : 'Dark',
		'LiteDark' : 'Lite Dark',
		'OSM_S': 'OSM',
		'OSM_D': 'OSM Dark',
		'GSI_S': 'GSI',
		'GSI_D': 'GSI Dark',
		'BLANK': 'Blank'
	};

	function MapExtender() {
		this.idMap = {};
	}

	MapExtender.prototype = {
		extendMapTypeList: function(mapTypeList) {
			eachType(function(tid) {
				mapTypeList.push(tid);
			});
		},

		initMapTypes: function(gmap) {
			var that = this;

			eachType(function(tid, name) {
				var mapTypeObj = that[ 'initMapType_' + tid ](gmap, name);
				if (mapTypeObj) {
					gmap.mapTypes.set(tid, mapTypeObj);
					that.registerWithId(tid, mapTypeObj);
				}
			});
			
			this.observeMapTypeChange(gmap);
		},
		
		initMapType_Dark: function(gmap, typeName) {
			return mobmap.GoogleMapsCustom.setupDarkMap(gmap);
		},

		initMapType_LiteDark: function(gmap, typeName) {
			return mobmap.GoogleMapsCustom.setupLightDarkMap(gmap);
		},
		
		initMapType_OSM_S: function(gmap, typeName) {
			var t = new OSMMapType(gmap, typeName);
			return t;
		},

		initMapType_OSM_D: function(gmap, typeName) {
			var t = new OSMMapType(gmap, typeName, 'maptile-osm-dark');
			return t;
		},

		initMapType_GSI_S: function(gmap, typeName) {
			var t = new GSIMapType(gmap, typeName);
			return t;
		},

		initMapType_GSI_D: function(gmap, typeName) {
			var t = new GSIMapType(gmap, typeName, 'maptile-osm-dark');
			return t;
		},

		initMapType_BLANK: function(gmap, typeName) {
			var t = new BlankMapType(gmap, typeName);
			return t;
		},

		observeMapTypeChange: function(gmap) {
			google.maps.event.addListener(gmap, "maptypeid_changed", this.onMapTypeChange.bind(this, gmap));
		},
		
		onMapTypeChange: function(gmap) {
			var cur = gmap.getMapTypeId();
			
			this.eachRegistered(function(tid, mapTypeObj) {
				if (mapTypeObj.setCopyrightVisibility) {
					mapTypeObj.setCopyrightVisibility(cur === tid);
				}
			});
		},
		
		registerWithId: function(tid, mapTypeObj) {
			this.idMap[tid] = mapTypeObj;
		},
		
		eachRegistered: function(func) {
			var m = this.idMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				func(i, m[i]);
			}
		}
	};

	// GSI Map Type ======================================================================================
	function GSIMapType(gmap, typeName, customClass, toner) {
		this.customClass = customClass || null;
		this.name = typeName;
		
		this.tileSize = new google.maps.Size(256, 256);
		this.urlBase = "https://cyberjapandata.gsi.go.jp/xyz/std";
		this.subDomains = ['a','b','c'];

		this.copyrightElement = generateMapCopyrightBox(gmap, '<a target="_blank" href="https://maps.gsi.go.jp/">© Geospatial Information Authority of Japan</a>');
		this.copyrightElement.style.display = 'none';

		this.imgMapType = new google.maps.ImageMapType({
			alt: typeName,
			getTileUrl: this.getTileUrl.bind(this)
		});
	}
	
	GSIMapType.prototype = {
		getOpacity: function() {
			return this.imgMapType.getOpacity();
		},	
		
		setCopyrightVisibility: function(v) {
			this.copyrightElement.style.display = v ? 'inline' : 'none';
		},

		getTile: function(tileCoord, zoom, ownerDocument) {
			var el = this.imgMapType.getTile(tileCoord, zoom, ownerDocument);
			if (this.customClass) {
				$(el).addClass( this.customClass );
			}
			
			
			return el;
		},

		releaseTile: function(tileDiv) {
			return this.imgMapType.releaseTile(tileDiv);
		},

		setOpacity: function(opacity) {
			return this.imgMapType.setOpacity(opacity);
		},
		
		getTileUrl: function(coord, zoom) {
//			var sd = this.pickSubdomain(coord.x + coord.y);
			var url = this.urlBase + "/" +zoom+ "/" +coord.x+ "/" +coord.y+ ".png";
			
			//console.log( url );
			return url;
		},

		pickSubdomain: function(index) {
			if (this.subDomains && this.subDomains.length > 0) {
				return this.subDomains[ index % (this.subDomains.length) ] + '.';
			}
			
			return '';
		},

		maxZoom: 19
	};

	// OSM Map Type ======================================================================================
	function OSMMapType(gmap, typeName, customClass, toner) {
		this.customClass = customClass || null;
		this.name = typeName;
		this.tileSize = new google.maps.Size(256, 256);

		this.urlBase = toner ? "tile.stamen.com/toner" : "tile.openstreetmap.org";
		this.subDomains = ['a','b','c'];

		this.copyrightElement = generateMapCopyrightBox(gmap, '<a target="_blank" href="http://www.openstreetmap.org/">© OpenStreetMap contributors</a>');
		this.copyrightElement.style.display = 'none';

		this.imgMapType = new google.maps.ImageMapType({
			alt: typeName,
			getTileUrl: this.getTileUrl.bind(this)
		});
	}
	
	OSMMapType.prototype = {
		getOpacity: function() {
			return this.imgMapType.getOpacity();
		},	
		
		setCopyrightVisibility: function(v) {
			this.copyrightElement.style.display = v ? 'inline' : 'none';
		},

		getTile: function(tileCoord, zoom, ownerDocument) {
			var el = this.imgMapType.getTile(tileCoord, zoom, ownerDocument);
			if (this.customClass) {
				$(el).addClass( this.customClass );
			}
			
			
			return el;
		},

		releaseTile: function(tileDiv) {
			return this.imgMapType.releaseTile(tileDiv);
		},

		setOpacity: function(opacity) {
			return this.imgMapType.setOpacity(opacity);
		},
		
		getTileUrl: function(coord, zoom) {
			var sd = this.pickSubdomain(coord.x + coord.y);
			// console.log(sd)
			// var url ="https://api.mapbox.com/styles/v1/mapbox/dark-v8/tiles/256/" +zoom+ "/" +coord.x+ "/" +coord.y+ "?access_token=pk.eyJ1IjoiY2h1YW5neWFuZyIsImEiOiJjamszc2MzcHExMmdyM3FsZWV3NTF3c2FiIn0.rYAau4oxrmleqzYz23CRvA";
			
			var url = "https://" + sd + this.urlBase + "/" +zoom+ "/" +coord.x+ "/" +coord.y+ ".png";
			// return "https://api.mapbox.com/styles/v1/mapbox/dark-v9/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoiY2h1YW5neWFuZyIsImEiOiJjamszc2MzcHExMmdyM3FsZWV3NTF3c2FiIn0.rYAau4oxrmleqzYz23CRvA"
			console.log( url );

			return url;
		},

		pickSubdomain: function(index) {
			if (this.subDomains && this.subDomains.length > 0) {
				return this.subDomains[ index % (this.subDomains.length) ] + '.';
			}
			
			return '';
		},

		maxZoom: 19
	};

	// GSI Map Type ======================================================================================
	function BlankMapType(gmap, typeName) {
		this.name = typeName;
		this.tileSize = new google.maps.Size(256, 256);

		this.imgMapType = new google.maps.ImageMapType({
			alt: typeName,
			getTileUrl: this.getTileUrl.bind(this)
		});
	}

	BlankMapType.prototype = {
		getOpacity: function() {
			return this.imgMapType.getOpacity();
		},	

		getTile: function(tileCoord, zoom, ownerDocument) {
			var el = this.imgMapType.getTile(tileCoord, zoom, ownerDocument);
			return el;
		},

		releaseTile: function(tileDiv) {
			return this.imgMapType.releaseTile(tileDiv);
		},

		setOpacity: function(opacity) {
			return this.imgMapType.setOpacity(opacity);
		},

		getTileUrl: function(coord, zoom) {
			return kBLACK_PLAIN;
		},

		maxZoom: 23
	};



	function eachType(func) {
		for (var i in CustomMapTypes) if (CustomMapTypes.hasOwnProperty(i)) {
			func(i, CustomMapTypes[i]);
		}
	}

	function generateMapCopyrightBox(gmap, html) {
		var el = document.createElement("span");
		el.className = 'mm-gmap-custom-copyright';
		el.innerHTML = html;
		gmap.controls[google.maps.ControlPosition.BOTTOM_RIGHT].push(el);
		return el;
	}

	var kBLACK_PLAIN = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAEAQMAAA'+
	 'CJA+yzAAAAA1BMVEUEAAHXdKWQAAAACklEQVQI12OAAgAACAABod4++QAAAABJRU5ErkJggg==';

	MapExtender.CustomMapTypes = CustomMapTypes;
	pkg.MapExtender = MapExtender;
});
