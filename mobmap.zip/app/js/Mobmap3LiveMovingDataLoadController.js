mmDefineModule(function(pkg) {
	'use strict';
	
	// 0: No  1:test  2:gps-test
	var TEST_MODE = 2;
	
	var kTestOriginTime = 907196400;
	var EMIT_DBG = true;

	function LiveMovingDataLoadController() {
		this.loaderScreen = null;

		this.currentDestLayer = null;
		this.currentLoader = null;
		this.maxRecordTime = -1;
		
		this.updaterRunning = false;
		this.updater_closure = this.updateAll.bind(this);
	}
	
	LiveMovingDataLoadController.prototype = {
		start: function(parameters) {
			var app = this.getOwnerApp();
			if (app) {
				var scr = app.mainUI.ensureLiveMovScreen();
				this.bindView(scr);
				
				var preset = null;
				var presetToken = null;
				if (TEST_MODE === 1) {
					preset = 'http://127.0.0.1:4567/test/';
				} else if (TEST_MODE === 2) {
					preset = '';
					// /gps-test/ <- disabled
				}

				if (parameters && parameters.auto_connect && parameters.read_token) {
					preset = parameters.auto_connect;
					presetToken = parameters.read_token;
				}

				scr.open(preset, presetToken);
			}
		},
		
		bindView: function(loaderScreen) {
			if (this.loaderScreen) { return; }
			this.loaderScreen = loaderScreen;
			
			this.loaderScreen.eventDispatcher().bind(
				mobmap.LiveMovScreen.Events.ExecuteButtonClicked,
				this.onLoaderExecuteButtonClick.bind(this)
			).bind(
				mobmap.LiveMovScreen.Events.Cancelled,
				this.onLoaderCancelled.bind(this)
			);
			
		},
		
		onLoaderExecuteButtonClick: function() {
			var url = this.loaderScreen.getSourceURL();
			var tok = this.loaderScreen.getAccessToken();
			var o_time = kTestOriginTime;
			
			if (TEST_MODE !== 1) {
				o_time = this.getCurrentTimeSec();
			}
			
			this.currentDestLayer = this.createLayer();
			this.currentLoader = new mobmap.LiveMovingDataLoader(
				this.currentDestLayer,
				url,
				o_time,
				tok
			);
			
			this.currentDestLayer.setLiveModeData({
				originTime: o_time,
				lastUpdated: this.getCurrentTimeSec(),
				interval: 10
			});
			
			this.currentDestLayer.setLoader( this.currentLoader );
			this.currentLoader.setNetworkStatusListener( this );
			this.currentLoader.start();
		},
		
		onLoaderCancelled: function() {
			this.closeAndCleanup();
		},
		
		closeAndCleanup: function() {
			this.currentDestLayer = null;
			this.currentLoader = null;

			if (this.loaderScreen) {
				this.loaderScreen.closeAndCleanup();
			}
		},
		
		createLayer: function() {
			var app = this.getOwnerApp();
			if (app) {
				var lyr = app.addNewMovingObjectLayer();
				lyr.enableAutoLoad();
				return lyr;
			}
			
			return null;
		},
		
		liveOnInitialLoadSuccess: function(loader) {
			this.startUpdater();
			this.closeAndCleanup();

			var targetLayer = this.findLayerForLoader(loader);
			if (targetLayer) {
				var liveData = targetLayer.getLiveModeData();
				liveData.interval   = loader.getRecommendedRefreshInterval();
				liveData.bufferTime = loader.getRecommendedBufferTime();
			}
		}, 

		liveOnInitialLoadFail: function(loader, error) {
			this.removeCurrentLayer();
			this.loaderScreen.showError('Failed to download (status='+error.status+')');
		},
		
		liveOnUpdateSuccess: function(loader, requestedTime, downloadedContent) {
			var targetLayer = this.findLayerForLoader(loader);
			if (targetLayer) {
				this.maxRecordTime = -1;
				this.parseUpdaterContent( targetLayer, downloadedContent );
				
				if (this.maxRecordTime >= 0) {
					loader.updateMaxFetchedTime( this.maxRecordTime );
					targetLayer.updateDateTimeRange(this.maxRecordTime, true);
				}

				this.showLayerMessage(targetLayer, 'just now');
			}
		},
		
		liveOnUpdateFail: function(loader, error) {
			var targetLayer = this.findLayerForLoader(loader);
			if (targetLayer) {
				this.showLayerMessage(targetLayer, 'failed');
			}
		},
		
		removeCurrentLayer: function() {
			var ll = this.getLayerList();
			var layer = this.currentDestLayer;
	
			if (layer && ll) {
				ll.removeItem(layer);
			}
		},
		
		getLayerList: function() {
			var app = this.getOwnerApp();
			if (app) {
				var pj = app.getCurrentProject();
				if (pj) {
					return pj.getLayerList();
				}
			}
			
			return null;
		},

		getLayersListView: function() {
			var app = this.getOwnerApp();
			if (app) {
				return app.mainUI.getLayersListView();
			}
			
			return null;
		},

		// Updater
		
		startUpdater: function() {
			if (!this.updaterRunning) {
				this.updaterRunning = true;
				this.updateAll();
			}
		},
		
		updateAll: function() {
			if (this.updaterRunning) {
				var ll = this.getLayerList();
								
				if (ll) {
					var n = ll.count();
					for (var i = 0;i < n;++i) {
						var layer = ll.getAt(i);
						var liveData = layer.getLiveModeData();
						if (liveData) {
							var dt = this.getCurrentTimeSec() - liveData.lastUpdated;

							if (EMIT_DBG) { console.log("Checking live layer #"+i, dt +'/'+liveData.interval ); }
							if (dt >= liveData.interval) {
								this.updateALayer( layer );
								this.showLayerMessage(layer, 'updating...');
							} else {
								this.extendLayerTimeRange(layer);
								this.showLayerMessage(layer, dt ? (dt + ' sec. ago') : 'just now');
							}
						}
					}
				}
				
				setTimeout(this.updater_closure, 2000);
			}
		},

		extendLayerTimeRange: function(destLayer) {
			if (TEST_MODE !== 1) {
				var t = this.getCurrentTimeSec();
				destLayer.updateDateTimeRange(t, true);
			}
		},

		showLayerMessage: function(layer, message) {
			var lv = this.getLayersListView().getViewOfModel(layer);
			if (lv) {
				lv.pvShowAdditionalInfo();
				lv.pvSetAdditionalInfoText( message );
			}
		},

		updateALayer: function(layer) {
			if (EMIT_DBG) { console.log("    -> XHR initiated" ); }

			var liveData = layer.getLiveModeData();
			liveData.lastUpdated = this.getCurrentTimeSec();

			var loader = layer.getLoader();
			loader.update();
		},

		stopUpdater: function() {
			this.updaterRunning = false;
		},
		
		getCurrentTimeSec: function() {
			return Math.floor( (new Date() - 0) / 1000.0 );
		},
		
		// Update moving data
		
		parseUpdaterContent: function(targetLayer, rawContent) {
			
			if (!rawContent) { return false; }
			if (rawContent.indexOf(',') < 0) { return false; }
			
			var lines = rawContent.split(/\n+/);
			var n = lines.length;
			var added_count = 0;
			for (var i = 0;i < n;++i) {
				if (this.parseUpdaterRow(targetLayer, lines[i], i)) {
					++added_count;
				}
			}
			
			console.log(n , 'fetched', '   added='+added_count);
		},
		
		parseUpdaterRow: function(targetLayer, line, lineNumber) {
			var fields = line.split(/ *, */);
			var newRecord = targetLayer.getLoader().parseMovingObjectFields(
				targetLayer.attributeList,
				fields,
				lineNumber
			);
			
			// Update max time
			if (newRecord.time > this.maxRecordTime) {
				this.maxRecordTime = newRecord.time;
			}
			
			return targetLayer.movingData.rtRegister(newRecord);
		},
		
		findLayerForLoader: function(loader) {
			var ll = this.getLayerList();

			if (ll) {
				var n = ll.count();
				for (var i = 0;i < n;++i) {
					var layer = ll.getAt(i);
					if (layer.getLoader() === loader) {
						return layer;
					}
				}
			}

			return null;
		}
	};

	// base classes
	mobmap.installBaseMethods(  LiveMovingDataLoadController.prototype, mobmap.AppOwnedBase  );

	pkg.LiveMovingDataLoadController = LiveMovingDataLoadController;
});