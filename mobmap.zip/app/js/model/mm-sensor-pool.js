mmDefineModule(function(pkg) {
	'use strict';

	function MMSensorPool() {
		this.list = [];
	}
	
	// <><> Event types <><>
	MMSensorPool.Events = {
		ItemAdded: 'mm-sensor-pool-item-added-event',
		ItemRemoved: 'mm-sensor-pool-item-removed-event',
		ItemHighlightRequired: 'mm-sensor-pool-item-highlight-event'
	};
	
	MMSensorPool.prototype = {
		findBySeqId: function(seqId) {
			var ls = this.list;
			for (var i = 0;i < ls.length;++i) {
				if (ls[i].seqId === seqId) {
					return ls[i];
				}
			}
			
			return null;
		},

		count: function() {
			return this.list.length;
		},

		getAt: function(i) {
			return this.list[i] || null;
		},

		add: function(newSensor, suppress_event, beforeGroup) {
			var existing = this.findBySeqId(newSensor.seqId);
			if ( existing ) {
				return existing;
			}
			
			if (!beforeGroup) {
				this.list.push(newSensor);
			} else {
				this.insertBeforeGroup(newSensor);
			}
			
			newSensor.setOwnerPool(this);
			if (!suppress_event) {
				this.fire(MMSensorPool.Events.ItemAdded, [this, newSensor]);
			}
			
			newSensor.setParentEventDispatcher( this.eventDispatcher() );
			return newSensor;
		},

		insertBeforeGroup: function(newItem) {
			var gi = this.findFirstGroupIndex();

			if (gi < 0) {
				this.list.push(newItem);
			} else {
				this.list.splice(gi, 0, newItem);
			}
		},

		findFirstGroupIndex: function() {
			var ls = this.list;
			var len = ls.length;

			for (var i = 0;i < len;++i) {
				var s = ls[i];
				if (s.type === mobmap.LandSensorTypes.Group) {
					return i;
				}
			}
			
			return -1;
		},

		remove: function(sensorItem, suppress_event) {
			var idx = this.list.indexOf(sensorItem);
			if (idx >= 0) {
				this.list.splice(idx, 1);
				if (!suppress_event) {
					this.fire(MMSensorPool.Events.ItemRemoved, [this, sensorItem]);
				}
				
				this.bulkCall('findAndRemoveGroupItem', sensorItem);
			}
		},

		bulkCall: function(methodName, arg1,arg2) {
			var ls = this.list;
			var len = ls.length;

			for (var i = 0;i < len;++i) {
				var s = ls[i];
				if (s[methodName]) {
					s[methodName](arg1, arg2);
				}
			}
		},

		getItemAfter: function(item) {
			var ls = this.list;
			var len = ls.length;

			for (var i = 0;i < len;++i) {
				var s = ls[i];
				if (s === item) {
					if (i < (len-1)) {
						return ls[i+1];
					} else {
						return null;
					}
				}
			}
			
			return null;
		},
		
		fireHighlight: function(itemId, state) {
			var item = this.findBySeqId(itemId);
			if (item) {
				this.fire(MMSensorPool.Events.ItemHighlightRequired, [item, state]);
			}
		},
		
		
		serialize: function() {
			var sobj = [];
			var ls = this.list;
			var len = ls.length;

			for (var i = 0;i < len;++i) {
				var s = ls[i];
				sobj.push( s.serialize() );
			}
			
			return sobj;
		}
	};

	// base classes
	mobmap.installBaseMethods(  MMSensorPool.prototype, mobmap.PseudoEventNodeBase  );

	// export
	pkg.MMSensorPool = MMSensorPool;
});
