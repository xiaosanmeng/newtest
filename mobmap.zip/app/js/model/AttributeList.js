mmDefineModule(function(pkg) {
	'use strict';

	function AttributeList() {
		this.list = [];
		this.colMap = {};
	}

	AttributeList.isRequiredAttribute = function(name) {
		return kRequiredMovingObjectAttributeQuickMap.hasOwnProperty(name);
	};

	AttributeList.parseHeaderLine = function(fields, callback) {
		var n = fields.length;
		for (var i = 0;i < n;++i) {
			var name = fields[i];
			if (name.toLowerCase() === 'lat') { name = 'y'; }
			if (name.toLowerCase() === 'lng' || 
				name.toLowerCase() === 'lon'   ) { name = 'x'; }
			
			var req = AttributeList.isRequiredAttribute(name);
			if (req) {
				callback(name, null, i);
			} else {
				// todo: add extra column
				var nameAndType = mobmap.CSVPreviewTable.splitAdditionalAttributeNameAndType(name);
				callback(nameAndType.name , nameAndType.type , i);
			}
		}
	};

	AttributeList.prototype = {
		add: function(name, valueType, csvColumnIndex) {
			if (this.indexOfName(name) >= 0) {
				return null;
			}
			
			var a = new AttributeInfo(name, valueType, csvColumnIndex);
			this.list.push(a);
			
			this.rebuildColumnIndexMap();
			return a;
		},

		calcMaxCSVColumnIndex: function() {
			throw "IMPL HERE!";
		},

		indexOfName: function(name) {
			var ls = this.list;
			for (var i = 0;i < ls.length;++i) {
				if (ls[i].name === name) {
					return i;
				}
			}
			
			return -1;
		},
		
		rebuildColumnIndexMap: function() {
			deleteAllProperties(this.colMap);

			var ls = this.list;
			for (var i = 0;i < ls.length;++i) {
				var a = ls[i];
				if (a.csvColumnIndex >= 0) {
					this.colMap[ a.csvColumnIndex ] = a;
				}
			}
		},
		
		setColumnIndexByName: function(name, columnIndex) {
			var i = this.indexOfName(name);
			if (i < 0) { return false; }
			
			this.list[i].csvColumnIndex = columnIndex;
			this.rebuildColumnIndexMap();
			return true;
		},

		convertToColumnType: function(columnIndex, rawValue, writeTarget) {
			var a = this.colMap[columnIndex];
			if (a) {
				var result = convertFromStringToColumnType(rawValue, a.type);
				if (writeTarget) {
					writeTarget[ a.name ] = result;
				}

				return result;
			}
		},

		eachAttribute: function(callback) {
			var ls = this.list;
			for (var i = 0;i < ls.length;++i) {
				callback(ls[i]);
			}
		},

		eachAdditionalAttribute: function(callback) {
			var ls = this.list;
			var len = ls.length;
			
			for (var i = 0;i < len;++i) {
				var item = ls[i];
				if ( !(AttributeList.isRequiredAttribute( item.name )) ) {
					callback(item);
				}
			}
		}
	};


	function AttributeInfo(name, valueType, csvColumnIndex) {
		this.name = name;
		this.type = valueType;
		this.csvColumnIndex = csvColumnIndex;
	}
	
	// Converter

	function convertFromStringToColumnType(rawStr, dataType) {
		switch(dataType) {
		case AttributeType.INTEGER:
			return parseInt(rawStr, 10); break;

		case AttributeType.FLOAT:
		case AttributeType.CFLOAT:
			return parseFloat(rawStr); break;

		case AttributeType.DATETIME:
			return parseFieldTime(rawStr); break;
		}
		
		return rawStr;
	}

	// Parse utils
	function parseFieldTime(rawVal) {
		var absTime = 0;
		
		if (rawVal.indexOf(':') >= 0) {
			var dateIndex    = readFieldDate(rawVal);
			var secondsInDay = readFieldHMSTime(rawVal);
			
			absTime = dateIndex + secondsInDay;
		} else {
			absTime = parseInt(rawVal, 10);
		}
		
		return absTime;
	}
	
	function readFieldDate(rawVal) {
		if (kDateRegExp.exec(rawVal)) {
			// Has date ------------------------
			var yr = parseInt( RegExp['$1'] , 10);
			var mn = parseInt( RegExp['$2'] , 10);
			var dy = parseInt( RegExp['$3'] , 10);
			
			//                    v zero-base
			var dt = new Date(yr,   mn - 1  , dy);
			return Math.floor(dt.getTime() / 1000);
		} else {
			// No date -------------------------
			return 0;
		}
	}
	
	function readFieldHMSTime(rawVal) {
		var hh, mm, ss;
		ss = 0;
		
		if (kTimeRegExp.exec(rawVal)) {
			hh = parseInt(RegExp['$1'], 10);
			mm = parseInt(RegExp['$2'], 10);
			
			// Second(:SS) is optional
			var s_raw = RegExp['$4'];
			ss = s_raw ? parseInt(s_raw, 10) : 0;
		}
		
		return hh*3600 + mm*60 + ss;
	}

	pkg.parseFieldTime = parseFieldTime;
	pkg.AttributeList = AttributeList;
});