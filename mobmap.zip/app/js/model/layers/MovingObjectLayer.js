mmDefineModule(function(pkg) {
	'use strict';

	function MovingObjectLayer() {
		// Turbo polyline
		this.tp_count_cache = -1;
		this.tp_tempRecord = null;
		this.tp_sel_list   = [];
		this.mdataOffset = 0;
		
		// Event timeline
		this.eventTimeline = null;
		this.etlUpdater = null;
		
		// trajectory options
		this.trajectoryDefaultColor = '#37d';
		this.trajectoryDefaultOpacity = 1.0;
		this.trajectoryUseMarkerColor = false;
		this.trajectoryAddComposition = false;
		this.trajectoryLimitDistance   = 0;
		this.trajectoryLimitTimePeriod = 0;
		this.trajectoryLineStyle = kTrajLineStyle_Normal;
		
		this.initBaseProperties();
		this.enableSelectionEvent();
		this.autoLoad = false;
		this.remainSides = true;
		this.movingData = new mobmap.MovingData();
		this.localSelectionPool = new mobmap.SelectionPool(this);
		this._pickPoolForSelection = null;
		
		var markerGen = new mobmap.MarkerGenerator(document);
		this.markerOption = new mobmap.MarkerOptionModelProxy(markerGen, this);

		this.attributeList = new mobmap.AttributeList();
		this.addDefaultAttributes();
		
		this.markerOption.setParentEventDispatcher( this.eventDispatcher() );
		this.localSelectionPool.setParentEventDispatcher( this.eventDispatcher() );
	}
	
	var _params_array_tmp = [null,null];
	var _mmcolor_tmp = new MMColor();
	MovingObjectLayer.prototype = {
		addDefaultAttributes: function() {
			var src = kRequiredMovingObjectAttributes;
			for (var i = 0;i < src.length;++i) {
				this.addAttribute(src[i].name, src[i].type, i);
			}
		},
		
		addAttribute: function(name, valueType, csvColumnIndex) {
			this.attributeList.add(name, valueType, csvColumnIndex);
			
			if (!( mobmap.AttributeList.isRequiredAttribute(name) )) {
				console.log("Add: ", name );
				this.movingData.addExtraProperty(name, valueType === AttributeType.CFLOAT);
			}
		},
		
		addAttributeAfterLoad: function(name, valType) {
			if (!this.movingData) { return false;}
			if (this.attributeList.indexOfName(name) >= 0) { return false; }
	
			var emptyVal = 0;
			if (valType ===  AttributeType.STRING) {
				emptyVal = '';
			}

			if (this.movingData.addAttributeAfterLoad(name, (valType === AttributeType.CFLOAT), kInitialValueTypeEmpty, emptyVal, valType )) {
				if (this.attributeList) {
					this.attributeList.add(name, valType);
				}

				this.fire(mobmap.LayerEvent.DataSchemaChange, this);
			}

			return true;
		},

		applyColumnMapping: function(columnMapping) {
			for (var i in columnMapping) if (columnMapping.hasOwnProperty(i)) {
				var coli = columnMapping[i];
				this.attributeList.setColumnIndexByName(i, coli);
			}
		},

		setExistingAttributeColumnIndex: function(name, colIndex) {
			this.attributeList.setColumnIndexByName(name, colIndex);
		},

		enableAutoLoad: function() {
			this.autoLoad = true;
		},

		getDetailDescriptionForLayerType: function() {
			var n = this.movingData.countIds();
			if (n < 2) {
				return n + ' moving object';
			} else {
				return n + ' moving objects';
			}
		},

		setTailEnabled: function(b) {
			this.markerOption.setTailEnabled(b);
		},

		setMarkerColorBoundAttribute: function(attrName) {
			this.markerOption.setMarkerColorBoundAttribute(attrName);
		},

		mapAttributeToMarkerIndex: function(rawValue) {
			if (rawValue < 0) { return 0; }
			var mo = this.markerOption.options;

			// Scale value (if needed)
			var sc = mo.indexScaling;
			if (sc > 1) {
				rawValue = Math.floor(rawValue / sc);
			}

			return Math.min(rawValue, mo.numOfMarkers-1);
		},

		getMarkerIndexForRecord: function(rec) {
			if (!rec) { return null; }
			
			var boundAttrName = this.getMarkerOption().getMarkerColorBoundAttribute();
			var markerIndex = 0;

			if (boundAttrName !== null) {
				markerIndex = this.mapAttributeToMarkerIndex( rec[boundAttrName] );
			}

			return markerIndex;
		},
		
		getRemainOutsideRecords: function() {
			return this.remainSides;
		},
		setRemainOutsideRecords: function(b) {
			if (b !== this.remainSides) {
				this.movingData.setRemainSidesMode(b);
				this.remainSides = b;
				
				this.fire(mobmap.LayerEvent.DataFetchChange, this);
			}
		},

		// > > > Loader listeners < < <
		
		csvloaderOnReaderLoadEnd: function(loader) {
			if (this.autoLoad) {
				this.startFullLoad();
			} else {
				this.fire(mobmap.LayerEvent.FullLoadReady, this);
			}
		},
		
		csvloaderReadHeaderLine: function(fieldsArray) {
			var that = this;
			mobmap.AttributeList.parseHeaderLine(fieldsArray, function(name, type, columnIndex) {
				if (type === null) {
					// required attribute
					that.attributeList.setColumnIndexByName(name, columnIndex);
				} else {
					// extra attribute
					that.addAttribute(name, type, columnIndex);
				}
			});
		},

		csvloaderReadLine: function(loader, fieldsArray, lineNumber) {
			var newRecord = this.loader.parseMovingObjectFields(this.attributeList, fieldsArray, lineNumber);
			this.ldAddRecord(newRecord);
		},

		csvloaderLoadFinish: function(loader) {
			this.ldFinish();
		},
		
		// internal - - - -
		ldAddRecord: function(newRecord) {
			this.updateDateTimeRange(newRecord.time);
			this.movingData.register(newRecord);
		},
		
		ldFinish: function() {
			this.movingData.close();
			this.markDataReady();
			
			this.fire(mobmap.LayerEvent.DataTimeRangeChange, this);
			this.fire(mobmap.LayerEvent.LoadFinish, this);
		},
		
		// - - - - - -- - - -
		
		csvloaderReportProgress: mobmap.layerReportLoadingProgress,

		csvloaderReadSchema: function(loader, schemaSource) {
			var len = schemaSource.length;
			for (var i = 0;i < len;++i) {
				var entry = schemaSource[i];
				
				var coli = -1;
				if (entry.hasOwnProperty('column')) {
					coli = parseInt(entry.column, 10);
				}

				// Pickup type
				var type_name = 'string';
				var type_i    = AttributeType.STRING;
				if (entry.hasOwnProperty('type')) {
					type_name = entry.type.toLowerCase();
				}
				
				if (AttributeTypeNameMap.hasOwnProperty(type_name)) {
					type_i = AttributeTypeNameMap[type_name];
				}
				
				console.log(coli, type_name, type_i);
			}
		},

		startFullLoad: function() {
			var loader = this.getLoader();
			if (loader) {
				this.invalidateDateTimeRange();

				this.ldFireWillStart();
				loader.fullLoad();
			}
		},
		
		ldFireWillStart: function() {
			this.fire(mobmap.LayerEvent.FullLoadWillStart, this);
		},
		
		dispose: function() {
			
		},
		
		ensurePickPoolForSelection: function() {
			if (!this._pickPoolForSelection) {
				this._pickPoolForSelection = this.movingData.createPickPool();
			}
			
			return this._pickPoolForSelection;
		},

		setTrajectoryDefaultColor: function(c, opacity) {
			if (this.trajectoryDefaultColor !== c || !isNumbersNear(this.trajectoryDefaultOpacity, opacity)) {
				this.trajectoryDefaultColor = c;
				this.trajectoryDefaultOpacity = opacity;
				this.fire( mobmap.LayerEvent.TrajectoryColorChange, this );
			}
		},
		
		setTrajectoryUseMarkerColor: function(enabled) {
			if (this.trajectoryUseMarkerColor !== enabled) {
				this.trajectoryUseMarkerColor = enabled;
				this.fire( mobmap.LayerEvent.TrajectoryColorChange, this );
			}
		},

		setTrajectoryAddComposition: function(enabled) {
			if (this.trajectoryAddComposition !== enabled) {
				this.trajectoryAddComposition = enabled;
				this.fire( mobmap.LayerEvent.TrajectoryColorChange, this );
			}
		},
		
		setTrajectoryLineStyle: function(s) {
			if (this.trajectoryLineStyle !== s) {
				this.trajectoryLineStyle = s;
				this.fire( mobmap.LayerEvent.TrajectoryStyleChange, this );
			}
		},
		
		setTrajectoryLimitDistance: function(d) {
			if (this.trajectoryLimitDistance !== d) {
				this.trajectoryLimitDistance = d;
				this.fire( mobmap.LayerEvent.TrajectoryColorChange, this );
			}
		},
		
		setTrajectoryLimitTimePeriod: function(t) {
			if (this.trajectoryLimitTimePeriod !== t) {
				this.trajectoryLimitTimePeriod = t;
				this.fire( mobmap.LayerEvent.TrajectoryColorChange, this );
			}
		},

		onSelfSelectionChange: function() {
			// ETL is NOT up-to-date anymore
			this.etlInvalidate();
		},

		// Polyline datasource API - - - - - - - - - - - - - - - - - - - - - - - -

		tpCountPolylines: function() {
			if (this.tp_count_cache < 0) {
				this.tp_count_cache = this.movingData.countIds()
			}
			
			return this.tp_count_cache;
		},
		
		tpCountVerticesOfPolyline: function(polylineIndex) {
			var md = this.movingData;
			if (!md) { return 0;}
			
			var tls = md.getFlattenTLArray();
			return tls[polylineIndex].countTrajectoryVertices();
		},
		
		tpGetVertexLatitude: function(polylineIndex, vertexIndex) {
			var tls = this.movingData.getFlattenTLArray();

			var rc = tls[polylineIndex].getTrajectoryVertexAt(vertexIndex);			
			return rc ? rc.y : null;
		},

		tpGetVertexLongitude: function(polylineIndex, vertexIndex) {
			var tls = this.movingData.getFlattenTLArray();

			var rc = tls[polylineIndex].getTrajectoryVertexAt(vertexIndex);			
			return rc ? rc.x : null;
		},

		tpGetVertexTimestamp: function(polylineIndex, vertexIndex) {
			var tls = this.movingData.getFlattenTLArray();
			return this.mdataOffset + Math.floor( tls[polylineIndex].getTrajectoryVertexAttributeAt(vertexIndex, 'time', null) );

//			return recs[vertexIndex]._time + this.mdataOffset;
		},

		tpGetOwnerObjectId: function(polylineIndex) {
			var tls = this.movingData.getFlattenTLArray();

			return tls[polylineIndex].stringId;
		},

		tpGetMarkerBoundColor: function(objId, stopIndex) {
			var tl = this.movingData.getTimeListOfId(objId);
			if (!tl) { return null; }

			var nVertices = tl.countTrajectoryVertices();
			if (stopIndex < 0 || stopIndex >= nVertices) { return null; }

			if (!this.tp_tempRecord) {
				this.tp_tempRecord = mobmap.MovingData.createEmptyRecord();
			}
			tl.writeTrajectoryVertexAttributes(this.tp_tempRecord, stopIndex, this.movingData.extraProps);

			var markerIndex = this.getMarkerIndexForRecord(this.tp_tempRecord);

			return this.getMarkerOption().getMarkerGenerator().pickCSSColorByIndex(_mmcolor_tmp, markerIndex);
		},
		
		tpGetSelectedIDList: function() {
			if (!this.localSelectionPool.isAnySelected()) {
				return null;
			}
			
			this.tp_sel_list.length = 0;
			this.localSelectionPool.pushIDsToArray( this.tp_sel_list );
			return this.tp_sel_list;
		},
		
		// EVENT TIMELINE --------------
		ensureEventTimeline: function() {
			if (!this.eventTimeline) {
				this.eventTimeline = new mobmap.EventTimeline();
				this.etlUpdater = new ETLUpdater(this, this.eventTimeline);
			}
			
			return this.eventTimeline;
		},

		etlInvalidate: function() {
			var etl = this.ensureEventTimeline();
			etl.clean();
		},
		
		etlRunFill: function() {
			var md = this.movingData;
			var idmap = md.getIdMap();
			
			var selp = this.getSelectionPool();
			if (selp.isAnySelected()) {
				idmap = selp.idmap;
			}

			this.etlUpdater.fromIDMap(idmap);
			this.etlUpdater.run();
		},

		etlSync: function() {
			var etl = this.ensureEventTimeline();
			if (etl.contentDirty) {
				etl.setRemainEnabled( etl.configuration.shouldRemainValues() );
				this.etlRunFill();
			}

			return etl;
		}
	};
	
	// Event timeline updater
	function ETLUpdater(ownerLayer, etl) {
		this.running = false;
		this.sender = ownerLayer;
		this.movingData = ownerLayer.movingData;
		this.eventTimeline = etl;
		this.idList = [];

		this.async_proc = this.processNext.bind(this);

		this.numEntire = 0;
		this.numFinished = 0;
	}
	
	var EMODE_RECS = 0;
	var EMODE_ATTR = 1;
	ETLUpdater.prototype = {
		run: function() {
			if (this.running) { return; }
			this.running = true;
			this.processNext();
		},
		
		processNext: function() {
			if (!this.running) { return false; }

			// Choose type
			var mode = EMODE_RECS;
			var attrName = null;
			if ( this.eventTimeline.configuration.shouldUseAttribute() ) {
				mode = EMODE_ATTR;
				attrName = this.eventTimeline.configuration.targetAttribute;
			} 
			
			var remain = false;
			// Check limit
			var lim = this.eventTimeline.configuration.numLimit;
			if (lim && this.idList.length > lim) {
				// abort
			} else {
				for (var i = 0;i < 400;++i) {
					if (this.idList.length > 0) {
						var nextId = this.idList.shift();
						this.fillById(nextId, mode, attrName);
						++this.numFinished;
					
						remain = true;
					} else {
						break;
					}
				}
			}
			
			if (remain) {
				var entire = this.numEntire;
				if (entire < 1) { entire=1; }
				
				this.eventTimeline.invalidateCache();
				this.eventTimeline.setContentCompleteFlag(true, this.numFinished / entire);
				this.sender.fire( mobmap.LayerEvent.EventTimelineProgress );
				setTimeout(this.async_proc, 7);
			} else {
				this.eventTimeline.markContentUpdated();
				this.eventTimeline.setContentCompleteFlag(false);
				this.sender.fire( mobmap.LayerEvent.EventTimelineReady );
				this.running = false;
			}
			
			return remain;
		},
		
		fromIDMap: function(m) {
			var ls = this.idList;
			ls.length = 0;

			for (var i in m) {
				if (Object.prototype.hasOwnProperty.call(m, i)) {
					ls.push(i);
				}
			}

			this.numEntire = ls.length;
			this.numFinished = 0;

			return ls;
		},
		
		// DATA FILL
		fillById: function(pid, fillMode, attrName) {
			var tl = this.movingData.getTimeListOfId(pid);
			this.addAttributeValuesOfTL(pid, tl, attrName, this.movingData.extraProps);
		},

		addAttributeValuesOfTL: function(pid, tl, attrName, xprops) {
			if (tl) {
				var n = tl.countTrajectoryVertices();
				for (var i = 0;i < n;++i) {
					var time = tl.getTrajectoryVertexAttributeAt(i, 'time', null);
					if (time !== null) {
						if (attrName) {
							// Use attr-value
							var attrVal = tl.getTrajectoryVertexAttributeAt(i, attrName, xprops);
							this.eventTimeline.addValue(time, attrVal, pid);
						} else {
							// Simply count up
							this.eventTimeline.addValue(time, 1, pid);
						}
					}
				}
			}
		}
	};

	// base classes
	mobmap.installBaseMethods(  MovingObjectLayer.prototype, mobmap.PseudoEventNodeBase  );
	mobmap.installBaseMethods(  MovingObjectLayer.prototype, mobmap.LayerBase  );

	pkg.MovingObjectLayer = MovingObjectLayer;
});
