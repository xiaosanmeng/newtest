mmDefineModule(function(pkg) {
	'use strict';

	var LayerBase = {
		initBaseProperties: function(layerType) {
			this.layerId = mobmap.layerGetNextId();
			this.loader = null;
			this.shortDescription = null;
			this.ownerList = null;
			this.initialSettings = null;
			this.markerOption = null;
			this.localSelectionPool = null;
			this.dataTimeRange = {
				min: 0, max: -1
			};

			this.visible = true;
			this.dataReady = false;
			this.type = layerType || LayerType.MovingObject;
			
			this._list_view = null; // Associeted view for layer List
			this._map_view  = null; // Associeted view for the map
			this._live_data = null; // Internal information for live mode
		},

		getInMapContent: function() {
			if (this.initialSettings) {
				return this.initialSettings.getInMapContent();
			}
			return null;
		},
		
		setLiveModeData: function(d) { this._live_data = d; },
		getLiveModeData: function(d) { return this._live_data; },

		isSelectable: function() { return !!(this.localSelectionPool); },
		getSelectionPool: function() { return this.localSelectionPool; },

		getInitialSettings: function() { return this.initialSettings; },
		setInitialSettings: function(options) {
			this.initialSettings = new mobmap.SavedLayerSettings(options);
		},

		applyInitialSettings: function() {
			if (this.initialSettings) {
				this.initialSettings.applyToLayer(this);
				this.fire(LayerEvent.InitialSettingsApplied, this);
			}
		},

		getDesiredMapType: function() {
			if (this.initialSettings) {
				return this.initialSettings.getMapType();
			}
			
			return null;
		},


		getMarkerOption: function() {
			// maybe null (i.e this layer is a grid)
			
			return this.markerOption || null;
		},

		getOwnerProject: function() {
			if (!this.ownerList) { return null; }
			return this.ownerList.ownerProject;
		},

		getOwnerList: function() { return this.ownerList; },
		setOwnerList: function(layerList) { this.ownerList = layerList; },

		setLoader: function(loader) {
			this.loader = loader;
		},
		
		getLoader: function() {
			return this.loader;
		},
		
		setShortDescription: function(t) {
			this.shortDescription = t;
		},
		
		getShortDescription: function() {
			if (this.shortDescription) {
				return this.shortDescription;
			}
			
			if (!this.loader) {
				return 'No source';
			}
			
			return this.loader.getSourceDescription();
		},

		markDataReady: function() {
			this.dataReady = true;
		},

		getDetailDescription: function() {
			if (this.getDetailDescriptionForLayerType) {
				return this.getDetailDescriptionForLayerType();
			} else {
				return 'Details N/A';
			}
		},
		
		// time range operation
		invalidateDateTimeRange: function() {
			this.dataTimeRange.min = Number.POSITIVE_INFINITY;
			this.dataTimeRange.max = Number.NEGATIVE_INFINITY;
		},
		
		updateDateTimeRange: function(newTime, autoFire) {
			var d = this.dataTimeRange;
			d.min = Math.min( d.min, newTime );
			d.max = Math.max( d.max, newTime );
			
			if (autoFire) {
				this.fire(mobmap.LayerEvent.DataTimeRangeChange, this);
			}
		},
		
		getVisibility: function() {
			return this.visible;
		},
		
		setVisibility: function(newValue) {
			this.visible = newValue;
			this.fire(LayerEvent.VisibilityChange, this);
			return this.visible;
		},
		
		getEventTimeline: function() {
			if (this.ensureEventTimeline) {
				return this.ensureEventTimeline();
			}
			return null;
		},
		
		enableSelectionEvent: function() {
			if (this.onSelfSelectionChange) {
				this.eventDispatcher().bind(
					mobmap.SelectionPool.CHANGE_EVENT ,
					this.onSelfSelectionChange.bind(this)
				);
			}
		}
	};

	var LayerEvent = {
		FullLoadReady:        'mm-layer-model-event-full-load-ready',
		FullLoadWillStart:    'mm-layer-model-event-full-load-will-start',
		BodyLoadStarted:      'mm-layer-model-event-body-load-started',
		LoadProgressChange:   'mm-layer-model-event-load-progress-change',
		LoadFinish:           'mm-layer-model-event-load-progress-finish',
		LoadError:            'mm-layer-model-event-load-error',
		DataFetchChange:      'mm-layer-model-event-data-fetch-change',
		DataTimeRangeChange:  'mm-layer-model-event-data-time-range-change',
		WillBeRemoved:        'mm-layer-model-event-will-be-removed',
		VisibilityChange:     'mm-layer-model-event-visibility-change',
		TrajectoryColorChange:'mm-layer-model-event-trajectory-color-change',
		TrajectoryStyleChange:'mm-layer-model-event-trajectory-style-change',
		GridAppearanceChange: 'mm-layer-model-event-grid-appearance-change',
		DataSchemaChange:     'mm-layer-model-event-data-schema-change',
		EventTimelineProgress:   'mm-layer-model-event-event-timeline-progress',
		EventTimelineReady:   'mm-layer-model-event-event-timeline-ready',
		EventTimelineConfigChange: 'mm-layer-model-event-event-timeline-config',
		InitialSettingsApplied:'mm-layer-model-event-initial-setting-applied',
		MO_PickedAndReadyToRender: 'mm-layer-model-event-mo-ready-to-render'
	};
	
	var LayerType = {
		MovingObject: 'moving-object',
		Grid: 'grid'
	};

	var gLayerNextId = 1;
	pkg.layerGetNextId = function() {
		var i = gLayerNextId++;
		return i;
	};
	
	var _params_array_tmp = [null,null];
	pkg.layerReportLoadingProgress = function(loader, lineno) {
		var ratio = lineno;
		if (loader) {
			var n = loader.countLines();
			if (n < 1) {++n;}
			ratio /= n;
		}
		
		_params_array_tmp[0] = this;
		_params_array_tmp[1] = ratio;
		this.fire(mobmap.LayerEvent.LoadProgressChange, _params_array_tmp);
	};
	
	pkg.LayerEvent = LayerEvent;
	pkg.LayerBase  = LayerBase;
	pkg.LayerType  = LayerType;
});
