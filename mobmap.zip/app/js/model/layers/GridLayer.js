mmDefineModule(function(pkg) {
	'use strict';

	function GridLayer() {
		this.initBaseProperties(mobmap.LayerType.Grid);
		this.rawMetadataLines = [];
		this.gridOptions = {
			type: GridLayer.Types.Unknown,
			code: GridLayer.MeshCode.None,
			meshLevel: 1,
			definition: {
				originLat: 30,
				originLng: 130,
				stepLat: 0.01,
				stepLng: 0.01
			}
		};
		
		this.renderOptions = {
			showLabel: false,
			valueMax: 5000,
			spacing: false,
			colorList: new mobmap.GridColorList()
		};

		this.tempRecord = {};
		this.attributeList = new mobmap.AttributeList();
		this.data = new mobmap.MeshData();
		
		// initial coloring
		this.renderOptions.colorList.generateHueWheel(1);
	}

	GridLayer.Types = {
		Unknown:   -1,
		Static:     0,
		Dynamic:    1,
		NewAPIGrid: 2
	};

	GridLayer.MeshCode = {
		None: 0,
		Japan: 1
	};

	GridLayer.prototype = {
		// Render option setters
		setShowLabel: function(b) {
			if (this.renderOptions.showLabel !== b) {
				this.renderOptions.showLabel = b;
				this.fire(mobmap.LayerEvent.GridAppearanceChange, this);
			}
		},
		
		getShowLabel: function() {
			return this.renderOptions.showLabel;
		},
		
		setRenderValueMax: function(m) {
			if (m !== this.renderOptions.valueMax) {
				this.renderOptions.valueMax = m;
				this.fire(mobmap.LayerEvent.GridAppearanceChange, this);
			}
		},
		
		getRenderValueMax: function() {
			return this.renderOptions.valueMax;
		},

		setSpacingEnabled: function(s) {
			if (this.renderOptions.spacing !== s) {
				this.renderOptions.spacing = s;
				this.fire(mobmap.LayerEvent.GridAppearanceChange, this);
			}
		},

		getSpacingEnabled: function() {
			return this.renderOptions.spacing;
		},

		setColorList: function(source) {
			this.renderOptions.colorList.copyFrom(source);
			this.fire(mobmap.LayerEvent.GridAppearanceChange, this);
		},

		getColorList: function() {
			return this.renderOptions.colorList;
		},


		startFullLoad: function() {
			var loader = this.getLoader();
			if (loader) {
				this.invalidateDateTimeRange();
				
				this.fire(mobmap.LayerEvent.FullLoadWillStart, this);
				loader.fullLoad();
			}
		},
		
		dispose: function() {
			
		},

		getDetailDescriptionForLayerType: function() {
			if (!this.data) {
				return 'Grid';
			} else {
				return 'Grid (' + this.data.getNumOfCells() + ' cells)';
			}
		},

		calcColumnFromLng: function(lng) {
			var d = this.gridOptions.definition;
			return Math.floor( (lng - d.originLng) / d.stepLng );
		},
		
		calcRowFromLat: function(lat) {
			var d = this.gridOptions.definition;
			return Math.floor( (lat - d.originLat) / d.stepLat );
		},
		
		calcCellCenterLng: function(cx) {
			var d = this.gridOptions.definition;
			return d.originLng + (cx + 0.5) * d.stepLng;
		},
		
		calcCellCenterLat: function(cy) {
			var d = this.gridOptions.definition;
			return d.originLat + (cy + 0.5) * d.stepLat;
		},

		// > > > Empty grid generator < < <
		generateDynamicGrid: function(options) {
			if (options.hasOwnProperty('originLat') && 
			    options.hasOwnProperty('originLng') &&
			    options.hasOwnProperty('latStep') &&
			    options.hasOwnProperty('lngStep') && 
			    options.hasOwnProperty('cols') && 
			    options.hasOwnProperty('rows') ) {
				
				
				
				this.configureManually(options);
				this.generateGridOnTime(options.cols, options.rows, 0);
				this.csvloaderLoadFinish(null);
			} else {
				throw "Missing parameters";
			}
		},
		
		generateGridOnTime: function(cols, rows, t, fillVal) {
			var x, y;
			if (!fillVal) { fillVal = 0; }

			for (y = 0;y < rows;++y) {
				for (x = 0;x < cols;++x) {
					//if (x===70 || x === 3){ this.data.register(t, y, x, 2222); } else
					this.data.register(t, y, x, fillVal);
				}
			}
		},

		incrementCellValue: function(seconds, latIndex, lngIndex) {
			this.data.incrementCellValue(seconds, latIndex, lngIndex);
		},

		// > > > Loader listeners < < <
		
		csvloaderOnReaderLoadEnd: function(loader) {
			this.startFullLoad();
		},

		csvloaderReadLine: function(loader, fieldsArray, lineNumber) {
			// ++ New API only ++
			this.checkBodyLinesStart(fieldsArray);
			
			if (loader.getPhase() === mobmap.GridCSVLoader.PHASE_META) {
				this.parserReadMetaFields(fieldsArray);
			} else {
				if (this.gridOptions.type === GridLayer.Types.NewAPIGrid) {
					this.newAPIParserReadBodyFields(fieldsArray);
				} else {
					this.parserReadBodyFields(fieldsArray);
				}
			}
		},

		csvloaderLoadFinish: function(loader) {
			this.data.close();
			if (this.gridOptions.type === GridLayer.Types.Dynamic) {
				this.fire(mobmap.LayerEvent.DataTimeRangeChange, this);
			}
			this.fire(mobmap.LayerEvent.LoadFinish, this);
		},
		
		csvloaderReportProgress: mobmap.layerReportLoadingProgress,

		checkBodyLinesStart: function(fields) {
			if (this.gridOptions.type !== GridLayer.Types.NewAPIGrid) { return false; }
			
			if (fields[0] && fields[0].indexOf('@') === 0) {
				return false;
			}
			
			// body line
			this.parserFinishMeta();
			return true;
		},

		// Parser - - - - - - - - - - - - - - - -
		parserReadBodyFields: function(fields) {
			var latI, lngI, cellName = null;
			var latIndexCol = 0;
			var lngIndexCol = 1;
			var valueCol    = 2;
			var seconds = 0;
			
			if (this.gridOptions.type === GridLayer.Types.Dynamic) {
				var rawT = fields[0];
				seconds = mobmap.parseFieldTime(rawT);
				
				++latIndexCol;
				++lngIndexCol;
				++valueCol;
				
				// Update time range of this layer
				this.updateDateTimeRange(seconds);
			}

			if (this.gridOptions.code !== GridLayer.MeshCode.Japan) {
				latI = parseInt( fields[latIndexCol] , 10);
				lngI = parseInt( fields[lngIndexCol] , 10);
			} else {
				// Mesh-code mode
				var meshCode = parseInt( fields[latIndexCol] , 10);
				var meshLv = this.gridOptions.meshLevel;
				latI = mobmap.JapanMeshCodeDecoder.calcLatIndexFromMeshCode(meshCode, meshLv);
				lngI = mobmap.JapanMeshCodeDecoder.calcLngIndexFromMeshCode(meshCode, meshLv);
				--valueCol;

				cellName = meshCode;
			}

			var val  = parseFloat( fields[valueCol] );
			this.data.register(seconds, latI, lngI, val, cellName);
		},

		parserReadMetaFields: function(fields) {
			if (fields.length < 1) { return; }

			this.rawMetadataLines.push(fields.join(','));

			var firstCol = fields[0];
			if (firstCol.indexOf('@') === 0) {
				this.parserDoMetaCommands(fields);
			} else {
				this.parserReadMeshDefinitionFields(fields);
				this.parserFinishMeta();
			}

			console.log(this.gridOptions);
		},
		
		parserDoMetaCommands: function(fields) {
			var lw = fields[0].toLowerCase();

			if (lw.indexOf('use-mesh-code') >= 0) {
				// @use-mesh-code,[Level]
				this.initJapanMeshCodeMode(fields[1] ? parseInt(fields[1], 10) : 1);
				this.parserFinishMeta();

			} else if (lw.indexOf('dynamic-mesh') >= 0) {
				// @dynamic-mesh
				this.gridOptions.type = GridLayer.Types.Dynamic;

			} else if (lw.indexOf('static-mesh') >= 0) {
				// @static-mesh
				this.gridOptions.type = GridLayer.Types.Static;

			} else {
				this.newAPIParserDoMetaCommands(lw, fields);
			}
		},

		// ++ New API ++
		newAPIParserDoMetaCommands: function(firstCol, allFields) {
			switch(firstCol) {
			case '@grid':
				this.gridOptions.type = GridLayer.Types.NewAPIGrid;
				return true; break;
			case '@japan_mesh_code':
				var meshLevel = parseInt(allFields[1], 10);
				this.initJapanMeshCodeMode(meshLevel);
				return true; break;
			case '@columns':
				this.newAPIReadColumnSettings(allFields);
				return true; break;
			}
			
			return false;
		},

		newAPIReadColumnSettings: function(fields) {
			var n = fields.length;
			// START FROM 1
			for (var i = 1;i < n;++i) {
				var nameAndType = mobmap.CSVPreviewTable.splitAdditionalAttributeNameAndType( fields[i] );
				this.attributeList.add(nameAndType.name, nameAndType.type, i-1); 
			}
		},
		
		newAPIParserReadBodyFields: function(fields) {
			var i;
			var tmp = this.tempRecord;

			// Erase
			for (i in tmp) if (tmp.hasOwnProperty(i)) {
				delete tmp[i];
			}

			// Parse columns
			for (i = 0;i < fields.length;++i) {
				this.attributeList.convertToColumnType(i, fields[i], tmp);
			}
			
			// Send
			var grid_opt = this.gridOptions;
			if (grid_opt.code === GridLayer.MeshCode.Japan) {
				var meshLv = grid_opt.meshLevel;
				var secRecordTime = 0;
				var latI = mobmap.JapanMeshCodeDecoder.calcLatIndexFromMeshCode(tmp.cell, meshLv);
				var lngI = mobmap.JapanMeshCodeDecoder.calcLngIndexFromMeshCode(tmp.cell, meshLv);

				this.data.register(secRecordTime, latI, lngI, tmp.value);
			}
		},

		initJapanMeshCodeMode: function(lv) {
			this.gridOptions.code = GridLayer.MeshCode.Japan;
			this.gridOptions.meshLevel = lv;
			
			var df = this.gridOptions.definition;
			df.originLat = 0;
			df.originLng = 100;
			
			mobmap.JapanMeshCodeDecoder.setCellStep(df, lv);
		},

		parserReadMeshDefinitionFields: function(fields) {
			var df = this.gridOptions.definition;
			
			df.originLat = parseFloat( fields[0] );
			df.originLng = parseFloat( fields[1] );
			df.stepLat   = parseFloat( fields[2] );
			df.stepLng   = parseFloat( fields[3] );
		},
		
		configureManually: function(options) {
			var df = this.gridOptions.definition;

			df.originLat = options.originLat;
			df.originLng = options.originLng;
			df.stepLat   = options.latStep;
			df.stepLng   = options.lngStep;
			
			this.sendDefinition();
		},
		
		parserFinishMeta: function() {
			this.getLoader().finishMetaLines();
			this.sendDefinition();
		},
		
		sendDefinition: function() {
			this.data.dynamic = (this.gridOptions.type === GridLayer.Types.Dynamic);
			
			var src = this.gridOptions.definition;
			this.data.meshDefinition = {};
			for (var i in src) if (src.hasOwnProperty(i)) {
				this.data.meshDefinition[i] = src[i];
			}
		},
		
		setAutoValueMax: function() {
			var m = 1;
			if (this.data) {
				m = this.data.valueRange.max;
			}
			
			this.setRenderValueMax(m);
		},
		
		etlInvalidate: function() {
			
		}
	};


	// base classes
	mobmap.installBaseMethods(  GridLayer.prototype, mobmap.PseudoEventNodeBase  );
	mobmap.installBaseMethods(  GridLayer.prototype, mobmap.LayerBase  );

	pkg.GridLayer = GridLayer;
});
