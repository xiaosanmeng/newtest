mmDefineModule(function(pkg) {
	'use strict';

	function MMProject() {
		this.landSensorPool = null;
		this.layerList = null;

		this.activeLayerIds = [];

		this.currentDateTime = new mobmap.DateTime();
		this.initLayerList();
		this.initLandSensorPool();
		
		this.currentDateTime.setParentEventDispatcher( this.eventDispatcher() );
	}
	
	MMProject.Events = {
		LAYER_SELECTED: 'mm-layer-selected-event'
	};
	
	MMProject.prototype = {
		initLayerList: function() {
			this.layerList = new mobmap.MMLayerList(this);
			this.layerList.setParentEventDispatcher( this.eventDispatcher() );
		},
		
		initLandSensorPool: function() {
			this.landSensorPool = new mobmap.MMSensorPool();
			this.landSensorPool.setParentEventDispatcher( this.eventDispatcher() );
		},

		getLandSensorPool: function() {
			return this.landSensorPool;
		},

		getLandSensorById: function(sid) {
			return this.getLandSensorPool().findBySeqId(sid);
		},

		addLandSensor: function(sensorType, initialLat, initialLng, lat2, lng2) {
			// Calc initial lat/lng scale
			var mapPane = this.getOwnerApp().getMapPane();
			var bounds = mapPane.getGoogleMaps().getBounds();		
			var lngSpan = bounds.getNorthEast().lng() -  bounds.getSouthWest().lng();
			var latSpan = bounds.getNorthEast().lat() -  bounds.getSouthWest().lat();

			var sensor = null;
			if (lat2 !== undefined && lng2 !== undefined) {
				sensor = mobmap.createLandSensorInstance(sensorType, initialLat, initialLng, lat2, lng2, true); 
			} else {
				sensor = mobmap.createLandSensorInstance(sensorType, initialLat, initialLng, latSpan, lngSpan, false); 
			}

			this.landSensorPool.add(sensor, false, sensorType !== mobmap.LandSensorTypes.Group);
			return sensor;
		},
		
		getLayerList: function() {
			return this.layerList;
		},
		
		calcMinTimeAmongAllLayers: function() {
			return this.layerList.calcMinMaxTime('min');
		},
		
		calcMaxTimeAmongAllLayers: function() {
			return this.layerList.calcMinMaxTime('max');
		},
		
		// Layer selection API
		lyrselSelectOne: function(layerId) {
			var cur = this.lyrselGetFirstId();
			if (this.lyrselGetCount() === 1 && cur === layerId) {
				return false;
			}
			
			this.activeLayerIds.length = 0; // clear
			this.activeLayerIds.push(layerId);
			
			this.fire( MMProject.Events.LAYER_SELECTED, this );
			
			return true;
		},
		
		lyrselGetCount: function() {
			return this.activeLayerIds.length;
		},
		
		lyrselGetFirstId: function() {
			if ( this.lyrselGetCount() < 1 ) {
				return null;
			}
			
			return this.activeLayerIds[0];
		},

		lyrselEach: function(callback) {
			var ls = this.getLayerList();
			
			var n = this.lyrselGetCount();
			for (var i = 0;i < n;++i) {
				var layer_id = this.activeLayerIds[i];
				var lyr = ls.findById(layer_id);

				callback(lyr);
			}
		},

		removeLayer: function(layer) {
			var ll = this.getLayerList();
			ll.removeItem(layer);
		},
		
		countMovingObjectLayers: function() {
			return this.getLayerList().countWithType( mobmap.LayerType.MovingObject );
		}
	};

	// base classes
	mobmap.installBaseMethods(  MMProject.prototype, mobmap.AppOwnedBase  );
	mobmap.installBaseMethods(  MMProject.prototype, mobmap.PseudoEventNodeBase  );

	pkg.MMProject = MMProject;
});
