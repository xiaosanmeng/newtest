mmDefineModule(function(pkg) {
	'use strict';
	var gNextSensorSeqId = 1;

	// --- Land sensor
	function MMLandSensor(initialLat, initialLng, importSource) {
		this.seqId = importSource ? importSource.id : MMLandSensor.feedNextId();
		 this._view = null; // slot for view manager object
		 this._lv_view = null; // slot for list view
		this.visible = true;
		
		this.vertexList = [];
		this.direction = mobmap.GMapDirectionIcon.FWD | mobmap.GMapDirectionIcon.BACK;

		this.g_geometory = null;
		
		this.subGroups = null;
		this.center = new MMLatLng(initialLat, initialLng);
		this.title = importSource ? importSource.title : 'Unknown';
		
		this.type = importSource ? importSource.type : LandSensorTypes.LineGate;
		this.ownerPool = null;
		
		if (importSource) {
			this.importProperties(importSource);
		}
	}
	
	MMLandSensor.feedNextId = function() {
		return gNextSensorSeqId++;
	};

	// <><> Event types <><>
	MMLandSensor.Events = {
		VertexChanged: 'mm-land-sensor-vertex-change-event',
		VertexAdded:   'mm-land-sensor-vertex-add-event',
		VertexRemoved: 'mm-land-sensor-vertex-remove-event',
		GateDirectionChanged: 'mm-land-sensor-direction-change-event',
		
		GroupItemAdded: 'mm-sensor-group-item-add-event',
		GroupItemRemoved: 'mm-sensor-group-item-remove-event',
		
		TitleChanged: 'mm-land-sensor-title-change-event',
		AppearanceChanged: 'mm-land-sensor-appearance-change-event',
		
		ViewFormChangeRequired: 'mm-land-sensor-view-form-change-required',
		RemoveRequest: 'mm-land-sensor-remove-request'
	};

	MMLandSensor.prototype = {
		getId: function() {
			return this.seqId;
		},

		getTitle: function() {
			return this.title;
		},
		
		setTitle: function(newValue) {
			if (this.title !== newValue) {
				this.title = newValue;
				this.fire(MMLandSensor.Events.TitleChanged, [this, newValue]);
			}
		},

		getVisibility: function() {
			return this.visible;
		},
		
		setVisibility: function(v) {
			if (this.visible === v) {
				return v;
			}
			
			this.visible = v;
			this.fire(MMLandSensor.Events.AppearanceChanged, [this, v]);
			return v;
		},

		setOwnerPool: function(p) {
			this.ownerPool = p;
		},

		importProperties: function(src) {
			if (src.vertexList) {
				this.copyArrayProperty(this.vertexList, src.vertexList);
			}
			
			if (src.hasOwnProperty('direction')) {
				this.importDirectionFlags(src);
			}
		},

		importDirectionFlags: function(src) {
			this.direction = src.direction;
		},

		copyArrayProperty: function(dest, src) {
			for (var i in src) if (src.hasOwnProperty(i)) {
				dest.push( src[i] );
			}
		},

		initLineGateWithEnds: function(lat1, lng1, lat2, lng2) {
			this.type = LandSensorTypes.LineGate;
			this.title = 'LGate_' + this.seqId;
			this.center.lat = (lat1 + lat2) / 2.0;
			this.center.lng = (lng1 + lng2) / 2.0;

			this.vertexList.length = 2;
			this.vertexList[0] = new MMLatLng(lat1, lng1);
			this.vertexList[1] = new MMLatLng(lat2, lng2);
			
			this.updateGoogleMapsGeometories();
		},
		
		initLineGateWithSpan: function(latSpan, lngSpan) {
			this.type = LandSensorTypes.LineGate;
			this.title = 'LGate_' + this.seqId;
			var c = this.center;

			this.vertexList.length = 2;
			this.vertexList[0] = new MMLatLng(c.lat + latSpan*0.5, c.lng - lngSpan*0.5);
			this.vertexList[1] = new MMLatLng(c.lat - latSpan*0.5, c.lng + lngSpan*0.5);

			this.updateGoogleMapsGeometories();
		},

		initPolygonGateWithSpan: function(latSpan, lngSpan) {
			this.type = LandSensorTypes.PolygonGate;
			this.title = 'PGate_' + this.seqId;
			var c = this.center;
			
			this.vertexList.length = 4;
			this.vertexList[0] = new MMLatLng(c.lat + latSpan*0.5, c.lng - lngSpan*0.5);
			this.vertexList[1] = new MMLatLng(c.lat + latSpan*0.5, c.lng + lngSpan*0.5);
			this.vertexList[2] = new MMLatLng(c.lat - latSpan*0.5, c.lng + lngSpan*0.5);
			this.vertexList[3] = new MMLatLng(c.lat - latSpan*0.5, c.lng - lngSpan*0.5);
			
			this.updateGoogleMapsGeometories();
		},
		
		initAsGroup: function() {
			this.type = LandSensorTypes.Group;
			this.title = 'Group_' + this.seqId;
			this.initSubGroupList();
		},
		

		getVertexAt: function(i) {
			return this.vertexList[i] || null;
		},

		getVertexCount: function() {
			return this.vertexList.length;
		},

		setVertexPositionAt: function(i, lat, lng) {
			var v = this.getVertexAt(i);
			if (v) {
				if (!isNumbersNear(v.lat, lat) || !isNumbersNear(v.lng, lng)) {
					v.lat = lat;
					v.lng = lng;
					this.updateGoogleMapsGeometories();
					this.fire(MMLandSensor.Events.VertexChanged, this);
				}
			}
		},
		
		insertVertexAfter: function(prevIndex) {
			var oldLen = this.getVertexCount();
			if (prevIndex < 0) { prevIndex = 0; }
			if (prevIndex >= oldLen) { prevIndex = oldLen-1; }

			var vPrev = this.getVertexAt(prevIndex);
			var vNext = this.getVertexAt( (prevIndex+1) % oldLen );
			
			var mLat = 0.5 * (vPrev.lat + vNext.lat);
			var mLng = 0.5 * (vPrev.lng + vNext.lng);

			this.insertVertexWithLatLng(prevIndex, mLat, mLng);
		},
		
		insertVertexWithLatLng: function(insertAfter, lat, lng) {
			this.vertexList.splice(insertAfter+1, 0, new MMLatLng(lat, lng));
			this.updateGoogleMapsGeometories();
			this.fire(MMLandSensor.Events.VertexAdded, [this, insertAfter]);
		},
		
		removeVertexAt: function(index) {
			this.vertexList.splice(index, 1);
			this.updateGoogleMapsGeometories();
			this.fire(MMLandSensor.Events.VertexRemoved, [this, index]);
		},
		
		removeSelf: function() {
			this.ownerPool.remove(this);
		},

		requestRemove: function() {
			this.fire(MMLandSensor.Events.RemoveRequest, this);
		},

		setDirection: function(d) {
			if (this.direction !== d) {
				this.direction = d;
				this.fire(MMLandSensor.Events.GateDirectionChanged, [this, d]);
			}
		},

		getDirection: function() {
			return this.direction;
		},

		serialize: function() {
			var serializedObj = {
				"id": this.getId(),
				"type": this.type,
				"title": this.title
			};
			
			if (this.type === LandSensorTypes.LineGate) {
				serializedObj.direction = this.direction;
			}
			
			if (this.type === LandSensorTypes.Group) {
				serializedObj.subGroup = this.serializeSubGroups();
			} else {
				serializedObj.vertexList = this.vertexList;
			}

			return serializedObj;
		},
		
		updateGoogleMapsGeometories: function() {
			if (!this.g_geometory) {
				this.g_geometory = this.generateGoogleMapsGeometoryObject();
			}
			
			if (this.g_geometory) {
				this.g_geometory.setPath(this.vertexList);
			}
		},
		
		generateGoogleMapsGeometoryObject: function() {
			if (this.type === LandSensorTypes.PolygonGate) {
				return new google.maps.Polygon();
			} else if (this.type === LandSensorTypes.LineGate) {
				// return google.maps.
			}
			
			return null;
		},
		
		getGoogleMapsGeometory: function() {
			return this.g_geometory;
		}
	};
	
	// Group functions
	MMLandSensor.prototype.initSubGroupList = function() {
		var ls = [ [], [], [], [], [], [] ];
		this.subGroups = ls;
	};
	
	MMLandSensor.prototype.countSubGroup = function() {
		return this.subGroups.length;
	};

	MMLandSensor.prototype.getSubGroupAt = function(i) {
		return this.subGroups[i] || null;
	};

	MMLandSensor.prototype.addGroupItem = function(item, subGroupIndex) {
		var subs = this.subGroups;
		if (subGroupIndex < 0 || subGroupIndex >= subs.length) {
			return false;
		}

		if (subs[subGroupIndex].indexOf(item) >= 0) {
			return false;
		}

		this.findAndRemoveGroupItem(item);

		subs[subGroupIndex].push(item);
		this.fire(MMLandSensor.Events.GroupItemAdded, [this, subGroupIndex, item]);

		return true;
	};
	
	MMLandSensor.prototype.findAndRemoveGroupItem = function(item) {
		var subs = this.subGroups;
		for (var i in subs) if (subs.hasOwnProperty(i)) {
			var subI = subs[i].indexOf(item);
			if (subI >= 0) {
				subs[i].splice(subI, 1);
				this.fire(MMLandSensor.Events.GroupItemRemoved, [this, i-0, item]);
			}
		}
	};
	
	MMLandSensor.prototype.serializeSubGroups = function() {
		var ret = {
			"idList": []
		};
		
		if (this._lv_view && this._lv_view.getCurrentFormName) {
			ret["form"] = this._lv_view.getCurrentFormName();
		}
		
		var subs = this.subGroups;
		for (var i in subs) if (subs.hasOwnProperty(i)) {
			var subG = subs[i];
			var slen = subG.length;
			
			var subList = [];
			for (var j = 0;j < slen;++j) {
				subList.push( subG[j].getId() );
			}
			ret.idList.push( subList );
		}
		
		return ret;
	};
	
	MMLandSensor.prototype.requestChangeViewForm = function(name) {
		this.fire( MMLandSensor.Events.ViewFormChangeRequired, [this, name] );
	};

	var LandSensorTypes = {
		LineGate: 'line-gate',
		PolygonGate: 'polygon-gate',
		Group: 'group'
	};

	pkg.LandSensorTypes = LandSensorTypes;
	pkg.createLandSensorInstance = function(sensorType, arg1, arg2, mapLatSpan, mapLngSpan, withEnds) {
		switch(sensorType) {

		case LandSensorTypes.LineGate:
			var lg = new MMLandSensor(arg1, arg2);
			if (withEnds) {
				lg.initLineGateWithEnds(arg1, arg2, mapLatSpan, mapLngSpan);
			} else {
				lg.initLineGateWithSpan(mapLatSpan * 0.1, mapLngSpan * 0.1);
			}
			return lg; break;
			
		case LandSensorTypes.PolygonGate:
			var pg = new MMLandSensor(arg1, arg2);
			pg.initPolygonGateWithSpan(mapLatSpan * 0.1, mapLngSpan * 0.1);
			return pg; break;

		case LandSensorTypes.Group:
			var gr = new MMLandSensor(arg1, arg2);
			gr.initAsGroup();
			return gr; break;
		}
		
		return null;
	};
	
	
	// base classes
	mobmap.installBaseMethods(  MMLandSensor.prototype, mobmap.PseudoEventNodeBase  );

	// export
	pkg.MMLandSensor = MMLandSensor;
});
