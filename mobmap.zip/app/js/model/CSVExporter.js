mmDefineModule(function(pkg) {
	'use strict';
	
	var _tmp_fields = [];
	
	function MOLayerCSVExporter(targetLayer, columnNameList, headerEnabled) {
		this.columnNameList = columnNameList;
		this.headerEnabled = headerEnabled;
		
		this.chunkSize = 50;
		this.idList = [];
		this.recordBuffer = [];
		this.targetLayer = targetLayer;
		this.listener = null;

		// job info
		this.numDone = 0;
		this.numAll  = 0;

		var selPool = targetLayer.getSelectionPool();
		this.fillIDList(selPool);

		this.advanceClosure = this.advance.bind(this);
	}
	
	MOLayerCSVExporter.prototype = {
		fillIDList: function(selPool) {
			this.idList.length = 0;
			
			if (selPool) {
				selPool.addToArray(this.idList);
				this.numAll = this.idList.length;
			}
		},
		
		start: function(listener) {
			this.recordBuffer.length = 0;

			this.listener = listener;
			setTimeout(this.advanceClosure, 20);
		},
		
		advance: function() {
			var i;
			
			for (i = 0;i < this.chunkSize;++i) {
				if (this.numDone >= this.numAll) { break; }
				var IDtoExport = this.idList[ this.numDone ];
				this.exportId(IDtoExport);
				
				++this.numDone;
			}
			
			var all_done = (this.numDone >= this.numAll);
			if (!all_done) {
				if (this.listener && this.listener.progress) {
					// Report progress
					this.listener.progress( this.numDone / this.numAll );
				}

				setTimeout(this.advanceClosure, 20);
			} else {
				this.finish();
			}
		},

		exportId: function(pid) {
			var md = this.targetLayer.movingData;
			var tl = md.getTimeListOfId(pid);

			var r_list = tl.getRecordList();
			var n = r_list.length;
			
			for (var i = 0;i < n;++i) {
				var rec = r_list[i];
				this.recordBuffer.push([rec, this.generateCSVLine(rec) ]);
			}
			
		},

		finish: function() {
console.log('sorting...');
			this.sortRecordBuffer();
console.log('done');
			
			if (this.listener && this.listener.complete) {
				this.listener.complete( this.toBlob() );
			}
		},

		generateHeaderLine: function() {
			return this.columnNameList.join(',') + '\n';
		},

		generateCSVLine: function(rec) {
			var n = this.columnNameList.length;
			var a = _tmp_fields;
			a.length = n;
			
			for (var i = 0;i < n;++i) {
				var attrName = this.columnNameList[i];
				a[i] = (attrName === 'time') ? formatDateTime(rec[ attrName ]) : rec[ attrName ];
			}
			
			return a.join(',') + '\n';
		},

		sortRecordBuffer: function() {
			this.recordBuffer.sort(function(a,b) {
				return a[0].time - b[0].time;
			});
		},
		
		toBlob: function() {
			var s_empty = '';
			var s_newl  = '\n';
			var ls = this.recordBuffer;
			var n = ls.length;

			for (var i = 0;i < n;++i) {
				var ent = ls[i];
				ent.shift();
			}
			
			if (this.headerEnabled) {
				// Add header (at first line)
				ls.unshift( this.generateHeaderLine() );
			}
			
			return new Blob(ls, {type: 'text/plain'});
		}
	};

	function formatDateTime(rawT) {
		return kendo.toString(new Date(rawT * 1000.0), "yyyy-MM-dd HH:mm:ss");
	}


	// export
	pkg.MOLayerCSVExporter = MOLayerCSVExporter;
});