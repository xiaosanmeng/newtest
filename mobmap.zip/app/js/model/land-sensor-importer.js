mmDefineModule(function(pkg) {
	'use strict';

	function LandSensorFileImporter(targetProject) {
		this.targetProject  = targetProject;

		this.fileForm = document.createElement('input');
		this.fileForm.type = 'file'
		this.fileForm.setAttribute('accept', 'application/json');
		this.jFileForm = $(this.fileForm).change( this.onFileChange.bind(this) );
		
		this.contentImporter = null;
	}

	LandSensorFileImporter.prototype = {
		openFileDialog: function() {
			this.jFileForm.click();
		},

		onFileChange: function() {
			var f = this.fileForm.files;
			if (f && f.length > 0 && f[0]) {
				this.readFileAsString(f[0], this.afterFileRead.bind(this));
			}
		},
		
		readFileAsString: function(file, callback) {
			var reader = new FileReader();
			reader.onload = callback;

			reader.readAsText(file);
		},
		
		afterFileRead: function(e) {
			var j = null;

			try {
				j = JSON.parse(e.target.result);
			} catch(err) {
				// fail
				console.log(err);
			}
			
			if (j) {
				this.contentImporter = new LandSensorImporter(this.targetProject, j);
				this.contentImporter.load();
			}
		}
	};


	function LandSensorImporter(targetProject, sourceObject) {
		this.targetProject = targetProject;
		this.sourceObject = sourceObject;
	}

	LandSensorImporter.prototype = {
		load: function() {
			this.reassignIDs();
			this.calcInitialLatLng( this.sourceObject );
			
			var src = this.sourceObject;
			var spool = this.targetProject.getLandSensorPool();
			for (var i in src) if (src.hasOwnProperty(i)) {
				var o = src[i];
				var s = new mobmap.MMLandSensor(o.initialLocation.lat, o.initialLocation.lng, o);
				
				spool.add(s);
			}
			
			this.configureGroupObjects(spool, src);
		},
		
		configureGroupObjects: function(spool, src) {
			for (var i in src) if (src.hasOwnProperty(i)) {
				var o = src[i];
				if (o.type === mobmap.LandSensorTypes.Group && o.subGroup) {
					var importedSensor = spool.findBySeqId(o.id);
					if (importedSensor) {
						importedSensor.initSubGroupList();
						importedSensor.requestChangeViewForm(o.subGroup.form);
					
						var sl = o.subGroup.idList;
						for (var i in sl) if (sl.hasOwnProperty(i)) {
							this.addSubgroupItems(spool, importedSensor, i - 0, sl[i]);
						}
					}
				}
			}
		},

		addSubgroupItems: function(spool, target, subGroupIndex, srcList) {
			var len = srcList.length;
			for (var i = 0;i < len;++i) {
				var sid = srcList[i];
				var s = spool.findBySeqId(sid);
				if (s) {
					target.addGroupItem(s, subGroupIndex);
				}
			}
		},

		calcInitialLatLng: function(src) {
			for (var i in src) if (src.hasOwnProperty(i)) {
				var o = src[i];
				var latSum = 0;
				var lngSum = 0;
				if (o.vertexList) {
					
					var len = o.vertexList.length;
					for (var j = 0;j < len;++j) {
						latSum += o.vertexList[j].lat;
						lngSum += o.vertexList[j].lng;
					}
					
					latSum /= len;
					lngSum /= len;
				}
				
				o.initialLocation = {
					lat: latSum, lng: lngSum
				};
			}
		},

		reassignIDs: function() {
			var old_new_map = {};
			
			var src = this.sourceObject;
			for (var i in src) if (src.hasOwnProperty(i)) {
				var o = src[i];
				if (! old_new_map.hasOwnProperty(o.id) ) {
					var newId = mobmap.MMLandSensor.feedNextId();
					old_new_map[ o.id ] = newId;
					
					o.id = newId;
				}
			}
			
			this.rewriteReferenceIDs(old_new_map);
		},
		
		rewriteReferenceIDs: function(old_new_map) {
			var src = this.sourceObject;
			for (var i in src) if (src.hasOwnProperty(i)) {
				var o = src[i];

				if (o.subGroup && o.subGroup.idList) {
					var nSubs = o.subGroup.idList.length;
					for (var j = 0;j < nSubs;++j) {
						var subList = o.subGroup.idList[j];
						this.rewriteIdInList(subList, old_new_map);
					}
				}
			}
		},
		
		rewriteIdInList: function(list, old_new_map) {
			var len = list.length;
			for (var i = 0;i < len;++i) {
				var oldVal = list[i];
				if (old_new_map.hasOwnProperty( oldVal )) {
					list[i] = old_new_map[oldVal];
				}
			}
		}
	};

	// export
	pkg.LandSensorFileImporter = LandSensorFileImporter;
	pkg.LandSensorImporter = LandSensorImporter;
});