mmDefineModule(function(pkg) {
	'use strict';

	function SavedLayerSettings(options) {
		this.options = options;
	}
	
	SavedLayerSettings.prototype = {
		applyToLayer: function(targetLayer) {
			var changed = false;
			
			var o = this.options;
			if (!o) { return; }
			
			var mo = targetLayer.getMarkerOption();
			if (mo) {

				if (o.numOfMarkers) {
					mo.setNumOfMarkers(o.numOfMarkers);
					changed = true;
				}

				if (o.boundAttribute) {
					mo.setMarkerColorBoundAttribute(o.boundAttribute);
					changed = true;
				}

				if (o.coloring) {
					if (o.coloring.preset) {
						mo.setMarkerSetPresetReversed(o.coloring.preset, !!o.coloring.reversed);
						mo.loadMarkerSetPreset(o.coloring.preset);
					}
				}
				
				var cmp = o.composition;
				if (cmp) {
					mo.setAddCompositionEnabled(true);
				}
				
				var asz = o.autoSizing;
				if (asz) {
					mo.setMarkerAutoSizing(asz);
				}

			}
		},

		getMarkerColorPreset: function() {
			if (this.options && this.options.coloring) {
				return this.options.coloring.preset || null;
			}
			
			return null;
		},

		getMapType: function() {
			return this.options.mapType || null;
		},
		getMapZoom: function() {
			return this.options.mapZoom || null;
		},
		
		getAutoPlay: function() {
			if (this.options) { return this.options.autoPlay; }
			return null;
		},
		
		getShowClock: function() {
			if (this.options) { return this.options.showClock; }
			return false;
		},
		
		getShowGateDock: function() {
			if (this.options.hasOwnProperty('showGateDock')) {  return this.options.showGateDock;  }
			return true;
		},
		
		getInMapContent: function() {
			if (this.options) { return this.options.inMapContent || null; }
			return null;
		}
	};

	pkg.SavedLayerSettings = SavedLayerSettings;
});
