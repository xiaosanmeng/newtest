mmDefineModule(function(pkg) {
	'use strict';

	function MMLayerList(ownerProject) {
		// From bottom to top
		this.list = [];
		
		this.ownerProject = ownerProject;
	}

	MMLayerList.Event = {
		ItemAdded: 'mm-layer-list-item-added',
		ItemRemoved: 'mm-layer-list-item-removed',
		OrderSwapRequested: 'mm-layer-list-item-swap-rq',
		OrderSwapSucceeded: 'mm-layer-list-item-swap-suc'
	};

	MMLayerList.prototype = {
		add: function(lyr, toBottom, suppress_event) {
			if (this.exists(lyr)) { return null; }
			lyr.setParentEventDispatcher( this.eventDispatcher() );

			if (toBottom) {
				this.list.unshift(lyr);
			} else {
				// on top
				this.list.push(lyr);
			}

			lyr.setOwnerList(this);
			if (!suppress_event) {
				this.fire(MMLayerList.Event.ItemAdded, [this, lyr]);
			}
			
			return lyr;
		},
		
		exists: function(layerObject) {
			return (this.indexOf(layerObject) >= 0);
		},
		
		indexOf: function(layerObject) {
			return this.list.indexOf(layerObject);
		},
		
		calcMinMaxTime: function(method) {
			var rval = (method === 'min') ? 
				Number.POSITIVE_INFINITY : 
				Number.NEGATIVE_INFINITY;
			
			var ls = this.list;
			for (var i in ls) if(ls.hasOwnProperty(i)) {
				var lyr = ls[i];
				rval = Math[method]( lyr.dataTimeRange[method] );
			}
			
			return rval;
		},
		
		count: function() {
			return this.list.length;
		},
		
		getAt: function(index) {
			return this.list[index] || null;
		},
		
		findById: function(layerId) {
			var ls = this.list;
			for (var i in ls) if(ls.hasOwnProperty(i)) {
				var layer = ls[i];
				if (layer.layerId === layerId) {
					return layer;
				}
			}

			return null;
		},
		
		removeItem: function(layer) {
			var pos = this.indexOf(layer);
			if (pos >= 0) {
				layer.fire(mobmap.LayerEvent.WillBeRemoved, layer);
				layer.dispose();

				this.removeItemAt(pos);
				this.fire(MMLayerList.Event.ItemRemoved, [this, layer]);
			}
		},

		removeItemAt: function(position) {
			this.list.splice(position, 1);
		},
		
		forEach: function(proc) {
			var n = this.list.length;
			for (var i = 0;i < n;++i) {
				proc(i, this.list[i]);
			}
		},
		
		countWithType: function(t) {
			var n = 0;
			this.forEach(function(i, layer) {
				if (layer.type === t) { ++n; }
			});
			
			return n;
		},
		
		requestSwap: function(firstIndex) {
			this.fire(MMLayerList.Event.OrderSwapRequested, [this, firstIndex]);
		},
		
		swapItems: function(firstIndex) {
			var n = this.list.length;
			var i2 = firstIndex + 1;

			if (i2 >= n) { return false; }
			
			var oldLater = this.list[i2];
			this.list[i2] = this.list[firstIndex];
			this.list[firstIndex] = oldLater;

			this.fire(MMLayerList.Event.OrderSwapSucceeded, [this, firstIndex]);
			return true;
		}
	};

	// base classes
	mobmap.installBaseMethods(  MMLayerList.prototype, mobmap.PseudoEventNodeBase  );

	// export
	pkg.MMLayerList = MMLayerList;
});
