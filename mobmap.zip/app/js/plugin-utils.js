mmDefineModule(function(pkg) {
	'use strict';

	var PluginUtil = {
		InitOption: {
			OBSERVE_GROUP: 0x1,
			OBSERVE_OBJECT_SELECTION: 0x2,
			OBSERVE_LAYER_SELECTION: 0x4,
			OBSERVE_LINEGATE: 0x10,
			OBSERVE_TIMECHANGE: 0x20
		},
		
		activatePlugin: function(pluginHost, panelContainer, pluginClass, existingInstance, initOption) {
			if (!initOption) { initOption=0; }

			if (!existingInstance) {
				var pluginInstance = new pluginClass();

				// Additional initialization
				if (initOption & PluginUtil.InitOption.OBSERVE_GROUP) {
					pluginHost.observeAnalysisFeatureGroup(pluginInstance);
				}

				if (initOption & PluginUtil.InitOption.OBSERVE_LINEGATE) {
					pluginHost.observeAnalysisFeatureLineGate(pluginInstance);
				}

				if (initOption & PluginUtil.InitOption.OBSERVE_OBJECT_SELECTION) {
					pluginHost.observeObjectSelection(pluginInstance);
				}

				if (initOption & PluginUtil.InitOption.OBSERVE_LAYER_SELECTION) {
					pluginHost.observeLayerSelection(pluginInstance);
				}
				
				if (initOption & PluginUtil.InitOption.OBSERVE_TIMECHANGE) {
					pluginHost.observeTimeChange(pluginInstance);
				}

				panelContainer.appendChild( pluginInstance.getElement() );
			} else {
				pluginInstance = existingInstance;
				existingInstance.show();
			}

			return pluginInstance;
		},
		
		deactivatePlugin: function(existingInstance) {
			if (existingInstance) {
				existingInstance.hide();
			}
		},

		findSelectItemById: function(targetId, selectElement) {
			var ls = selectElement.childNodes;
			var len = ls.length;
			
			for (var i = 0;i < len;++i) {
				var el = ls[i];
				if (el.tagName) {
					var ival = parseInt(el.value, 10)
					if (ival === targetId) {
						return el;
					}
				}
			}
			
			return null;
		},

		addGroupSelectOption: function(targetSelectElement, groupItem) {
			var opt = $H('option');
			opt.appendChild( $T(groupItem.getTitle()) );
			opt.value = groupItem.seqId;
			
			targetSelectElement.appendChild(opt);
		},

		addGroupSelectOptionIf: function(selectElement, sensorPool, addedItem) {
			var iid = addedItem.seqId;
			var exist = this.findSelectItemById(iid, selectElement);
			if (!exist) {
				this.addGroupSelectOption(selectElement, addedItem);
			}
		},
		
		changeGroupSelectOptionTitleIf: function(selectElement, changedItem) {
			var el = this.findSelectItemById(changedItem.seqId, selectElement);
			if (el) {
				el.innerHTML = '';
				el.appendChild( $T( changedItem.getTitle() ) );
			}
		},
		
		createJobFromList: function(pluginHost, outJobList, gateList, finishedCallback, that, userData1) {
			var len = gateList.length;
			for (var i = 0;i < len;++i) {
				var item = gateList[i];
				var job = pluginHost.getOwnerApp().createGateSensorJob(item);
				if (job) {
					job.userData1 = userData1 || null;
					job.then( finishedCallback.bind(that, job) );
					outJobList.push(job);
				}
			}
		},

		getCurrentLayer: function(pluginHost) {
			var pj = this.getCurrentProject(pluginHost);
			if (!pj) { return null; }
			
			var layerId = pj.lyrselGetFirstId();
			if (layerId < 0) { return null; }
			
			return pj.getLayerList().findById(layerId);
		},

		getCurrentSelectionPool: function(pluginHost) {
			var pj = this.getCurrentProject(pluginHost);
			if (!pj) { return null; }
			
			var layerId = pj.lyrselGetFirstId();
			if (layerId < 0) { return null; }
			
			var layer = pj.getLayerList().findById(layerId);
			if (!layer) { return null; }
			var selp = layer.getSelectionPool();
			if (!selp) { return null; }
			
			return {
				layer: layer,
				selectionPool: selp
			};
		},

		getCurrentProject: function(pluginHost) {
			var app = pluginHost.getOwnerApp();
			if (!app) { return null; }

			return app.getCurrentProject();
		},

		getGateItemOfId: function(pluginHost, itemId) {
			var pj = this.getCurrentProject(pluginHost);
			if (!pj) { return null; }
			
			return pj.getLandSensorById(itemId);
		},

		getGroupItemOfId: function(pluginHost, groupId) {
			return this.getGateItemOfId(pluginHost, groupId);
		},

		moveJobToFinishedList: function(job, pendingList, finishedList) {
			var li = pendingList.indexOf(job);
			if (li >= 0) { pendingList.splice(li, 1); }

			finishedList.push(job);
		},
		
		startFirstJobInList: function(jobList) {
			if (jobList.length < 1) { return; }
			
			console.log("-- Start job --")
			jobList[0].start();
		},

		ClassificationColors: ['#f55', '#78f', '#292', '#fa4', '#82a'],

		createChart: function(vList) {
			var chart_width  = 160;
			var chart_height = 16;
			var area_height  = 20;
			var colors = PluginUtil.ClassificationColors;

			var i;
			var sum = 0;
			var len = vList.length;
			for (i = 0;i < len;++i) {
				sum += vList[i];
			}
			
			var cv = document.createElement('canvas');
			var g = cv.getContext('2d');
			
			cv.width = chart_width;
			cv.height = area_height;
			
			var oy = area_height - chart_height - 1;
			var x = 0;

			g.fillStyle = colors[len - 1];
			g.fillRect(0, oy, chart_width, chart_height);
			
			var partW;
			for (i = 0;i< (len-1);++i) {
				partW = chart_width * vList[i] / sum;
				g.fillStyle = colors[i];
				g.fillRect(x, oy, partW, chart_height);
				x += partW;
			}

			g.fillStyle = 'rgba(0,0,0,0.1)';
			g.fillRect(0, oy+chart_height-2, chart_width, 2);
			g.fillRect(0, oy+chart_height-1, chart_width, 1);
			
			x = 0;
			for (i = 0;i< len;++i) {
				partW = chart_width * vList[i] / sum;
				x += partW / 2;
	
				g.font = '12px';
				g.textAlign = 'center';
				g.fillStyle = '#000';
				g.fillText( String.fromCharCode(0x41 + i), x, oy + 13);
				g.fillStyle = '#fff';
				g.fillText( String.fromCharCode(0x41 + i), x, oy + 12);
				
				x += partW / 2;
			}
			
			return cv;
		},
		
		setJobSequenceIndices: function(jobList) {
			var len = jobList.length;
			for (var i = 0;i < len;++i) {
				var j = jobList[i];
				if (j.gate) { // type check
					j.partIndex  = i;
					j.partsCount = len;
				}
			}
		},

		generatePluginLargeButton: function(container, text) {
			var a = $H('button', 'mmr-big-button');
			a.appendChild($T(text));
			container.appendChild(a);
			return a;
		},

		installBaseElementMethods: function(objPrototype) {
			objPrototype.getElement = base_getElement;
			objPrototype.show       = base_show;
			objPrototype.hide       = base_hide;
			objPrototype.createElementWithTitle = base_createElementWithTitle;
		},
		
		createAnalysisItemChooser: function(pluginHost, containerElement, listener, labelText, itemType) {
			var a = new AnalysisItemGroupChooser(pluginHost, listener, labelText, itemType);
			
			if (containerElement) {
				containerElement.appendChild(a.getElement());
			}
			
			return a;
		},
		
		createAnalysisItemGroupChooser: function(pluginHost, containerElement, listener, labelText) {
			return this.createAnalysisItemChooser(pluginHost, containerElement, listener, labelText);
		},

		createLineGateChooser: function(pluginHost, containerElement, listener, labelText) {
			return this.createAnalysisItemChooser(
				pluginHost, containerElement, listener, labelText,
				mobmap.LandSensorTypes.LineGate
			);
		},
		
		createBigButton: function(labelText, containerElement) {
			var b = $H('button', 'mmr-big-button');
			b.appendChild($T(labelText));
			if (containerElement) {
				containerElement.appendChild(b);
			}
			
			return b;
		},

		kGourpFilterLine:     0x1,
		kGourpFilterPolygon:  0x2,
		kGourpFilterOptional: 0x4,

		validateGroupItems: function(pluginHost, groupId, conditions) {
			var groupObj = mobmap.PluginUtil.getGroupItemOfId(pluginHost, groupId); 
			var groupForm = pluginHost.getGroupFormById(groupId);

			var len = conditions.length;
			for (var i = 0;i < len;++i) {
				var cond = conditions[i];
				var requiredForm = cond.form;
				var subConditions = cond.conditions;
				
				var allPassed = (requiredForm === groupForm);
				
				for (var si in subConditions) if (subConditions.hasOwnProperty(si)) {
					si -= 0;
					
					var subc_flags = subConditions[si];
					var sg = groupObj.getSubGroupAt(si);

					var cond_passed = this.validateSubGroup(sg, subc_flags);
					if (!cond_passed) {
						allPassed = false;
					}
				}
				
				if (allPassed) {
					return i;
				}
			}

			return -1;
		},
		
		validateSubGroup: function(subGroupItemList, conditionFlags) {
			var U = mobmap.PluginUtil;

			var n = 0;
			if (subGroupItemList) {
				n = subGroupItemList.length;
			}

			if (n === 0 && 0 === (conditionFlags & U.kGourpFilterOptional)) {
				// at least one item is required
				return false;
			}

			for (var i = 0;i < n;++i) {
				var item = subGroupItemList[i];
				var tp = item.type;
				
				if (tp === mobmap.LandSensorTypes.Group) {
					return false;
				}
				
				if (tp === mobmap.LandSensorTypes.PolygonGate &&
					0 === (conditionFlags & U.kGourpFilterPolygon)) {
					return false;
				}

				if (tp === mobmap.LandSensorTypes.LineGate &&
					0 === (conditionFlags & U.kGourpFilterLine)) {
					return false;
				}
			}
			
			return true;
		},
		
		indexToAlphabetical: function(i) {
			return String.fromCharCode(0x41 + i);
		}
	};
	
	// UI Component =======================================
	function AnalysisItemGroupChooser(pluginHost, listener, labelText, itemType) {
		this.iteratorMethodName = (itemType === mobmap.LandSensorTypes.LineGate) ?
		                           'eachLineGate' :
		                           'eachAnalysisItemGroup';
		
		this.listener = listener || null;
		this.element = $H('div');
		this.selectElement = null;
		this.initView(pluginHost, labelText);
	}
	
	AnalysisItemGroupChooser.prototype = {
		initView: function(pluginHost, labelText) {
			var el = this.element;

			var lab = $H('label');
			lab.appendChild( $T(labelText) );
			var sel = $H('select', 'mm-plugin-group-chooser');
			lab.appendChild(sel);
			el.appendChild(lab);

			pluginHost[ this.iteratorMethodName ]( (function(groupItem, itemIndex) {
				mobmap.PluginUtil.addGroupSelectOption(sel, groupItem);
			}).bind(this) );
			
			this.selectElement = sel;
			this.validateForm();
		},
		
		getElement: function() {
			return this.element;
		},

		validateForm: function() {
			
		},

		getValue: function() {
			var v = this.selectElement.value;
			if (v && v.length > 0) {
				return v - 0;
			} else {
				return null;
			}
		},

		onGroupAdded: function(sensorPool, addedItem) {
			mobmap.PluginUtil.addGroupSelectOptionIf(this.selectElement, sensorPool, addedItem);
		},

		onGroupTitleChanged: function(changedItem) {
			mobmap.PluginUtil.changeGroupSelectOptionTitleIf(this.selectElement, changedItem);
		},
		
		onItemAdded: function(sensorPool, addedItem) {
			this.onGroupAdded(sensorPool, addedItem);
		},
		
		onItemTitleChanged: function(changedItem) {
			this.onGroupTitleChanged(changedItem);
		}
	};
	
	
	// Plugin base functions - - - - - - - - - - - - - - - -
	function base_getElement() {
		return this.element;
	}

	function base_show() {
		if (this.willShow) { this.willShow(); }
		this.element.style.display = '';
	}

	function base_hide() {
		if (this.willHide) { this.willHide(); }
		this.element.style.display = 'none';
	}

	function base_createElementWithTitle(t) {
		var el = document.createElement('div');
		var h = $H('h2', 'plugin-caption');
		
		h.appendChild($T(t));
		el.appendChild(h);
		
		return el;
	}

	pkg.PluginUtil = PluginUtil;
});
