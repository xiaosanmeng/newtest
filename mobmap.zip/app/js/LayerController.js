mmDefineModule(function(pkg) {
	'use strict';

	function LayerController() {
		this.mapPane = null;
		this._mmcolor_tmp = null;
		this.registeredLayerList = [];
	}
	
	LayerController.prototype = {
		connectModelAndView: function(mapPane, modelEventDispatcher) {
			this.mapPane = mapPane;
			this.observeMapPane(mapPane);
			this.observeModelEvents(modelEventDispatcher);
		},

		observeMapPane: function(mapPane) {
			mapPane.eventDispatcher().bind(mobmap.MapPane.NEED_OVERLAYS_RENDER_EVENT, this.onMapPaneNeedsOverlaysRender.bind(this));
		},

		observeModelEvents: function(modelEventDispatcher) {
			var E = mobmap.MMLayerList.Event;
			modelEventDispatcher.
			bind(
				E.ItemAdded,
				this.onNewLayerAdded.bind(this)
			).
			bind(
				E.ItemRemoved,
				this.onLayerRemoved.bind(this)
			).bind(
				E.OrderSwapRequested,
				this.onLayerSwapRequested.bind(this)
			).
			bind(
				mobmap.LayerEvent.VisibilityChange,
				this.onLayerVisibilityChange.bind(this)
			).
			bind(
				mobmap.LayerEvent.GridAppearanceChange,
				this.onGridAppearanceChange.bind(this)
			).
			bind(
				mobmap.SelectionPool.CHANGE_EVENT,
				this.onLayerLocalSelectionChanged.bind(this)
			).
			bind(
				mobmap.LayerEvent.LoadFinish,
				this.onLoayerLoadFinished.bind(this)
			).
			bind(
				mobmap.LayerEvent.DataFetchChange,
				this.onLoayerDataFetchChange.bind(this)
			).
			bind(
				mobmap.MarkerOptionModelProxy.CHANGE_EVENT,
				this.onLoayerMarkerOptionChanged.bind(this)
			).
			bind(
				mobmap.LayerEvent.TrajectoryColorChange,
				this.onLayerTrajectoryColorChange.bind(this)
			).bind(
				mobmap.LayerEvent.TrajectoryStyleChange,
				this.onLayerTrajectoryStyleChange.bind(this)
			).bind(
				mobmap.MMProject.Events.LAYER_SELECTED,
				this.onLayerSelected.bind(this)
			).bind(
				mobmap.LayerEvent.EventTimelineReady,
				this.onLayerEventTimelineReady.bind(this)
			).bind(
				mobmap.LayerEvent.EventTimelineProgress,
				this.onLayerEventTimelineProgress.bind(this)
			).bind(
				mobmap.LayerEvent.EventTimelineConfigChange,
				this.onLayerEventTimelineConfigChange.bind(this)
			);
		},

		onLayerSelected: function(e) {
			this.updateTimelineVizIf();
		},

		onNewLayerAdded: function(e, sender, newItem) {
			if (!this.isAlreadyRegistered(newItem)) {
				this.buildMapViewForLayer(newItem);
				this.registeredLayerList.push(newItem);
				
				// Select if this layer is the first
				var pj = this.getAppCurrentProject();
				if (pj) {
//					if (pj.lyrselGetCount() === 0) {
						pj.lyrselSelectOne(newItem.layerId);
//					}
				}
			}

			this.checkLiveLayerExists();
		},

		onLayerRemoved: function(e, sender, removedItem) {
			if (this.isAlreadyRegistered(removedItem)) {

				var pos = this.registeredLayerList.indexOf(removedItem);
				this.registeredLayerList.splice(pos, 1);

				this.destroyGMapOverlayForLayer(removedItem);
			}

			this.checkLiveLayerExists();
			this.updateTimelineVizIf();
		},
		
		checkLiveLayerExists: function() {
			var live = false;
			
			var pj = this.getAppCurrentProject();
			if (pj) {
				var ll = pj.getLayerList();
				var n = ll.count();
				for (var i = 0;i < n;++i) {
					var lyr = ll.getAt(i);
					if (lyr.getLiveModeData && lyr.getLiveModeData()) {
						live = true;
						break;
					}
				}
			}
			
			var app = this.getOwnerApp();
			app.mainUI.getToolPane().setLiveMode(live);
		},

		onLayerSwapRequested: function(e, sender, firstIndex) {
			var success = sender.swapItems(firstIndex);
			
			if (success) {
				this.reorderOverlays();
				this.redrawMap();
			}
		},

		destroyGMapOverlayForLayer: function(layer) {
			var overlay = layer._map_view;
			if (overlay) {
				overlay.willRemove();
				overlay.setMap(null);
				overlay.ownerObject = null;
			}
		},

		onLoayerLoadFinished: function(e, senderLayer) {
			this.checkLiveLayerExists();

			if (senderLayer.type === mobmap.LayerType.Grid && senderLayer._map_view) {
				senderLayer._map_view.bindData( senderLayer.data );
			}

			if (this.getAppCurrentProject().countMovingObjectLayers() === 1 && 
			    senderLayer.type === mobmap.LayerType.MovingObject) {
				this.centeringMap( senderLayer );
			}

			senderLayer.applyInitialSettings();
			this.mapPane.applyLayerDesiredSettings(senderLayer);
			this.redrawMap();
			
			// Auto action (if set)
			var app = this.getOwnerApp();
			if (app) {
				app.executeLayerInitialAction(senderLayer);
			}
			
			// Renew ETL
			senderLayer.etlInvalidate();
			this.updateTimelineVizIf();
		},
		
		onLoayerDataFetchChange: function(e, senderLayer) {
			this.redrawMap();
		},
		
		onLoayerMarkerOptionChanged: function(e, sender, affectsColor) {
			this.notifyTrajectoryColorAffected( sender.getOwnerLayer() );
			this.redrawMap();
			
			if (affectsColor) {
				this.updateInmapStyles( sender.getOwnerLayer() );
			}
		},

		updateInmapStyles: function(layer) {
			var inMapContent = layer.getInMapContent();
			if (inMapContent) {
				var app = this.getOwnerApp();
				var mp = app.getMapPane();
				var mo = layer.getMarkerOption();

				mp.clearStyleSheetRules();
				if (mo && inMapContent.markerIndices) {
					if (!this._mmcolor_tmp) {
						this._mmcolor_tmp = new MMColor();
					}
				
					for (var i = 0;i < inMapContent.markerIndices.length;++i) {
						var markerIndex = inMapContent.markerIndices[i] // marker index for legend;
						mo.getMarkerGenerator().pickColorByIndex(this._mmcolor_tmp, markerIndex);
							
						mp.addStyleSheetMarkerColorRule(markerIndex, this._mmcolor_tmp.toCSSRGBA());
					}
				}
				
				if (mo) {
					var attr = mo.getMarkerColorBoundAttribute();
					if (attr) {
						mp.addStyleSheetAttributeBoundDisplay(attr);
					}
				}
			}
		},

		buildMapViewForLayer: function(layer) {
			var tp = layer.type;
			if (tp === mobmap.LayerType.MovingObject) {
				this.buildMapViewForPointsLayer(layer);
			} else if (tp === mobmap.LayerType.Grid) {
				this.buildMapViewForGridLayer(layer);
			} else {
				console.log("[Warning] Layer cannot be displayed on the map.");
			}
		},
		
		buildMapViewForPointsLayer: function(layer) {
			var mapPane = this.mapPane;
			var gmap = mapPane.getGoogleMaps();
			
			var mapOverlay = new mobmap.GLMobLayer();
			mapOverlay.canvasReadyCallback = this.onOverlayGLReady.bind(this);
			mapOverlay.preapareDefaultMarkerPool();

			mapOverlay.setMap(gmap);
			mapOverlay.ownerObject = layer;
			layer._map_view = mapOverlay;
		},

		buildMapViewForGridLayer: function(layer) {
			var mapPane = this.mapPane;
			var gmap = mapPane.getGoogleMaps();
			
			var mapOverlay = new mobmap.MeshCanvasOverlay();
			mapOverlay.canvasReadyCallback = this.onOverlayGridCanvasReady.bind(this);
			mapOverlay.setMap(gmap);
			mapOverlay.setColorList( layer.getColorList() );
			mapOverlay.ownerObject = layer;
			layer._map_view = mapOverlay;
		},

		onOverlayGLReady: function() {
			this.reorderOverlays();
			this.redrawMap();
		},
		
		onOverlayGridCanvasReady: function() {
			this.reorderOverlays();
		},

		isAlreadyRegistered: function(layer) {
			var ls = this.registeredLayerList;
			for (var i in ls) if(ls.hasOwnProperty(i)) {
				if (ls[i] === layer) { return true; }
			}
			
			return false;
		},

		onLayerLocalSelectionChanged: function(e, senderPool) {
			this.redrawMap();
			
			this.getOwnerApp().getMapPane().notifyTrajectoryMapSelectionChange();
			this.checkETLSelectionChange(senderPool);
		},

		onLayerTrajectoryColorChange: function(e, layer) {
			this.notifyTrajectoryColorAffected(layer);
		},
		
		onLayerTrajectoryStyleChange: function(e, layer) {
			this.notifyTrajectoryColorAffected(layer);
		},

		notifyTrajectoryColorAffected: function(layer) {
			this.getOwnerApp().getMapPane().notifyTrajectoryMapColoringChange(layer);
		},

		onLayerVisibilityChange: function(e, senderLayer) {
			var mapOverlay = senderLayer._map_view;
			if (mapOverlay) {
				mapOverlay.setVisibility( senderLayer.getVisibility() );
			}
			this.redrawMap();
		},
		
		onGridAppearanceChange: function(e, senderLayer) {
			var mapOverlay = senderLayer._map_view;
			if (mapOverlay && mapOverlay.setValueLabelEnabled) {
				mapOverlay.setValueLabelEnabled( senderLayer.getShowLabel() );
				mapOverlay.setRenderValueMax( senderLayer.getRenderValueMax() );
				mapOverlay.setCellSpacing( senderLayer.getSpacingEnabled() );
			}
			this.redrawMap();
		},

		centeringMap: function( layer ) {
			var md = layer.movingData;
			if (!md) { return; }
			var tls = md.getFlattenTLArray();
			
			var mx = 0;
			var my = 0;
			var num = 0;
			
			for (var i in tls) if (tls.hasOwnProperty(i)) {
				var t = tls[i];
				if ( !(t.isEmpty()) )  {
					var recordList = t.getRecordList();
					var rec = recordList[0];
					mx += rec.x;
					my += rec.y;
					++num;
				}
			}
			
			if (num > 0) {
				mx /= num;
				my /= num;
				
				var mapPane = this.mapPane;
				if (mapPane) {
					mapPane.panTo(my, mx);
				}
			}
		},

		redrawMap: function() {
			var mapPane = this.mapPane;
			var pj = this.getAppCurrentProject();
			if (mapPane && pj) {
				mapPane.redraw(pj);
			}
		},
		
		getAppCurrentProject: function() {
			var app = this.getOwnerApp();
			if (!app) { return null; }

			return app.getCurrentProject();
		},
		
		onMapPaneNeedsOverlaysRender: function(e, senderMapPane, targetTimeSec, timeDirection) {
			var i;
			var pj = this.getAppCurrentProject();
			if (pj) {
				var ll = pj.getLayerList();
				var n  = ll.count();
				
				// Each layer
				for (i = 0;i < n;++i) {
					var layer = ll.getAt(i);
					if (layer.type === mobmap.LayerType.MovingObject) {
						this.renderMovingObjectLayer(layer, senderMapPane, targetTimeSec, timeDirection);
					} else if (layer.type === mobmap.LayerType.Grid) {
						this.renderGridLayer(layer, senderMapPane, targetTimeSec, timeDirection);
					}
				}
			}
		},
		
		renderMovingObjectLayer: function(layer, senderMapPane, targetTimeSec, timeDirection) {
			var mapOverlay = layer._map_view;
			if (!mapOverlay) { return; }

			this.updateGLOverlayTextureIfNeeded(layer, mapOverlay);
			this.updateGLOverlayCompositionMode(layer, mapOverlay);

			mapOverlay.setTimeDirection(timeDirection);
			this.fillMarkersToRender(mapOverlay, layer, targetTimeSec);
		},

		renderGridLayer: function(layer, senderMapPane, targetTimeSec, timeDirection) {
			var gridOverlay = layer._map_view;
			if (!gridOverlay) { return; }

			gridOverlay.resetRenderedRegion();
			gridOverlay.setPickTime(targetTimeSec);
			gridOverlay.render();
		},

		updateGLOverlayTextureIfNeeded: function(layer, glOverlay) {
			var mo = layer.getMarkerOption();
			var texDirty = mo.getTextureDirty(false);
			
			if (texDirty) {
				var mgen = mo.getMarkerGenerator();
				mgen.generate();
				var textureSourceImage = mgen.updateTextureCanvas();
				
				var chipWidth  = mgen.markerOuterSize;
				var chipHeight = mgen.markerOuterSize;
				var crop = true;
				
				glOverlay.setMarkerChipSize(chipWidth, chipHeight);
				if (glOverlay.setMarkerImage(textureSourceImage, crop)) {
					mo.resetTextureDirty();
				}
			}
		},

		updateGLOverlayCompositionMode: function(layer, glOverlay) {
			var mo = layer.getMarkerOption();
			glOverlay.setMarkerComposition(
				mo.isAddCompositionEnabled() ? kMarkerCompositionAdd
				                             : kMarkerCompositionNormal
			);
		},

		fillMarkersToRender: function(overlay, sourceLayer, targetTimeSec) {

			// Check moving data
			if (!sourceLayer.dataReady) { return; }
			var movingData = sourceLayer.movingData;

			var selection_pl = sourceLayer.getSelectionPool();
			var anySelected  = selection_pl.isAnySelected();
			
			var mOpt = sourceLayer.getMarkerOption();
			var mkGen = mOpt.getMarkerGenerator();
			var selonly = mOpt.getShowSelectedOnly();
			var boundAttrName = mOpt.getMarkerColorBoundAttribute();

			// Init render options
			var tailLength = 0;
			var tailInterval = mOpt.getTailDuration();
			
			if (mOpt.getTailEnabled()) {
				tailLength = 1;
			}

			// Init overlay's marker pool
			var mk_pool = overlay.getTopMarkerPool();
			mk_pool.clear();

			// Chip size may be changed. Pick here.
			var chipW = overlay.markerTextureConf.chipWidth;
			var chipH = overlay.markerTextureConf.chipHeight;

			// Get prepared pick pool (create if not ready)
			var pickPool = LayerController.ensureOverlayPickPool(overlay);

			pickPool.clear();
			movingData.pickAt(pickPool, targetTimeSec, 0, tailLength, tailInterval);
			var count = pickPool.pickedCount;

			mk_pool.begin(count);
			var src_array = pickPool.getArray();
			var m_array = mk_pool.getArray();

			for (var i = 0;i < count;++i) {
				var sourceRecord = src_array[i];
				var marker_data = m_array[i];
				var recId = sourceRecord.id;
				
				marker_data.lat = sourceRecord.y;
				marker_data.lng = sourceRecord.x;
				marker_data.chipY = 0;
				marker_data.tailLengthToRender = tailLength;

				if (selonly && anySelected) {
					if (!selection_pl.isIDSelected(recId)) {
						marker_data.chipY = -1;
						marker_data.tailLengthToRender = 0;
						continue;
					}
				}

				// Apply marker color (if attribute is bound)
				var mkIndex = 0;
				if (boundAttrName !== null) {
					var boundAttrVal = sourceRecord[boundAttrName];
					mkIndex = sourceLayer.mapAttributeToMarkerIndex(boundAttrVal);
				}
				
				marker_data.chipX = mkIndex * chipW;

				if (anySelected) {
					var this_selected = selection_pl.isIDSelected(recId);
					if (!this_selected) {
						marker_data.chipY = chipH;
					}
				}
				
				if (tailLength > 0) {
					var mcol = marker_data.ensureBaseColor();
					mkGen.pickColorByIndex(mcol, mkIndex);
					
					var tailSource = sourceRecord._tailRecords;
					var tailArray = marker_data.ensureTailArray(tailLength);
					
					for (var j = 0;j < tailLength;++j) {
						var t_mk  = tailArray[j];
						var t_src = tailSource[j];
						t_mk.lat = t_src.y;
						t_mk.lng = t_src.x;
						
						var tcol = t_mk.ensureBaseColor();
						tcol.copyFrom(mcol);
						t_mk.tailAlpha = 0;
					}
				}
			}

			sourceLayer.fire(mobmap.LayerEvent.MO_PickedAndReadyToRender, pickPool);

			overlay.setTailDrawEnabled( tailLength > 0 );
			overlay.resetRenderedRegion();
			overlay.renderGL();
			if (this.ownerApp) {
			//	this.ownerApp.notifyMovingDataPicked(sourceLayer, src_array, count);
			}
		},

		getTopLayerOverlay: function() {
			var ls = this.registeredLayerList;
			var len = ls.length;
			if (len < 1) { return null; }

			return ls[len - 1]._map_view;
		},
		
		// REORDER
		reorderOverlays: function() {
			var i, layer;
			var pj = this.getAppCurrentProject();
			if (pj) {
				var ll = pj.getLayerList();
				var containerElement = this.getOverlaysParent(ll);
				if (containerElement) {
					var removedElements = this.removeAllOverlayElements(ll);
					this.appendElementsReversed(containerElement, removedElements);
				}
			}
		},

		getOverlaysParent: function(layerList) {
			if (layerList.count() < 1) { return null; }

			var layer = layerList.getAt(0);
			if (!layer) { return null; }
			
			var v = layer._map_view;
			if (!v) { return null; }
			
			if (!( v.canvas )) { return null; }
			return v.canvas.parentNode || null;
		},
		
		removeAllOverlayElements: function(layerList) {
			var rls = [];
			
			var n = layerList.count();
			for (var i = 0;i < n;++i) {
				var layer = layerList.getAt(i);
				var v = layer._map_view;

				if (v && v.canvas && v.canvas.parentNode) {
					v.canvas.parentNode.removeChild( v.canvas );
					rls.push( v.canvas );
				}
			}
			
			return rls;
		},
		
		appendElementsReversed: function(containerElement, list) {

			var n = list.length;
			for (var i = (n-1);i >= 0;--i) {
				containerElement.appendChild(list[i]);
			}
		},
		
		// Timeline visualization controls - - - - - - - - - -
		onLayerEventTimelineProgress: function() {
			var app = this.getOwnerApp();
			app.mainUI.getToolPane().getTimelineBar().redrawBar();
		},
		
		onLayerEventTimelineReady: function() {
			this.updateTimelineVizIf();

			var app = this.getOwnerApp();
			app.mainUI.getToolPane().getTimelineBar().redrawBar();
		},

		onLayerEventTimelineConfigChange: function() {
			this.updateTimelineVizIf();
		},

		updateTimelineVizIf: function() {
			var app = this.getOwnerApp();
			var enabled = app.isTimelineVizEnabled();
			
			var etlToShow = null;
			if (enabled) {
				var layer = selectedLayerFromApp(app);
				if (layer) {
					etlToShow = layer.getEventTimeline();
					if (etlToShow) {
						layer.etlSync();
					}
				}
			}
			
			var tb = app.mainUI.getToolPane().getTimelineBar();
			tb.bindEventTimeLine(etlToShow);
		},
		
		checkETLSelectionChange: function(senderPool) {
			this.updateTimelineVizIf();
		}
	};
	
	LayerController.ensureOverlayPickPool = function(overlay) {
		if (!overlay) { return null; }

		if (!overlay._stockPickPool) {
			var movingData = overlay.ownerObject.movingData;
			overlay._stockPickPool = movingData.createPickPool();
		}
		
		return overlay._stockPickPool;
	};

	function selectedLayerFromApp(app) {
		var lyrId = app.getCurrentProject().lyrselGetFirstId();
		if (lyrId !== null) {
			return app.
			 getCurrentProject().
			 getLayerList().findById(lyrId);
		}

		return null;
	}

	// base classes
	mobmap.installBaseMethods(  LayerController.prototype, mobmap.AppOwnedBase  );

	pkg.LayerController = LayerController;
});