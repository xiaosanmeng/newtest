mmDefineModule(function(pkg) {
	'use strict';
	var kValTypeDataAttrName = 'data-attr-datatype';

	function CSVPreviewTable() {
		this.element = $H('div', 'mm-csv-preview-table-container');
		this.jElement = $(this.element);
		
		this.tableElement = $H('table', 'mm-csv-preview-table');
		this.jTableElement = $( this.tableElement );
		this.element.appendChild(this.tableElement);
		
		this.jTableElement.click( this.onTableClick.bind(this) );
		
		this.clickableRowMap = {};
		this.numOfDataColumns = 0;
		this.additionalAttrRow = null;

		mmAddEventDispatcherMethod(this, this.tableElement);
	}
	
	CSVPreviewTable.Events = {
		ColumnSettingChanged: 'mm-previewtable-column-setting-change-event'
	};

	CSVPreviewTable.prototype = {
		getElement: function() {
			return this.element;
		},

		clear: function() {
			this.clearHTML();
			this.clearClickableRowObjects();
		},

		clearHTML: function() {
			this.jTableElement.empty();
		},

		clearClickableRowObjects: function() {
			var m = this.clickableRowMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				delete m[i];
			}
		},



		addColsHeaderRow: function(numOfDataColumns) {
			this.numOfDataColumns = numOfDataColumns;

			var tbl = this.tableElement;
			var tr = $H('tr', 'mm-previewtable-chrow');

			var n = numOfDataColumns + 1;
			for (var i = 0;i < n;++i) {
				var td = $H('th');
				if (i) {
					td.appendChild( $T(i) );
				}
				
				tr.appendChild(td);
			}

			tbl.appendChild(tr);
		},

		fillDataRows: function(sourceRows, numOfColumns) {
			var tbl = this.tableElement;
			
			var len = sourceRows.length;
			for (var i = 0;i < len;++i) {
				var tr = this.createDataTRow(i + 1);
				var row = sourceRows[i];
				
				for (var j = 0;j < numOfColumns;++j) {
					var td = $H('td', 'mm-previewtable-data-cell');
					var sourceCol = row[j] || null;
					if (sourceCol) {
						td.appendChild($T(sourceCol));
					}
					
					td.setAttribute(CSVPreviewTable.DataAttrName.DataColIndex, j);
					tr.appendChild(td);
				}
				
				tbl.appendChild(tr);
			}
		},
		
		addConfigHeaderRow: function(numOfDataColumns) {
			var n = numOfDataColumns + 1;
			
			var tr = $H('tr');
			var td = $H('td', 'mm-previewtable-confighead');
			td.setAttribute('colspan', n);
			td.innerHTML = 'Configure columns';
			
			tr.appendChild(td);
			this.tableElement.appendChild(tr);
		},

		createDataTRow: function(lineIndex) {
			var tr = $H('tr', 'mm-previewtable-row-' + lineIndex);
			var td = $H('td', 'mm-previewtable-rowhead');

			td.appendChild( $T(lineIndex) );
			tr.appendChild(td);

			return tr;
		},
		
		findFirstRow: function() {
			return this.jTableElement.find('.mm-previewtable-row-1');
		},
		
		addRequiredAttributeRow: function(name, numOfDataColumns) {
			var tbl = this.tableElement;
			var tr = $H('tr', 'mm-previewtable-configrow');

			var crowObj = new ClickableConfigurationRow(name);
			this.clickableRowMap[name] = crowObj;

			var n = numOfDataColumns + 1;
			for (var i = 0;i < n;++i) {
				var td;
				if (i === 0) {
					td = $H('td', 'mm-previewtable-attr-rowhead mm-previewtable-attrname-' + name);
					td.appendChild( $T(name) );
					
					var acolor = CSVPreviewTable.AttrIndicatorColors[name];
					if (acolor) {
						td.style.background = makeHeadColGradient(acolor);
					}
				} else {
					td = $H('td');
					
					td.setAttribute(CSVPreviewTable.DataAttrName.SelAttrName, name);
					td.setAttribute(CSVPreviewTable.DataAttrName.SelColIndex, i-1);
					
					crowObj.addTableCell(td);
				}
				
				tr.appendChild(td);
			}
			
			tbl.appendChild(tr);
		},

		addAdditionalAttributeRow: function(numOfDataColumns) {
			var name = '-additional';
			var rowObj = new AdditionalAttributesRow();

			var n = numOfDataColumns + 1;
			for (var i = 0;i < n;++i) {
				if (i === 0) {
					var td = $H('td', 'mm-previewtable-attr-rowhead mm-previewtable-attrname-' + name);
					td.innerHTML = 'Additional';
					rowObj.appendHeadColumnElement(td);
				} else {
					rowObj.generateInputColumn(i-1);
				}
			}


			var tbl = this.tableElement;
			tbl.appendChild( rowObj.getRowElement() );

			this.additionalAttrRow = rowObj;
		},

		onTableClick: function(e) {
			this.processClickableConfigRowEvents(e);
			this.updateCellHighlight();
			
			this.fire(CSVPreviewTable.Events.ColumnSettingChanged);
		},
		
		processClickableConfigRowEvents: function(e) {
			var m = this.clickableRowMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				var cr = m[i];
				cr.processClickEvent(e);
			}
		},

		updateCellHighlight: function() {
			var n = this.numOfDataColumns;
			for (var i = 0;i < n;++i) {
				var q = this.jTableElement.find('td[' + (CSVPreviewTable.DataAttrName.DataColIndex) + '=' +i+ ']');

				q.removeClass('mm-previewtable-error-highlight').
				  removeClass('mm-previewtable-highlight-id').
				  removeClass('mm-previewtable-highlight-time').
				  removeClass('mm-previewtable-highlight-x').
				  removeClass('mm-previewtable-highlight-y');

				var foundCR = this.findAttributeForColumnIndex(i);
				if  (!foundCR) {
					// Empty
				} else if (foundCR === true) {
					// Dup
					q.addClass('mm-previewtable-error-highlight');
				} else {
					// Found
					q.addClass('mm-previewtable-highlight-' + foundCR.attributeName);
				}
			}
		},
		
		findAttributeForColumnIndex: function(colIndex) {
			var found = null;
			
			var m = this.clickableRowMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				var cr = m[i];
				if (cr.selectedColIndex === colIndex) {
					if (found) {
						// dup
						return true;
					}
					
					found = cr;
				}
			}
			
			return found;
		},

		detectColumnTypes: function(recordList) {
			var detector = new mobmap.ColumnsAutoDetector();
			detector.detect(recordList);
			
			this.selectColumnForAttributeName('id'  , detector.getIdColumnIndex());
			this.selectColumnForAttributeName('time', detector.getTimeColumnIndex());
			this.selectColumnForAttributeName('x'   , detector.getXColumnIndex());
			this.selectColumnForAttributeName('y'   , detector.getYColumnIndex());
			this.updateCellHighlight();
		},
		
		selectColumnForAttributeName: function(attrName, colIndex) {
			var m = this.clickableRowMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				var cr = m[i];
				if (cr.attributeName === attrName) {
					cr.selectColumn(colIndex);
				}
			}
		},

		getColumnIndexOfAttrName: function(attrName) {
			var m = this.clickableRowMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				var cr = m[i];
				if (cr.attributeName === attrName) {
					return cr.selectedColIndex;
				}
			}

			return -1;
		},
		
		eachAditionalAttribute: function(callback) {
			if (this.additionalAttrRow) {
				this.additionalAttrRow.eachAttribute(callback);
			}
		},

		checkColumnsValid: function() {
			var valid = true;
			var m = this.clickableRowMap;

			for (var i in m) if (m.hasOwnProperty(i)) {
				var cr = m[i];
				if (cr.selectedColIndex < 0) {
					valid = false;
				} else {
					if ( true === this.findAttributeForColumnIndex( cr.selectedColIndex ) ) {
						valid = false;
					}
				}
			}

			return valid;
		}
	};


	function AdditionalAttributesRow() {
		var handler = this.onTextChange.bind(this);

		this.rowElement = $H('tr');
		this.jRowElement = $( this.rowElement ).
		                    keyup( handler ).
		                    keypress( handler ).
		                    change( handler );

		this.colList = [];
		this.txList = [];
	}
	
	AdditionalAttributesRow.ColIndexDataAttr = 'data-addattr-column-index';
	
	AdditionalAttributesRow.prototype = {
		getRowElement: function() {
			return this.rowElement;
		},

		appendHeadColumnElement: function(td) {
			this.rowElement.appendChild(td);
		},

		appendColumnElement: function(td) {
			this.rowElement.appendChild(td);
		},

		generateInputColumn: function(colIndex) {
			var td = $H('td', 'mm-previewtable-addattr-col');
			var tx = $H('input');
			tx.type = 'text';

			tx.setAttribute(AdditionalAttributesRow.ColIndexDataAttr, colIndex);
			td.setAttribute(AdditionalAttributesRow.ColIndexDataAttr, colIndex);

			td.appendChild(tx);
			this.appendColumnElement(td);

			this.colList.push( td );
			this.txList.push( tx );
		},
		
		onTextChange: function(e) {
			if (e.target && e.target.getAttribute) {
				var v = e.target.getAttribute(AdditionalAttributesRow.ColIndexDataAttr);
				if (v && v.length > 0) {
					var ci = parseInt( v );
					this.updateStyleOfColumn(ci);
				}
			}
		},
		
		updateStyleOfColumn: function(colIndex) {
			var td = this.colList[colIndex];
			var tx = this.txList[colIndex];
			var v = tx.value;

			var nameAndType = splitAdditionalAttributeNameAndType(v);
			var color_enable = false;
			if (nameAndType.name) {
				color_enable = true;
			}

			td.setAttribute(kValTypeDataAttrName, color_enable ? ('t'+nameAndType.type) : '');
		},
		
		eachAttribute: function(callback) {
			var len = this.txList.length;
			for (var i = 0;i < len;++i) {
				var tx = this.txList[i];
				var v = tx.value;

				var nameAndType = splitAdditionalAttributeNameAndType(v);
				if (nameAndType.name) {
					callback(i, nameAndType);
				}
			}
		}
	};

	function cleanAdditionalAttributeName(rawValue) {
		if (!rawValue) { return ''; }
		return rawValue.replace(/^ +/, '').replace(/ +$/, '');
	}

	function splitAdditionalAttributeNameAndType(rawValue) {
		var atype = null;
		var aname = null;

		var cleaned = cleanAdditionalAttributeName(rawValue);
		if (cleaned.match( /^([-_0-9a-zA-Z]+)/ ))  {
			aname = RegExp['$1'];
			atype = AttributeType.STRING;
			if (cleaned.indexOf(':') >= 0) {
				var fields = cleaned.split(':');
				if (fields[1]) {
					atype = findAttributeTypeFromName(fields[1]);
				}
			}
		}
		
		return {name: aname, type: atype} ;
	}
	CSVPreviewTable.splitAdditionalAttributeNameAndType = splitAdditionalAttributeNameAndType;


	function ClickableConfigurationRow(name) {
		this.attributeName = name;
		this.jcellList = [];
		
		this.selectedColIndex = -1;
		
		this.barImage = this.createBarImage(name);
		this.arrowImage = this.createArrowImage(name);
	}

	ClickableConfigurationRow.TempCanvasWidth  = 64;
	ClickableConfigurationRow.TempCanvasHeight = 32;

	ClickableConfigurationRow.prototype = {
		addTableCell: function(td) {
			this.jcellList.push($(td));
		},
		
		processClickEvent: function(e) {
			var el = this.checkValidElement(e.target);
			if (!el) {
				if (e.target && e.target.parentNode) {
					el = this.checkValidElement(e.target.parentNode);
				}
			}
			
			if (el) {
				var colIndex = parseInt(el.getAttribute(CSVPreviewTable.DataAttrName.SelColIndex) , 10);
				this.selectColumn(colIndex);
			}
		},

		selectColumn: function(colIndex) {
			if (this.selectedColIndex === colIndex) {
				return;
			}
			
			if (colIndex >= 0) {
				this.selectedColIndex = colIndex;
				this.modifyCellAppearance(colIndex);
			}
		},

		modifyCellAppearance: function(selIndex) {
			var ls = this.jcellList;
			var len = ls.length;

			for (var i = 0;i < len;++i) {
				var j = ls[i];
				var st = j[0].style;

				if (i < selIndex) {
					st.backgroundImage = this.barImage;
					st.backgroundRepeat = '';
				} else if (i === selIndex) {
					st.backgroundImage = this.arrowImage;
					st.backgroundRepeat = 'no-repeat';
				} else {
					st.backgroundImage = 'none';
				}
			}
		},

		checkValidElement: function(node) {
			if (node && node.getAttribute) {
				var a = node.getAttribute(CSVPreviewTable.DataAttrName.SelAttrName);
				if (a && a.length > 0 && a === this.attributeName) {
					return node;
				}
			}
			
			return null;
		},
		
		createBarImage: function(attrName) {
			var clr = CSVPreviewTable.AttrIndicatorColors[attrName];
			if (!clr) { return null; }

			var cv = this.createTemporaryCanvas();
			var g = cv.getContext('2d');
			var cy = this.prepareTempImageStyle(g, clr);
			
			g.beginPath();
			g.moveTo(-8, cy);
			g.lineTo(ClickableConfigurationRow.TempCanvasWidth + 8, cy);
			g.stroke();
			
			return 'url("' + cv.toDataURL() +'")';
		},
		
		createArrowImage: function(attrName) {
			var clr = CSVPreviewTable.AttrIndicatorColors[attrName];
			if (!clr) { return null; }

			var cv = this.createTemporaryCanvas();
			var g = cv.getContext('2d');
			var cy = this.prepareTempImageStyle(g, clr);
			var ax = 10;
			var ay = cy-11;
			
			g.beginPath();
			g.moveTo(-8, cy);
			g.lineTo(2, cy);
			g.bezierCurveTo(ax, cy, ax, cy, ax, ay);
			g.stroke();

			g.beginPath();
			g.moveTo(ax, ay);
			g.lineTo(ax-4, ay+4);
			g.stroke();

			g.beginPath();
			g.moveTo(ax, ay);
			g.lineTo(ax+4, ay+4);
			g.stroke();
			
			g.beginPath();
			g.font = '11px';
			g.textAlign = 'left';
			g.fillText(attrName, ax + 6, cy);

			return 'url("' + cv.toDataURL() +'")';
		},
		
		prepareTempImageStyle: function(g, clr) {
			g.strokeStyle = makeStyleSheetRGB(clr[0], clr[1], clr[2]);
			g.fillStyle = g.strokeStyle;
			g.lineWidth = 2;
			return Math.floor(2*ClickableConfigurationRow.TempCanvasHeight / 3);
		},

		createTemporaryCanvas: function() {
			var cv = $H('canvas');
			cv.width  = ClickableConfigurationRow.TempCanvasWidth;
			cv.height = ClickableConfigurationRow.TempCanvasHeight;
			return cv;
		}
	};


	function makeHeadColGradient(baseColor) {
		return 'linear-gradient(to bottom, '+
		makeStyleSheetRGB(baseColor[0], baseColor[1], baseColor[2])+
		','+
		makeStyleSheetRGB_BlendBlack(baseColor[0], baseColor[1], baseColor[2])+
		')';
	}

	CSVPreviewTable.AttrIndicatorColors = {
		id: [250,0,90],
		time: [200,100,0],
		x: [0,200,0],
		y: [0,0,220]
	};
	
	CSVPreviewTable.DataAttrName = {
		SelAttrName: 'data-sel-attr-name',
		SelColIndex: 'data-sel-col-index',
		DataColIndex: 'data-dat-col-index'
	};

	pkg.CSVPreviewTable = CSVPreviewTable;
});
