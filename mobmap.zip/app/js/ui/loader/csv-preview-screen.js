mmDefineModule(function(pkg) {
	'use strict';
	
	function CSVPreviewScreen() {
		this.jElement = mobmap.FullScreenBox.createBaseElementJ();
		this.element = this.jElement[0];
		this.chkIgnoreHeader = null;

		this.fileformWrapper = null;
		this.addFileForm(this.element);
		
		this.preparingMessage = this.addPreparingMessage(this.element);


		// Content elements
		this.addIgnoreHeaderCheck(this.element);
		
		this.previewTable = new mobmap.CSVPreviewTable();
		this.element.appendChild( this.previewTable.getElement() );


		mobmap.FullScreenBox.setupFullScreen(this);
		var backButton = this.addBackButton();
		this.addTitle('CSV loader configuration');
		
		this.footerElement = this.addFooterArea();
		this.executeButton = this.addExecuteButton( this.footerElement, 'Start loading' );

		// observe buttons
		$(this.executeButton).click( this.onExecuteButtonClick.bind(this) );
		$(backButton).click( this.onBackButtonClick.bind(this) );

		this.previewTable.eventDispatcher().bind(
			mobmap.CSVPreviewTable.Events.ColumnSettingChanged,
			this.onColumnSettingChanged.bind(this)
		);

		mmAddEventDispatcherMethod(this, this.element);
	}

	CSVPreviewScreen.Events = {
		ExecuteButtonClicked: 'mm-csvpreview-execute-click',
		Cancelled: 'mm-csvpreview-cancelled'
	};

	CSVPreviewScreen.prototype = {
		addPreparingMessage: function(container) {
			var box = $H('div', 'mm-csvpreview-preparing');
			box.innerHTML = 'Wait...';

			container.appendChild(box);
			return box;
		},

		setPreparingMessageVisibility: function(v) {
			this.preparingMessage.style.display =v ? '' : 'none';
		},

		// [][] Ignore-header [][]

		addIgnoreHeaderCheck: function(containerElement) {
			var pair = generateInputWithLabel({
				text: 'Ignore first row (as a header)',
				type: 'checkbox',
				labelClass: 'mm-ignore-header-check',
				reverse: true
			});
			
			this.chkIgnoreHeader = pair.input;
			containerElement.appendChild(pair.label);
			
			$(this.chkIgnoreHeader).click( this.onIgnoreHeaderCheckClick.bind(this) );
		},
		
		setIgnoreHeaderCheckValue: function(v) {
			if (this.chkIgnoreHeader) {
				if ( this.chkIgnoreHeader.checked !== !!(v) ) {
					this.chkIgnoreHeader.checked = !!(v);
					this.updateFirstRowStyle();
				}
			}
		},

		getIgnoreHeaderCheckValue: function() {
			if (this.chkIgnoreHeader) {
				return this.chkIgnoreHeader.checked;
			}

			return false;
		},

		updateFirstRowStyle: function() {
			var b = this.getIgnoreHeaderCheckValue();
			var j = this.previewTable.findFirstRow();
			
			if (b) {
				j.addClass('mm-ignored-data-row');
			} else {
				j.removeClass('mm-ignored-data-row');
			}
		},

		onIgnoreHeaderCheckClick: function() {
			this.updateFirstRowStyle();
		},

		// - - - - - - - - - - - - - - - - - - - -

		addFileForm: function(containerElement) {
			this.fileformWrapper = new mobmap.FileFormWrapper();
			containerElement.appendChild(this.fileformWrapper.getElement());
			return this.renewFileInput();;
		},
		
		openFileDialog: function()   { this.fileformWrapper.openFileDialog(); },
		renewFileInput: function()   { return this.fileformWrapper.renewFileInput(); },
		getSelectedFiles: function() { return this.fileformWrapper.getSelectedFiles(); },
		observeFileInputChange: function(handler) { this.fileformWrapper.observeFileInputChange(handler); },

		fillPreviewTable: function(sourceLines) {
			var i;
			var maxCols = 0;
			var dataRows = [];
			var len = sourceLines.length;
			for (i = 0;i < len;++i) {
				var fields = sourceLines[i].split( / *, */ );
				var nCols = fields.length;
				dataRows.push( fields );

				if (nCols > maxCols) {
					maxCols = nCols;
				}
			}
			
			this.previewTable.clear();
			this.previewTable.addColsHeaderRow(maxCols);
			this.previewTable.fillDataRows(dataRows, maxCols);
			
			this.previewTable.addConfigHeaderRow(maxCols);
			this.addRequiredAttributesToTable(this.previewTable, maxCols);
			this.previewTable.addAdditionalAttributeRow(maxCols);
			
			this.previewTable.detectColumnTypes(dataRows);
		},

		addRequiredAttributesToTable: function(tbl, maxCols) {
			tbl.addRequiredAttributeRow('id',  maxCols);
			tbl.addRequiredAttributeRow('x',   maxCols);
			tbl.addRequiredAttributeRow('y',   maxCols);
			tbl.addRequiredAttributeRow('time',maxCols);
		},

		onColumnSettingChanged: function(e) {
			var valid = this.previewTable.checkColumnsValid();
			this.executeButton.disabled = !valid;
		},

		onExecuteButtonClick: function() {
			this.fire( CSVPreviewScreen.Events.ExecuteButtonClicked );
		},

		onBackButtonClick: function() {
			this.fire( CSVPreviewScreen.Events.Cancelled );
		},

		getColumnIndexOfAttrName: function(attrName) {
			return this.previewTable.getColumnIndexOfAttrName(attrName);
		},
		
		eachAditionalAttribute: function(callback) {
			this.previewTable.eachAditionalAttribute(callback);
		},

		addExecuteButton: mobmap.FullScreenBox.addExecuteButton,
		addBackButton: mobmap.FullScreenBox.addBackButton,
		addTitle: mobmap.FullScreenBox.addTitle,
		addFooterArea: mobmap.FullScreenBox.addFooterArea,
		show: mobmap.FullScreenBox.show,
		hide: mobmap.FullScreenBox.hide,

		closeAndCleanup: function() {
			this.hide();
			this.previewTable.clear();
			this.setPreparingMessageVisibility(true);
			
			this.renewFileInput();
		}
	};

	pkg.CSVPreviewScreen = CSVPreviewScreen;
});
