mmDefineModule(function(pkg) {
	'use strict';
	function FileFormWrapper() {
		this.fileForm = null;
		this.element = document.createElement('span');
		this.jElement = $(this.element);

		this.element.style.display = 'none';
	}

	FileFormWrapper.prototype = {
		getElement: function() {
			return this.element;
		},

		renewFileInput: function() {
			var el = this.element;
			el.innerHTML = '';

			var f = $H('input');
			f.type = 'file';
			this.fileForm = f;
			
			el.appendChild(f);
			return f;
		},
		
		observeFileInputChange: function(handler) {
			this.jElement.change(handler);
		},

		getSelectedFiles: function() {
			return this.fileForm.files;
		},

		openFileDialog: function() {
			$(this.fileForm).click();
		}
	};

	pkg.FileFormWrapper = FileFormWrapper;
});
