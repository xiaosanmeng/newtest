mmDefineModule(function(pkg) {
	'use strict';
	
	// OPEN PFLOW : : : : :
	// Auto loader screen
	
	function SampleDataLoaderScreen(callbackFunc) {
		this.callbackFunc = callbackFunc || null;
		this.jElement = mobmap.FullScreenBox.createBaseElementJ();
		this.element = this.jElement[0];

		mobmap.FullScreenBox.setupFullScreen(this);
		this.addTitle('About Open PFLOW');
		this.fillContent( this.element );
		this.footerElement = this.addFooterArea();
		var btn = this.addExecuteButton( this.footerElement );
		$(btn).click( this.onExecuteButtonClick.bind(this) );

		mmAddEventDispatcherMethod(this, this.element);
	}

	SampleDataLoaderScreen.prototype = {
		onExecuteButtonClick: function() {
			this.hide();
			
			if (this.callbackFunc) {
				this.callbackFunc();
			}
		},
		
		addExecuteButton: function(containerElement) {
			var btn = $H('button', 'execute-button');
			btn.appendChild( $T('I got it.') );
			
			containerElement.appendChild(btn);
			return btn;
		},

		fillContent: function(containerElement) {
			var outer = $H('div', 'mm-openpflow-outer');


			var caption = $H('h3', 'mm-openpflow');
			caption.appendChild( $T('Open PFLOW') );

			var credits = $H('p', 'mm-openpflow-credits');
			credits.innerHTML = 'by courtesy of Sekimoto laboratory, the University of Tokyo';

			var desc = $H('p', 'mm-openpflow-desc');
			desc.innerHTML = 'Open PFLOW is a pseudo movement data set generated from publicly available statistical information.';


			outer.appendChild(caption);
			outer.appendChild(credits);
			outer.appendChild(desc);
			containerElement.appendChild(outer);
		},

		addBackButton: mobmap.FullScreenBox.addBackButton,
		addTitle: mobmap.FullScreenBox.addTitle,
		addFooterArea: mobmap.FullScreenBox.addFooterArea,
		show: mobmap.FullScreenBox.show,
		hide: mobmap.FullScreenBox.hide
	};

	pkg.SampleDataLoaderScreen = SampleDataLoaderScreen;
});
