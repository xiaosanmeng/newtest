mmDefineModule(function(pkg) {
	'use strict';

	var ENABLE_SERVER_LIST = false;

	function LiveMovScreen() {
		this.jElement = mobmap.FullScreenBox.createBaseElementJ();
		this.element = this.jElement[0];
		this.listener = null;
		
		this.formContainerElement = null;
		this.jFormContainer = null;
		this.jErrorBox = null;
		this.urlInputText = null;
		this.apiTokenInputText = null;

		mobmap.FullScreenBox.setupFullScreen(this);
		var backButton = this.addBackButton();
		this.addTitle('Live Moving Data');
		this.buildForm(this.element);
		
		this.footerElement = this.addFooterArea();
		this.executeButton = this.addExecuteButton( this.footerElement, 'Add layer' );

		// observe buttons
		$(this.executeButton).click( this.onExecuteButtonClick.bind(this) );
		$(backButton).click( this.onBackButtonClick.bind(this) );
		
		mmAddEventDispatcherMethod(this, this.element);
	}
	
	LiveMovScreen.Events = {
		ExecuteButtonClicked: 'mm-livemov-screen-execute-click',
		Cancelled: 'mm-livemov-screen-cancelled'
	};
	
	var DATA_SERVER_PRESETS = {
		/*
		'localhost': {
			base_url: 'http://127.0.0.1:4557/'
		}*/
	};
	
	LiveMovScreen.prototype = {
		buildForm: function(parentNode) {
			var el = $H('div', 'mm-livemov-screen-form-container');
			if (ENABLE_SERVER_LIST) {
				var layout_box = $H('div', 'mm-livemov-screen-selector-outer');
				this.addPresetSelector(layout_box, 'Presets', DATA_SERVER_PRESETS);
				this.addPresetSelector(layout_box, 'History', mobmap.LiveServerHistory.generateMap());
				parentNode.appendChild(layout_box);
				layout_box.appendChild(el);
			} else {
				parentNode.appendChild(el);
			}
			
			el.innerHTML = "URL of live movement data<br>";

			var urlInput = $H('input', 'mm-livemov-screen-url-form');
			urlInput.type = "text";
			el.appendChild(urlInput);
			this.apiTokenInputText = this.addTokenForm(el);
			
			this.formContainerElement = el;
			this.jFormContainer = $(el);
			this.urlInputText = urlInput;
			
			this.buildErrorBox(el);
		},
		
		addPresetSelector: function(container, sectionTitle, sourceMap) {
			var el = $H('div', 'mm-livemov-screen-preset-container');
			
			var heading = $H('h3');
			heading.innerHTML = sectionTitle;
			el.appendChild(heading);
			
			var n_added = 0;
			for (var i in sourceMap) if (sourceMap.hasOwnProperty(i)) {
				this.addPresetButton(el, i, sourceMap[i].base_url, sourceMap[i].token);
				++n_added;
			}
			
			if (n_added < 1) {
				var nothing = $H('p', 'mm-livemov-screen-preset-nothing-item');
				nothing.innerHTML = 'Nothing';
				el.appendChild( nothing );
			}
			
			container.appendChild(el);
		},

		addPresetButton: function(container, name, url, token) {
			var btn = $H('button', 'mm-livemov-screen-preset-item');
			btn.setAttribute('data-name', name);
			btn.setAttribute('data-url', url);
			
			if (token) {
				btn.setAttribute('data-token', token);
			}
			
			btn.appendChild( $T(name) );
			container.appendChild(btn);
			
			$(btn).click( this.onPresetButtonClick.bind(this, name, btn) );
			
			return btn;
		},
		
		onPresetButtonClick: function(presetName, senderButton) {
			var url = senderButton.getAttribute('data-url');
			var token = senderButton.getAttribute('data-token');
			
			this.urlInputText.value = url;
			if (token && token.length) {
				this.apiTokenInputText.value = token;
			} else {
				this.apiTokenInputText.value = '';
			}
		},

		addTokenForm: function(container) {
			container.appendChild( $H('br') );
			container.appendChild( $H('br') );
			container.appendChild( $T('Read access token') );
			container.appendChild( $H('br') );
			
			var urlToken = $H('input', 'mm-livemov-screen-url-form');
			urlToken.type = "text";
			container.appendChild(urlToken);
			return urlToken;
		},
		
		open: function(presetURL, presetToken) {
			this.urlInputText.value = presetURL || 'http://';
			this.apiTokenInputText.value = presetToken || '';
			this.hideError();
			this.show();
		},

		onExecuteButtonClick: function() {
			this.fire( LiveMovScreen.Events.ExecuteButtonClicked );
		},

		onBackButtonClick: function() {
			this.fire( LiveMovScreen.Events.Cancelled );
		},

		closeAndCleanup: function() {
			this.hideError();
			this.urlInputText.value = '';
			this.apiTokenInputText.value = '';

			this.hide();
		},

		getSourceURL: function() {
			return this.urlInputText.value;
		},
		
		getAccessToken: function() {
			var t = this.apiTokenInputText.value;
			if (t) {
				return t.replace(/ */g, '');
			}
			return t;
		},

		// erro box
		buildErrorBox: function(container) {
			var box = $H('div', 'mm-livemov-screen-errors');
			container.appendChild(box);
			this.jErrorBox = $(box);
			
			return this.jErrorBox;
		},
		
		showError: function(message) {
			this.jErrorBox.show().text( message );
		},

		hideError: function() {
			this.jErrorBox.hide();
		},

		addExecuteButton: mobmap.FullScreenBox.addExecuteButton,
		addBackButton: mobmap.FullScreenBox.addBackButton,
		addTitle: mobmap.FullScreenBox.addTitle,
		addFooterArea: mobmap.FullScreenBox.addFooterArea,
		show: mobmap.FullScreenBox.show,
		hide: mobmap.FullScreenBox.hide
	};

	pkg.LiveServerHistory = {
		generateMap: function() {
			return {
				'gps-test': {
					base_url: 'http://127.0.0.1:4567/gps-test/',
					token: 'd850b2a1986e0f0d3a48f2b6fe54223c8105ef8ba390d23592ae4480f750e397'
				}
			}
		}
	}

	pkg.LiveMovScreen = LiveMovScreen;
});
