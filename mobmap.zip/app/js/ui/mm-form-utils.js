mmDefineModule(function(pkg) {
	'use strict';

	var FormUtils = {
		generateLabel: function(labelText, labelClass) {
			var el = document.createElement('label');
			var tx = document.createElement('span');
			tx.appendChild( document.createTextNode(labelText) );
			tx.setAttribute('class', 'mm-form-label-text');
			
			el.appendChild( tx );
			if (labelClass) {
				el.setAttribute('class', labelClass);
			}
			
			return el;
		},
		
		generateRangeInLabel: function(options) {
			var lb = this.generateLabel(options.labelText, options.labelClass);

			var el = document.createElement('input');
			var jInput = $(el);
			el.type = 'range';
			lb.appendChild(el);

			valid_attr(el, 'min',  options.min);
			valid_attr(el, 'max',  options.max);
			valid_attr(el, 'step', options.step);

			if (options.enableCounter) {
				lb.appendChild( this.generateRangeCounter(el, jInput) );
			}
			
			if (options.change) {
				jInput.change( options.change );
			}

			return {
				jInput: jInput,
				input: el,
				label: lb
			}
		},
		
		generateRangeCounter: function(range, outObjs) {
			var counter = document.createElement('span');
			counter.setAttribute('class', 'mm-range-buddy-counter');
			var closure = function() {
				counter.innerHTML = range.value - 0;
			};
			
			range.addEventListener('change', closure, false);
			
			if (outObjs) {
				outObjs.forceUpdateCounter = closure;
			}
			
			closure();
			return counter;
		}
	};
	
	function valid_attr(el, attr, val) {
		if (val || val === 0) {
			el.setAttribute(attr, val);
		}
	}

	pkg.FormUtils = FormUtils;
});