mmDefineModule(function(pkg) {
	'use strict';
	var kLiveClassName = 'mm-pctl-live-enabled';

	function ToolPane(containerElement) {
		this.nullInitProperties();
		
		// Hold container element
		this.containerElement = containerElement;
		this.jContainerElement = $(containerElement);
		mmAddEventDispatcherMethod(this, containerElement);

		this.setupLayoutTable(this.containerElement);
		this.appToolBar = this.setupAppToolBar(this.toolbarColumn);
		this.setupTimeControlRow();
	}

	ToolPane.prototype = {
		nullInitProperties: function() {
			this.layoutTableElement = null;
			this.jLayoutTableElement = null;

			this.toolbarColumn = null;
			this.appToolBar = null;
			this.playctrlUI = null;
	
			this.timeControlLeftColumn    = null;
			this.timeControlDisplayColumn = null;
			this.timeControlRightColumn   = null;

			this.jTimeControlLeftColumn    = null;
			this.jTimeControlDisplayColumn = null;
			
			this.timelineBar = null;
			this.timeDisplayBox = null;
		},
		
		getPlayControllerUI: function() {
			return this.playctrlUI;
		},
		
		setupLayoutTable: function(containerElement) {
			var tbl = $H('table', 'mm-tool-pane-layout');

			// Time controller cells
			var tc_l = $H('td', 'mm-tool-pane-timectrl-left');
			var tc_d = $H('td', 'mm-tool-pane-timectrl-display');
			var tc_r = $H('td', 'mm-tool-pane-timectrl-right');

			var toolbar_row = $H('tr');
			tbl.appendChild(toolbar_row);
			
			this.toolbarColumn = $H('td', 'mm-tool-pane-toolbar-col');
			this.toolbarColumn.setAttribute('colspan', 3);
			toolbar_row.appendChild(this.toolbarColumn);

			var tc_row = $H('tr');
			tbl.appendChild(tc_row);
			tc_row.appendChild(tc_l);
			tc_row.appendChild(tc_d);
			tc_row.appendChild(tc_r);

			this.layoutTableElement       = tbl;
			this.jLayoutTableElement      = $(tbl);
			this.timeControlLeftColumn    = tc_l;
			this.timeControlDisplayColumn = tc_d;
			this.timeControlRightColumn   = tc_r;

			this.jTimeControlLeftColumn    = $(tc_l);
			this.jTimeControlDisplayColumn = $(tc_d);

			containerElement.appendChild(tbl);
		},
		
		setupAppToolBar: function(container) {
			var tb = new mobmap.MMToolbar();
			
			this.fillAppToolbarButtons(tb);
			container.appendChild( tb.getElement() );
			return tb;
		},

		setLiveMode: function(enabled) {
			if (enabled) {
				this.jTimeControlLeftColumn.addClass(kLiveClassName);
			} else {
				this.jTimeControlLeftColumn.removeClass(kLiveClassName);
			}
			
			this.onContainerResize(null);
			setTimeout( this.onContainerResize.bind(this, null), 20 );
		},

		// Column getters
		getColumnElementForPlayControl: function()    { return this.timeControlLeftColumn; },
		getColumnElementForTimelineBar: function()    { return this.timeControlRightColumn; },
		getColumnElementForTimeDisplayBox: function() { return this.timeControlDisplayColumn; },

		setupTimeControlRow: function() {
			this.setupPlayControl( this.getColumnElementForPlayControl() );
			this.setupTimeControlTimelineBar(  this.getColumnElementForTimelineBar()  );
			this.setupTimeDisplayBox();
			
			this.timeDisplayBox.bindTimelineBar( this.timelineBar );
		},

		setupPlayControl: function(containerColumn) {
			var ctl = new mobmap.PlayerController("./images/player/",  mobmap.PlayerController.TestPreset );
			containerColumn.appendChild( ctl.getElement() );
			this.playctrlUI = ctl;
		},

		setupTimeControlTimelineBar: function(containerElement) {
			this.timelineBar = new mobmap.TimelineBar();
			containerElement.appendChild( this.timelineBar.element );
		},
		
		getTimelineBar: function() { return this.timelineBar; },


		// Layout calculation
		calcWidthExceptTimeline: function() {
			if (!this.jTimeControlLeftColumn) { return 0; }
			
			return this.jTimeControlLeftColumn.width() + 
			        this.jTimeControlDisplayColumn.width();
		},

		onContainerResize: function(e) {
			var remainW =
			 this.jContainerElement.width() -
			  this.calcWidthExceptTimeline();
			
			this.timelineBar.setWidth(remainW);
		},

		observeScreenResize: function(scr) {
			scr.eventDispatcher().bind(mobmap.Mobmap3PanesScreen.RESIZE_EVENT,
				this.onContainerResize.bind(this));
			
			this.onContainerResize(null);
		},


		setupTimeDisplayBox: function() {
			this.timeDisplayBox = new TLTimeDisplayBox(
				this.getColumnElementForTimeDisplayBox()
			);
		},
		
		fillAppToolbarButtons: function(tb) {
			tb.addLabelItem('Selection', 'mm-apptoolbar-label');
			tb.addButtonItem(AppToolbarButtonName.ClearSel,'Clear selection',     'images/l-buttons/LB-x2.png');
			tb.addButtonItem(AppToolbarButtonName.RectSel, 'Select by rectangle', 'images/l-buttons/LB-rectsel2.png'  ,mobmap.MMToolbar.SELF_TOGGLE);

			tb.addLabelItem('Gate dock', 'mm-apptoolbar-label');
			tb.addButtonItem(AppToolbarButtonName.GateDock,'Show gate dock',      'images/l-buttons/LB-gate.png'     ,mobmap.MMToolbar.SELF_TOGGLE);

			tb.addLabelItem('Plug-ins', 'mm-apptoolbar-label');
			tb.addButtonItem(AppToolbarButtonName.Plugin  ,'Toggle plug-ins panel','images/l-buttons/LB-plugin.png');

			tb.addLabelItem('Clock', 'mm-apptoolbar-label');
			tb.addButtonItem(AppToolbarButtonName.Clock,'Show clock','images/l-buttons/LB-clock2.png', mobmap.MMToolbar.SELF_TOGGLE);

			tb.addLabelItem('Theater mode', 'mm-apptoolbar-label');
			tb.addButtonItem(AppToolbarButtonName.Theater,'Theater mode','images/l-buttons/LB-theatre2.png', mobmap.MMToolbar.SELF_TOGGLE);

			tb.addLabelItem('Timeline viz', 'mm-apptoolbar-label');
			tb.addButtonItem(AppToolbarButtonName.TLViz    ,'Toggle visualization on timeline','images/l-buttons/LB-etl.png', mobmap.MMToolbar.SELF_TOGGLE);
			tb.addButtonItem(AppToolbarButtonName.TLV_Config,'Configuration','images/l-buttons/LB-config.png');
		},

		getAppToolBar: function() {
			return this.appToolBar;
		}
	};


	// Time display box
	function TLTimeDisplayBox(containerElement) {
		this.element = null;
		this.dateElement = null;
		this.timeElement = null;
		
		this.containerElement = containerElement;
		this.generateElements(containerElement);
	}
	
	TLTimeDisplayBox.prototype = {
		generateElements: function(containerElement) {
			this.element     = $H('div', 'mm-timedisp-box');
			this.dateElement = $H('div', 'mm-timedisp-box-date');
			this.timeElement = $H('div', 'mm-timedisp-box-time');
			
			this.dateElement.innerHTML = '1900-01-01';
			this.timeElement.innerHTML = '00:00:00';

			this.element.appendChild(this.dateElement);
			this.element.appendChild(this.timeElement);
			containerElement.appendChild( this.element );
		},
		
		bindTimelineBar: function(tl) {
			tl.setDateDisplayElement( this.dateElement );
			tl.setTimeDisplayElement( this.timeElement );
		}
	};

	pkg.ToolPane = ToolPane;
});