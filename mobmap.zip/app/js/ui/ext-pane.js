mmDefineModule(function(pkg) {
	'use strict';
	var kExtToggleGroup = 'exts-toggle';
	
	function ExtPane(containerElement) {
		this.pluginPanelContainerElement = null;
		this.jPluginPanelContainerElement = null;
		this.galleryBarContainerElement = null;
		this.jGalleryBarContainerElement = null;
		this.galleryToolBar = null;
		this.activePluginId = null;

		// Hold container element
		this.containerElement = containerElement;
		this.jContainerElement = $(containerElement);
		mmAddEventDispatcherMethod(this, containerElement);

		this.buildViewElements(containerElement);
		this.initializeGalleryBar(this.galleryBarContainerElement);
		this.galleryToolBar.eventDispatcher().
		 bind( mobmap.MMToolbar.TOGGLE_CHANGE_EVENT, this.onGalleryToolBarToggleChange.bind(this) );
	}

	ExtPane.prototype = {
		loadPlugins: function() {
			this.putPluginButtons(this.galleryToolBar);
		},


		buildViewElements: function(containerElement) {
			var gb = $H('div', 'mmext-gallery-bar');
			this.galleryBarContainerElement = gb;
			this.jGalleryBarContainerElement = $(gb);
			
			var pn = $H('div', 'mmext-panel-container');
			this.pluginPanelContainerElement = pn;
			this.jPluginPanelContainerElement = $(pn).css('overflow-y', 'auto');

			containerElement.appendChild(gb);
			containerElement.appendChild(pn);
		},
		
		initializeGalleryBar: function(barContainerElement) {
			var tb = new mobmap.MMToolbar();
			barContainerElement.appendChild(tb.getElement());

			this.galleryToolBar = tb;
		},
		
		putPluginButtons: function(toolbar) {
			var ph = mobmap.PluginHost.getInstance();
			var that = this;

			ph.eachPlugin(function(pluginId, info) {
				that.putAPluginButton(toolbar, pluginId, info)
			});
		},
		
		putAPluginButton: function(toolbar, pluginId, info) {
			if (mobmap.PluginTypes.AnalysisPanel !== info.category) {
				return;
			}

			toolbar.addButtonItem(info['id'], info['title'], info['tool-icon'], kExtToggleGroup);
		},
		
		onGalleryToolBarToggleChange: function(e, senderButton) {
			if (senderButton.selected) {
				this.loadPluginPanel(senderButton.name);
			}
		},
		
		loadPluginPanel: function(pluginId) {
			var ph = mobmap.PluginHost.getInstance();
			var info = ph.getById(pluginId);
			if (info) {
				if (this.activePluginId !== pluginId) {
					this.unloadCurrent();

					info.load(this.pluginPanelContainerElement);
					this.activePluginId = pluginId;
				}
			}
		},

		sendMessage: function(pluginId, command, params) {
			if (this.activePluginId === pluginId) {
				var info = mobmap.PluginHost.getInstance().getById(pluginId);
				if (info.sendMessage) {
					info.sendMessage(command, params);
				}
			}
		},

		unloadCurrent: function() {
			var ph = mobmap.PluginHost.getInstance();
			if (this.activePluginId) {
				var info = ph.getById(this.activePluginId);
				if (info.unload) {
					info.unload();
				}
			}
		},
		
		// <><><><><> Sizing <><><><><>

		afterScreenResize: function() {
			var containerHeight = this.jContainerElement.height() | 0;
			var bh = this.jGalleryBarContainerElement.height() | 0;

			this.jPluginPanelContainerElement.css('max-height', (containerHeight - bh)+'px');
		},

	};

	pkg.ExtPane = ExtPane;
});