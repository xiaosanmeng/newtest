mmDefineModule(function(pkg) {
	'use strict';

	function LayerListViewController() {
		this.layerListView = null;
	}
	
	LayerListViewController.prototype = {
		connectModelAndView: function(layerListView, modelEventDispatcher) {
			this.layerListView = layerListView;

			var E = mobmap.MMLayerList.Event;
			var L = mobmap.LayerEvent;
			modelEventDispatcher.
			 bind(E.ItemAdded,          this.onItemAdded.bind(this)).
			 bind(E.ItemRemoved,        this.onItemRemoved.bind(this)).
			 bind(E.OrderSwapSucceeded, this.onItemSwapped.bind(this)).
			 bind(L.FullLoadWillStart,  this.onLayerLoadWillStart.bind(this)).
			 bind(L.LoadProgressChange, this.onLayerLoadProgressChange.bind(this)).
			 bind(L.LoadFinish,         this.onLayerLoadFinish.bind(this)).
			 bind(L.DataSchemaChange,   this.onLayerDataSchemaChange.bind(this)).
			 bind(L.InitialSettingsApplied,this.onLayerInitialSettingsApplied.bind(this)).
			 bind(mobmap.MMProject.Events.LAYER_SELECTED, this.onLayerSelected.bind(this)).
			 bind( mobmap.SelectionPool.CHANGE_EVENT, this.onLayerLocalSelectionChanged.bind(this) ).
			 bind(L.TrajectoryColorChange, this.onLayerTrajectoryColorChange.bind(this) ).
			 bind( mobmap.MarkerOptionModelProxy.CHANGE_EVENT, this.onLoayerMarkerOptionChanged.bind(this) ).
			 bind( mobmap.MarkerOptionModelProxy.GRADIENT_SET_CHANGE_EVENT, this.onLayerMarkerGradientSetChanged.bind(this) ).
			 bind(mobmap.LayerEvent.GridAppearanceChange, this.onGridAppearanceChange.bind(this)  );


			layerListView.observeListToolBarButtonClick( this.onListToolBarButtonClick.bind(this) );
		},

		// event handling - - - -
		onItemAdded: function(e, sender, newItem) {
			newItem._list_view = null;
			var LT = mobmap.LayerType;
			
			switch(newItem.type) {
			case LT.MovingObject:
				newItem._list_view = this.layerListView.addMovingObjectItem();
				break;

			case LT.Grid:
				newItem._list_view = this.layerListView.addGridItem();
				break;

			default:
				console.log("WARNING: Unknown layer type:" + newItem.type, newItem);
				break;
			}

			var vw = newItem._list_view;
			if (vw) {
				vw.setModel(newItem);
				this.observeLayerToolbar(newItem);
				vw.updateConfigurationPanelFromModel();
				vw.observeItemClick( this.onLvItemClick.bind(this, newItem) );
				vw.observeRemoveButtonClick( this.onLvRemoveButtonClick.bind(this, newItem) );
				vw.observeMoveUpButtonClick( this.onLvMoveUpButtonClick.bind(this, newItem) );
				
				if (vw.observeTrajectoryConfigurationSection) {
					vw.observeTrajectoryConfigurationSection(
						this.onTrajectoryColorPick.bind(this, newItem),
						this.onTrajectoryCompositionRadioChange.bind(this, newItem),
						this.onTrajectoryLineStyleRadioChange.bind(this, newItem),
						this.onTrajectoryLimitDistanceCheckChange.bind(this, newItem, vw),
						this.onTrajectoryLimitDistanceNumberChange.bind(this, newItem, vw),
						this.onTrajectoryLimitTimeNumberChange.bind(this, newItem, vw)
					);
				}
				
				// Data/Marker configuration form events = = = = = = = = = = = = = = = = = =
				this.observeDataConfigUIs(newItem, vw);
				this.observeMarkerConfigUIs(newItem, vw);
				
				// Grid properties
				this.observeGridConfigUIs(vw);

				this.afterContainerResize();
				
				// sync
				if (vw.syncFromModel) {
					vw.syncFromModel();
				}
			}
		},

		observeDataConfigUIs: function(newItem, vw) {
			if (vw.getRemainOutsideCheckbox) {
				$(vw.getRemainOutsideCheckbox()).
				 click( this.onRemainOutsideCheckboxClick.bind(this, vw) );
			}
		},

		observeMarkerConfigUIs: function(newItem, vw) {
			if (vw.bindAttrBindSelectChange) {
				vw.bindAttrBindSelectChange(  this.onAttrBindSelectChange.bind(this, newItem) );
			}
			
			// Preset toggles
			if (vw.liveObserveMarkerColorPresetRadio) {
				vw.liveObserveMarkerColorPresetRadio('click', this.onMarkerColorPresetRadioClick.bind(this, vw) );
			}

			if (vw.liveObserveColorReverseButtons) {
				vw.liveObserveColorReverseButtons(
					'click',
					this.onMarkerColorReverseButtonClick.bind(this, vw)
				);
			}

			if (vw.getJMarkerCompositionRadio) {
				vw.getJMarkerCompositionRadio().click( this.onMarkerCompositionRadioClick.bind(this, vw) );
			}
			
			if (vw.getJMarkerSizingRadio) {
				vw.getJMarkerSizingRadio().click( this.onMarkerSizingRadioClick.bind(this, vw) );
			}
			
			if (vw.getPerceptualScalingCheckbox) {
				$( vw.getPerceptualScalingCheckbox() ).
				 click( this.onPerceptualScalingCheckboxClick.bind(this, vw) );
			}

			if (vw.getTailDurationNumInput) {
				$( vw.getTailDurationNumInput() ).change(
					this.onTailDurationChange.bind(this, vw)
				);
			}
		},

		observeGridConfigUIs: function(vw) {
			if (vw.getJColorSchemeRadio) {
				vw.getJColorSchemeRadio().click( this.onColorSchemeRadioClick.bind(this, vw) );
			}
			
			if (vw.getJGridSpacingRadio) {
				vw.getJGridSpacingRadio().click( this.onGridSpacingRadioClick.bind(this, vw) );
			}
			
			if (vw.getJAutoMaxButton) {
				vw.getJAutoMaxButton().click( this.onAutoMaxButtonClick.bind(this, vw) );
			}
			
			if (vw.getJRenderValueMaxField) {
				var mx_func = this.onRenderValueMaxFieldChange.bind(this, vw);
				vw.getJRenderValueMaxField().change( mx_func ).keyup( mx_func );
			}
		},

		onItemRemoved: function(e, sender, removedItem) {
			var vw = removedItem._list_view;
			if (this.layerListView && vw) {
				this.layerListView.removeItemView(vw);
			}
		},

		onLayerLoadWillStart: function(e, layer) {
			if (layer._list_view) {
				layer._list_view.showLoadingProgress();
				layer._list_view.setTitleText( layer.getShortDescription() );
			}
		},
		
		onLayerLoadProgressChange: function(e, layer, ratio) {
			if (layer._list_view) {
				layer._list_view.setLoadingProgressRatio(ratio);
			}
		},

		onLayerLoadFinish: function(e, layer) {
			var v = layer._list_view;
			if (v) {
				v.hideLoadingProgress();
				v.setTitleSubText( layer.getDetailDescription() );

				mobmap.LayerListViewController.updateAttributeBindSelect(v, layer);
			}
		},
		
		observeLayerToolbar: function(listItem) {
			if (!listItem._list_view) { return; }
			
			var tb = listItem._list_view.getMainToolBar();
			tb.eventDispatcher().bind( mobmap.MMToolbar.TOGGLE_CHANGE_EVENT, this.onLayerToolBarToggle.bind(this, listItem) );
			
			var stb = listItem._list_view.getSelectionToolBar();
			if (stb) {
				stb.eventDispatcher().bind( mobmap.MMToolbar.CLICK_EVENT, this.onLayerSelectionToolBarClick.bind(this, listItem) );
			}
		},
		
		onLayerToolBarToggle: function(layer, e, senderButton) {
			switch(senderButton.name) {
			case mobmap.LayerListView.kToolButtonName_Config:
				if (layer._list_view) {
					layer._list_view.getConfigurationPanel().setOpened( senderButton.selected );
					this.afterContainerResize(); // this operation will affect box size
				}
				break;

			case mobmap.LayerListView.kToolButtonName_SelOnly:
				var mo = layer.getMarkerOption();
				if (mo) {
					mo.setShowSelectedOnly(senderButton.selected);
				}
				break;

			case mobmap.LayerListView.kToolButtonName_Tail:
			// TAIL
				// Modify model
				if (layer.setTailEnabled) {
					layer.setTailEnabled(senderButton.selected);
				}
				
				// Modify list view
				if (layer._list_view) {
					layer._list_view.showTailConfigurationSection( senderButton.selected );
				}
				
				break;

			case mobmap.LayerListView.kToolButtonName_Visibility:
				layer.setVisibility(senderButton.selected);
				break;

			case mobmap.LayerListView.kToolButtonName_Trajectory:
				this.showTrajectoryForLayer(layer, senderButton.selected);
				break;

			}
		},
		
		onLayerSelectionToolBarClick: function(layer, e, senderButton) {
			if (senderButton.name === mobmap.LayerListView.kToolButtonName_SelClear) {
				layer.getSelectionPool().clear();
			}
		},
		
		afterContainerResize: function() {
			if (this.layerListView) {
				this.layerListView.resizeView();
				this.layerListView.resizeFlexibleElements();
			}
		},

		onLayerSelected: function(e, senderProject) {
			var selId = senderProject.lyrselGetFirstId();
			if (selId !== null) {
				this.layerListView.setSelectedStyleOne(selId);
			}
		},

		onListToolBarButtonClick: function(e, button) {
			var app = this.getOwnerApp();

			if (app) {
				var LV = mobmap.LayerListView;
				switch(button.name){
				case LV.kListToolButtonName_AddMov:
					app.openCSVLoaderScreen(); break;
				case LV.kListToolButtonName_AddGrid:
					app.openGridCSVLoaderScreen(); break;
				case LV.kListToolButtonName_AddLive:
					app.openLiveMovSetupScreen(); break;
				case LV.kListToolButtonName_AddLiveGrid:
					app.openLiveGridSetupScreen(); break;
				}
			}
		},
		
		onLvItemClick: function(itemModel, e) {
			var pj = this.getAppCurrentProject();
			if (pj) {
				pj.lyrselSelectOne(itemModel.layerId);
			}
		},

		onLvRemoveButtonClick: function(itemModel, e) {
			var dlg = this.getOwnerApp().getConfirmDialog();
			dlg.showDialogOnCenter(
				'Remove layer',
				'Layer "' + itemModel.getShortDescription() + '" will be removed.',
				{
					'ok': this.onRemoveDialogOkClick.bind(this),
					targetLayer: itemModel
				});
		},
		
		onLvMoveUpButtonClick: function(itemModel, e) {
			var v = itemModel._list_view;
			var ls = itemModel.getOwnerList();
			var index = ls.indexOf(itemModel);

			if (index > 0) {
				ls.requestSwap(index-1);
			} else {
				if (v) {
					v.showCantMoveUpAnimation();
				}
			}
		},
		
		onItemSwapped: function(e, sender, firstIndex) {
			var item1 = sender.getAt(firstIndex  );
			var item2 = sender.getAt(firstIndex+1);
			
			if (item1 && item2) {
				var v1 = item1._list_view;
				var v2 = item2._list_view;
				if (v1 && v2) {
					this.layerListView.swapItems(v2, v1);
				}
			}
		},

		onRemoveDialogOkClick: function(senderDialog, callbackSetting) {
			var pj = this.getAppCurrentProject();
			if (pj) {
				pj.removeLayer(callbackSetting.targetLayer);
			}
		},

		onLayerLocalSelectionChanged: function(e, senderSelPool) {
			var ownerLayer = senderSelPool.getOwner();
			if (ownerLayer._list_view && 
				ownerLayer._list_view.notifySelectionChange) {
				ownerLayer._list_view.notifySelectionChange();
			}
		},

		onMarkerColorPresetRadioClick: function(senderView) {
			var layer = senderView.getModel();
			var mopt = layer.getMarkerOption();

			if (mopt) {
				var pid = senderView.getSelectedMarkerColorPresetId();
				mopt.loadMarkerSetPreset(pid);
			}
		},
		
		onMarkerCompositionRadioClick: function(senderView, e) {
			if (e.target && e.target.checked) {
				var add_enabled = ( parseInt(e.target.value) > 0 );
				var layer = senderView.getModel();
				var mopt = layer.getMarkerOption();
				
				mopt.setAddCompositionEnabled( add_enabled );
			}
		},

		onMarkerSizingRadioClick: function(senderView, e) {
			if (e.target && e.target.checked) {
				var v = parseInt(e.target.value);
				var layer = senderView.getModel();
				var mopt = layer.getMarkerOption();

				mopt.setMarkerAutoSizing( v );
			}
		},

		onPerceptualScalingCheckboxClick: function(senderView, e) {
			if (e.target) {
				var chk = e.target.checked;
				var mopt = senderView.getModel().getMarkerOption();
				if (mopt) {
					mopt.setPerceptualScalingEnabled( chk );
				}
			}
		},
		
		onMarkerColorReverseButtonClick: function(senderView, e) {
			var mopt = senderView.getModel().getMarkerOption();
			if (mopt) {
				var pid = e.target.getAttribute('data-radio-value');
				mopt.reverseMarkerSetPresetOrder(pid);
				senderView.renewMarkerPresetPreview(pid);

				if (senderView.getSelectedMarkerColorPresetId() === pid) {
					// load now
					mopt.loadMarkerSetPreset(pid);
				}
			}
		},

		onTailDurationChange: function(senderView, e) {
			var mopt = senderView.getModel().getMarkerOption();
			if (mopt) {
				mopt.setTailDuration( senderView.getTailDurationValue() );
			}
		},

		onRemainOutsideCheckboxClick: function(senderView, e) {
			if (e.target) {
				var chk = e.target.checked;
				var lyr = senderView.getModel();
				lyr.setRemainOutsideRecords(chk);
			}
		},

		onColorSchemeRadioClick: function(senderView) {
			senderView.getModel().setColorList( senderView.getSelectedColorScheme());
		},

		onGridSpacingRadioClick: function(senderView) {
			senderView.getModel().setSpacingEnabled( senderView.getGridSpacingEnabled() );
		},
		
		onRenderValueMaxFieldChange: function(senderView) {
			this.sendRenderValueMaxFieldValue(senderView);
		},

		onAutoMaxButtonClick: function(senderView) {
			senderView.getModel().setAutoValueMax();
		},

		sendRenderValueMaxFieldValue: function(senderView) {
			var val = senderView.getRenderValueMaxFieldValue();
			senderView.getModel().setRenderValueMax(val);
		},

		onGridAppearanceChange: function(e, senderLayer) {
			var vw = senderLayer._list_view;
			if (vw && vw.syncFromModel) {
				vw.syncFromModel();
			}
		},

		getAppCurrentProject: function() {
			var app = this.getOwnerApp();
			if (app) {
				return app.getCurrentProject();
			} else {
				return null;
			}
		},

		onLoayerMarkerOptionChanged: function(e, markerOption) {
			var senderLayer = markerOption.getOwnerLayer();
			if (senderLayer) {
				var v = senderLayer._list_view;
				if (v) {
					var dk = markerOption.isAddCompositionEnabled();
					v.pvSetDarkBackground( dk );
					v.setMarkerSequencePreviewDark( dk );
					
					v.syncFromModel();
				}
			}
		},

		onLayerMarkerGradientSetChanged: function(e, markerOption) {
			var layer = markerOption.getOwnerLayer();
			if (layer._list_view && layer._list_view.fillPresetSelector) {
				layer._list_view.clearPresetSelector();
				layer._list_view.fillPresetSelector();
			}
		},

		onLayerTrajectoryColorChange: function(e, layer) {
			var vw = layer._list_view;
			if (vw && vw.syncTrajectoryColorPicker) {
				vw.syncTrajectoryColorPicker( layer.trajectoryDefaultColor );
			}
		},

		showTrajectoryForLayer: function(layer, toggleStatus) {
			var lid = layer.layerId;
			this.layerListView.turnOffTrajectoryButton(lid);
			this.layerListView.toggleTrajectoryConfigPanel(toggleStatus ? lid : null);

			var trjDataSource = null;
			if (toggleStatus) {
				trjDataSource = layer;
			}

			var app = this.getOwnerApp();
			app.getMapPane().setTrajectoryOwner(layer);
			app.getMapPane().setTrajectoryMapDataSource(trjDataSource);
		},

		onAttrBindSelectChange: function(layer, e) {
			var attrName = layer._list_view.getAttrBindSelectValue();
			if (attrName === mobmap.LayerListViewMovingObjectItem.NoBind) {
				attrName = null;
			}
			
			layer.setMarkerColorBoundAttribute(attrName);
		},
		
		onLayerDataSchemaChange: function(e, senderLayer) {
			var vw = senderLayer._list_view;
			if (vw) {
				mobmap.LayerListViewController.updateAttributeBindSelect(vw, senderLayer);
			}
		},
		
		onLayerInitialSettingsApplied: function(e, senderLayer) {
			var vw = senderLayer._list_view;
			var s = senderLayer.getInitialSettings();
			if (vw && s) {
				var markerPreset = s.getMarkerColorPreset();
				if (markerPreset) {
					vw.renewMarkerPresetPreview(markerPreset); // update (if reversed)
				}
			}
		},
		
		onTrajectoryColorPick: function(senderLayer, e, picker, pickedColor, pickedOpacity) {
			var marker_color = (pickedColor === mobmap.QuickColorPicker.SpecialColor_Var);
			
			senderLayer.setTrajectoryUseMarkerColor(marker_color);
			senderLayer.setTrajectoryDefaultColor(pickedColor, pickedOpacity);
		},

		onTrajectoryCompositionRadioChange: function(senderLayer, e) {
			if (e.target.checked) {
				var enabled = parseInt(e.target.value) > 0;
				senderLayer.setTrajectoryAddComposition(enabled);
			}
		},
		
		onTrajectoryLineStyleRadioChange: function(senderLayer, e) {
			if (e.target.checked) {
				var val = parseInt(e.target.value, 10);
				senderLayer.setTrajectoryLineStyle(val);
			}
		},
		
		onTrajectoryLimitDistanceCheckChange: function(senderLayer, itemView, e) {
			this.sendTrajectoryLimitDistanceValue(senderLayer, itemView);
		},

		onTrajectoryLimitDistanceNumberChange: function(senderLayer, itemView, e) {
			this.sendTrajectoryLimitDistanceValue(senderLayer, itemView);
		},
		onTrajectoryLimitTimeNumberChange: function(senderLayer, itemView, e) {
			this.sendTrajectoryLimitDistanceValue(senderLayer, itemView);
		},
		
		sendTrajectoryLimitDistanceValue: function(layer, itemView) {
			var d = 0;
			var timeLimit = 0;
			var tp = itemView.getTrajLimitType();
			if (tp === mobmap.LayerListViewMovingObjectItem.TrajLimitDistance) {
				d = 1000 * parseFloat( itemView.getJLimitDistanceNumber().val() );
			} else if (tp === mobmap.LayerListViewMovingObjectItem.TrajLimitTime) {
				timeLimit = 60 * parseFloat( itemView.getJLimitTimeNumber().val() );
			}

			itemView.showLimitDistanceConfigBox(tp === mobmap.LayerListViewMovingObjectItem.TrajLimitDistance);
			itemView.showLimitTimeConfigBox(tp === mobmap.LayerListViewMovingObjectItem.TrajLimitTime);

			if (layer.setTrajectoryLimitDistance) {
				layer.setTrajectoryLimitDistance( Math.floor(d) );
			}
			
			if (layer.setTrajectoryLimitTimePeriod) {
				layer.setTrajectoryLimitTimePeriod( Math.floor(timeLimit) );
			}
			
			return tp !== mobmap.LayerListViewMovingObjectItem.TrajLimitNone;
		}
	};

	LayerListViewController.updateAttributeBindSelect = function(v, layer) {
		if (v.clearAdditionalAttributes) {
			v.clearAdditionalAttributes();
			layer.attributeList.eachAdditionalAttribute(function(attrInfo) {
				v.addAdditionalAttribute(attrInfo);
			});
		}
	}

	// base classes
	mobmap.installBaseMethods(  LayerListViewController.prototype, mobmap.AppOwnedBase  );

	// export
	pkg.LayerListViewController = LayerListViewController;
});