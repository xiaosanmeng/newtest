mmDefineModule(function(pkg) {
	'use strict';

	// List of default tabs
	var kInfoPaneDefaultTabNames = [
		['Layers'    , kInfoPaneTabNames.Layers     ],
		['Data'      , kInfoPaneTabNames.Data       ],
		['Analysis'  , kInfoPaneTabNames.Analysis   ]
	];


	function InfoPane(containerElement) {

		// Hold container element
		this.containerElement = containerElement;
		this.jContainerElement = $(containerElement);
		mmAddEventDispatcherMethod(this, containerElement);

		this.tabList = this.initializeTabs( this.jContainerElement );
		this.selectFirstTab();
	}


	InfoPane.INFOPANE_EVENT_RESIZED       = "infopane-event-resized";
	InfoPane.INFOPANE_EVENT_PAGE_SELECTED = "infopane-event-page-selected";
	InfoPane.prototype = {

		// +++++++++++++++++ Initialization +++++++++++++++++
		initializeTabs: function(jTabsContainerElement) {
			var tabList = new TabList(jTabsContainerElement[0]);
			this.prepareDefaultTabs(tabList);
			this.setupTabstrip(jTabsContainerElement);
			return tabList;
		},
		
		prepareDefaultTabs: function(tabList) {
			var ls = kInfoPaneDefaultTabNames;
			for (var i in ls) if (ls.hasOwnProperty(i)) {
				var name_and_id = ls[i];

				tabList.add(name_and_id[0], name_and_id[1]);
			}
		},

		setupTabstrip: function(jTabsContainerElement) {
			jTabsContainerElement.kendoTabStrip({animation: false, select: this.onSelectTab.bind(this) });
		},


		onSelectTab: function(e) {
			if (e) {
				var name = getTabNameData(e.item);
				if (name) {
					this.eventDispatcher().
					 trigger(InfoPane.INFOPANE_EVENT_PAGE_SELECTED, name);
				}
			}
		},

		// <><><><><> Sizing <><><><><>

		afterScreenResize: function() {
			var containerHeight = this.jContainerElement.height();
			var tabsHeight = this.tabList.getHeight();
			
			var h = 0 | (containerHeight - tabsHeight);
			this.setBoxHeightAll(h-18);
		},

		setBoxHeightAll: function(h) {
			this.jContainerElement.
			 find('.'+kTabbedBoxClassName).
			 height(h).
			 trigger(InfoPane.INFOPANE_EVENT_RESIZED);
		},

		// shortcut
		getBoxByName: function(name)  { return this.tabList.getBoxByName(name); },
		getLayerListBox: function()   { return this.getBoxByName( kInfoPaneTabNames.Layers ); },
		getTabStripObject: function() { return this.jContainerElement.data("kendoTabStrip"); },

		selectFirstTab: function() {
			this.getTabStripObject().select(0);
		}
	};



	// List element manager
	function TabList(containerElement) {
		this.element = $H('ul', 'mm-info-pane-list');
		this.jElement = $(this.element);
		
		this.containerElement = containerElement;
		this.containerElement.appendChild(this.element);
	}
	
	TabList.prototype = {
		add: function(label, name) {
			var li = $H('li');
			li.appendChild( $T(label) );
			li.setAttribute('data-itemname', name);
			
			this.element.appendChild(li);
			generateTabbedBox(this.containerElement, name);
			
			return li;
		},
		
		removeByName: function(name) {
			var ls = this.element.childNodes;
			var len = ls.length;
			for (var i = 0;i < len;++i) {
				var el_nm = ls[i].getAttribute('data-itemname');
				if (el_nm === name) {
					// XXX
				}
			}
		},
		
		getBoxByName: function(name) {
			var ls = this.containerElement.childNodes;
			var len = ls.length;
			for (var i = 0;i < len;++i) {
				var el = ls[i];
				if (!el.getAttribute) {continue;}
				
				var el_nm = el.getAttribute('data-itemname');
				var el_bx = el.getAttribute('data-tabbedbox') | 0;
				if (el_bx === 1 && el_nm === name) {
					return el;
				}
			}
			
			return null;
		},
		
		getHeight: function() {
			return this.jElement.height();
		}
	};
	
	var kTabbedBoxClassName = 'mm-info-pane-box';
	function generateTabbedBox(container, name) {
		var box = $H('div', kTabbedBoxClassName);
		box.setAttribute('data-itemname', name);
		box.setAttribute('data-tabbedbox', '1');
		container.appendChild(box);
	}

	function getTabNameData(el) { return el.getAttribute('data-itemname') || null; }


	pkg.InfoPane = InfoPane;
});