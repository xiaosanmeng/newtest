mmDefineModule(function(pkg) {
	'use strict';
	
	function SortableAttrListView(containerElement, columnNameList) {
		this.gridData = null;
		this.element = document.createElement('div');
		this.jElement = $( this.element );
		
		containerElement.appendChild( this.element );
		
		this.buildGrid(columnNameList);
	}
	
	SortableAttrListView.prototype = {
		buildGrid: function(columnNameList) {
			var j = this.jElement;


			j.kendoGrid({
				editable: true,
				dataSource: this.generateGridDataSource(columnNameList),
				reorderable: true,
				columns: this.generateColumnList( columnNameList )
			});
			
		},
		
		// Generate data source and template for grid
		generateColumnList: function(columnNameList) {
			var n = columnNameList.length;
			var outLs = [];
			for (var i = 0;i < n;++i) {
				outLs.push({
					field: columnNameList[i],
					template: cell_template.bind( null, columnNameList[i] )
				})
			}
			
			return outLs;
		},
		
		generateGridDataSource: function(columnNameList) {
			var n = columnNameList.length;

			var rec = {};
			for (var i = 0;i < n;++i) {
				rec[ columnNameList[i] ] = true;
			}

			this.gridData = rec;
			return {
				data: [rec]
			};
		},
		
		getResult: function() {
			var g = this.getKendoGrid();
			var colList = g.columns;
			var rec = g.dataSource.data()[0];
			
			var resList = [];
			for (var i = 0;i < colList.length;++i) {
				var attrName = colList[i].field;
				if (rec[attrName]) {
					resList.push( attrName );
				}
			}
			
			return resList;
		},
		
		destroy: function() {
			this.getKendoGrid().destroy();
		},
		
		getKendoGrid: function() {
			return this.jElement.data("kendoGrid");
		}
	};
	
	function cell_template(fieldName, dat) {
		return dat[fieldName] ? "✔︎ Export" : "";
	}
	
	pkg.SortableAttrListView = SortableAttrListView;
});