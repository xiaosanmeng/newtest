mmDefineModule(function(pkg) {
	'use strict';

	function RenameButton(targetElement, buttonURL, listener) {
		this.jTarget    = $(targetElement);
		this.textBox    = this.createBuddyText(targetElement);
		this.editButton = this.createEditButton(targetElement, buttonURL);
		this.jTextBox    = $(this.textBox);
		this.jEditButton = $(this.editButton);
		
		this.observeEvents();
		this.listener = listener;
	}
	
	var kActiveClassName = 'mm-renamer-active';
	
	RenameButton.prototype = {
		createBuddyText: function(targetElement) {
			var tx = $H('input', 'mm-renamer-buddy-text');
			tx.type = 'text';
			
			targetElement.parentNode.appendChild(tx);
			return tx;
		},
		
		createEditButton: function(targetElement, imageURL) {
			var btn = $H('img', 'mm-renamer-button');
			btn.src = imageURL;
			btn.alt = btn.title = 'Rename';

			targetElement.parentNode.appendChild(btn);
			return btn;
		},
		
		observeEvents: function() {
			this.jEditButton.click(
				this.onEditButtonClick.bind(this)
			);

			// Handle finishing
			this.jTextBox.
			 blur( this.onTextBlur.bind(this) ).
			 keydown( this.onTextKeyDown.bind(this) );
		},
		
		onEditButtonClick: function() {
			this.setEditMode(true);
		},

		setEditMode: function(enabled) {
			if (enabled) {
				this.textBox.value = this.jTarget.text();
				
				if (this.listener && this.listener.renamerWillStartEdit) {
					this.listener.renamerWillStartEdit(this);
				}
				
				this.jTarget.hide();
				this.jEditButton.addClass(kActiveClassName);
				this.jTextBox.addClass(kActiveClassName);
				
				this.textBox.focus();
			} else {
				this.jTarget.show();
				this.jEditButton.removeClass(kActiveClassName);
				this.jTextBox.removeClass(kActiveClassName);
			}
		},
		
		onTextBlur: function() {
			this.finishEdit(true);
		},
		
		onTextKeyDown: function(e) {
			var k = e.keyCode;
			if (k === 13) {
				// Enter
				this.finishEdit(true);
			} else if (k === 27) {
				// ESC
				this.finishEdit(false);
			}
		},
		
		finishEdit: function(adopt) {
			if (this.listener && this.listener.renamerDidFinishEdit) {
				this.listener.renamerDidFinishEdit(this, this.jTextBox.val(), adopt);
			}

			this.setEditMode(false);
		}
	};

	// export
	pkg.RenameButton = RenameButton;
});