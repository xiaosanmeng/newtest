mmDefineModule(function(pkg) {
	'use strict';
	var kToolBarClassName = 'mm-tool-bar';
	var kToolButtonClassName = 'mm-tool-button';
	var kToolButtonCoverClassName = 'mm-tool-button-cover';
	var kToolBarButtonDefaultWidth = 20;
	var kToolBarButtonDefaultHeight = 20;

	function MMToolbar() {
		this.element = document.createElement('div');
		this.element.className = kToolBarClassName;
		this.jElement = $(this.element);
		this.toggleGroups = {};
		this.nameMap = {};

		mmAddEventDispatcherMethod(this, this.element);
		this.observeSelfEvents();
	}

	MMToolbar.SELF_TOGGLE = 1;
	MMToolbar.CLICK_EVENT = 'mmtoolbar-click-event';
	MMToolbar.TOGGLE_CHANGE_EVENT = 'mmtoolbar-toggle-change-event';

	MMToolbar.prototype = {
		getElement: function() {
			return this.element;
		},
		
		addClass: function(className) {
			this.jElement.addClass(className);
		},
		
		show: function() { this.jElement.show(); },
		hide: function() { this.jElement.hide(); },
		
		addLabelItem: function(text, className) {
			var el = $H('span', className)
			el.appendChild($T(text));
			this.element.appendChild(el);
			return el;
		},
		
		addButtonItem: function(buttonName, longTitle, iconURL, toggleGroup, linkButton) {
			var btn = new MMToolbarButtonItem(buttonName, longTitle, iconURL, toggleGroup, linkButton);
			this.element.appendChild( btn.getElement() );
			
			this.nameMap[ buttonName ] = btn;
			if (toggleGroup) {
				this.addToToggleGroup(btn, toggleGroup);
			}
			
			return btn;
		},

		getButtonByName: function(name) {
			return this.nameMap[ name ] || null;
		},

		addToToggleGroup: function(button, toggleGroupName) {
			var m = this.toggleGroups;
			if (!m[toggleGroupName]) {
				m[toggleGroupName] = [];
			}
			
			m[toggleGroupName].push(button);
		},
		
		observeSelfEvents: function() {
			this.jElement.
			 mousedown( this.onMouseDown.bind(this) ).
			 click( this.onClick.bind(this) );
		},
		
		onMouseDown: function(e) {
			var buttonName = this.getSenderButtonName(e);
			if (buttonName) {
				var button = this.nameMap[buttonName];
				if (button) {
					
				}
			}
		},
		
		onClick: function(e) {
			var buttonName = this.getSenderButtonName(e);
			if (buttonName) {
				var button = this.nameMap[buttonName];
				if (button) {
					if (this.isSelfToggle(button)) {
						button.changeToggleState();
					} else {
						button.fire( MMToolbar.CLICK_EVENT );
						if (button.toggleGroup) {
							this.selectInToggleGroup(button.toggleGroup, buttonName);
						}
					}
				}
			}
		},

		isSelfToggle: function(button) {
			return (button.toggleGroup === MMToolbar.SELF_TOGGLE);
		},

		getSenderButtonName: function(e) {
			var el = e.target;
			for (var i = 0;i < 3;++i) {
				if (el.getAttribute) {
					var name = el.getAttribute('data-button-name');
					if (name && name.length > 1) {
						return name;
					}
				}

				el = el.parentNode;
				if (!el) { break; }
			}
			
			return null;
		},
		
		setSelectedStateByname: function(buttonName, newState, suppress_event) {
			var b = this.nameMap[ buttonName ];
			if (b) {
				b.setToggleState(newState, suppress_event);
			}
		},
		
		getSelectedStateByName: function(buttonName) {
			var b = this.nameMap[ buttonName ];
			if (b) {
				return b.selected;
			}
			return null;
		},
		
		selectInToggleGroup: function(groupName, buttonName) {
			var g = this.toggleGroups[groupName];
			if (!g) { return false; }

			var len = g.length;
			for (var i = 0;i < len;++i) {
				var btn = g[i];
				if (btn.name === buttonName) {
					btn.changeToggleState(false);
				} else {
					btn.changeToggleState(true);
				}
			}
		}
	};



	// - - - - items - - - -
	var MMToolbarItemBasePrototype = {
		initOuterElement: function(asLink) {
			this.element = document.createElement(asLink ? 'a' : 'span');
			this.element.className = kToolButtonClassName;
			this.jElement = $(this.element);
		},
		
		getElement: function() {
			return this.element;
		},
		
		eventDispatcher: function() {
			return this.jElement;
		},
		
		fire: function(eventType) {
			this.eventDispatcher().trigger(eventType, this);
		}
	};
	
	function MMToolbarButtonItem(buttonName, longTitle, iconURL, toggleGroup, linkButton) {
		this.selected = false;
		this.dummyImage = null;
		this.initOuterElement(linkButton);
		this.element.title = longTitle;
		this.name = buttonName;
		this.toggleGroup = toggleGroup;
		this.element.className = kToolButtonClassName;
		this.element.style.backgroundImage = 'url('+ iconURL +')';
		this.element.setAttribute('data-button-name', buttonName);

		this.setupButtonImage(this.element);
	}
	
	MMToolbarButtonItem.prototype.initOuterElement= MMToolbarItemBasePrototype.initOuterElement;
	MMToolbarButtonItem.prototype.getElement      = MMToolbarItemBasePrototype.getElement;
	MMToolbarButtonItem.prototype.eventDispatcher = MMToolbarItemBasePrototype.eventDispatcher;
	MMToolbarButtonItem.prototype.fire            = MMToolbarItemBasePrototype.fire;

	MMToolbarButtonItem.prototype.configureLink = function(url, downloadName) {
		this.element.href = url;
		this.element.setAttribute('download', downloadName);
	};

	MMToolbarButtonItem.prototype.addLinkTrap = function(callback) {
		this.element.addEventListener('mousedown', callback, true);
		this.element.addEventListener('mouseover', callback, true);
		this.element.addEventListener('keydown', callback, true);
	};

	MMToolbarButtonItem.prototype.setupButtonImage = function(targetElement) {
		var s = targetElement.style;
		s.paddingLeft = s.paddingRight = s.paddingTop = s.paddingBottom = 0;
		
		this.dummyImage = document.createElement('img');
		this.dummyImage.src = 'images/l-buttons/LB-dmy.png';
		this.dummyImage.width  = kToolBarButtonDefaultWidth;
		this.dummyImage.height = kToolBarButtonDefaultHeight;

		this.dummyImage.className = kToolButtonCoverClassName;
		targetElement.appendChild(this.dummyImage);
	};
	
	MMToolbarButtonItem.prototype.changeToggleState = function(onlyWhen) {
		if (onlyWhen === false || onlyWhen === true) {
			if (this.selected !== onlyWhen) {
				return;
			}
		}
		
		this.setToggleState( !this.selected );
	};

	MMToolbarButtonItem.prototype.setToggleState = function(newState, suppress_event) {
		if (this.selected === newState) {
			return;
		}
		
		if (newState) {
			this.jElement.addClass('toggle-selected');
		} else {
			this.jElement.removeClass('toggle-selected');
		}
		
		this.selected = newState;
		if (!suppress_event) {
			this.fire(MMToolbar.TOGGLE_CHANGE_EVENT);
		}
	};
	
	MMToolbarButtonItem.prototype.enableOppositeSided = function() {
		$(this.element).addClass('mm-tb-opposite-sided');
	};

	// export
	pkg.MMToolbar = MMToolbar;
});
