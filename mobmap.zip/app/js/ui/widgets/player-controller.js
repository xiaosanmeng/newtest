if (!window.mobmap) { window.mobmap={}; }

(function(pkg) {
	'use strict';
		
	function PlayerController(imagePathBase, scalePreset) {
		this.imagePathBase = imagePathBase;
		this.columns = [];
		this.scalePreset = scalePreset;
		this.speedSlider = null;
		this.speedLabelElement = null;
		this.jPlayButton = null;

		this.element = $H('table', 'mm-playctrl-table');
		this.buildColumns(this.element);
		
		mmAddEventDispatcherMethod(this, this.element);
	}
	
	PlayerController.Event = {
		PlayButtonClick: 'playctrl-play-click',
		StopButtonClick: 'playctrl-stop-click',
		LiveButtonClick: 'playctrl-live-click',
		SpeedChange: 'playctrl-speed-change'
	};

	PlayerController.TestPreset = [1, 6, 10, 36, 60, 100, 360, 600, 1000, 3600, 6000, 3600*6];

	PlayerController.prototype = {
		getElement: function() {
			return this.element;
		},
		
		getLengthOfPreset: function() {
			return this.scalePreset.length;
		},
		
		buildColumns: function(tbl) {
			var tr = $H('tr');
			
			var c1  = $H('td');
			var c2  = $H('td');
			var c2x = $H('td', 'mm-playctrl-live-col');
			var c3  = $H('td', 'mm-playctrl-speed-slider-col');
			
			tbl.appendChild(tr);
			tr.appendChild(c1);
			tr.appendChild(c2);
			tr.appendChild(c2x);
			tr.appendChild(c3);
			
			this.columns.push(c1);
			this.columns.push(c2);
			this.columns.push(c2x);
			this.columns.push(c3);
			
			
			this.putStopButton(c1);
			this.putPlayButton(c2);
			this.putLiveButton(c2x);
			this.putSpeedSlider(c3);
		},
		
		setBasicColumnStyle: function(el) {
			el.style.border = 'none';
			el.style.margin = 0;
			el.style.padding = 0;
		},
		
		putStopButton: function(container) {
			var box = $H('div', 'mm-playctrl-button');
			box.style.backgroundImage = 'url(' +this.imagePathBase+ 'stop.png)';
			
			container.appendChild(box);
			$(box).click( this.onStopButtonClick.bind(this) );
			return box;
		},
		
		putPlayButton: function(container) {
			var box = $H('div', 'mm-playctrl-button');
			box.style.backgroundImage = 'url(' +this.imagePathBase+ 'play.png)';

			this.jPlayButton = $(box).click( this.onPlayButtonClick.bind(this) );

			container.appendChild(box);
			return box;
		},

		putLiveButton: function(container) {
			var box = $H('div', 'mm-playctrl-button mm-playctrl-live-button');
			box.style.backgroundImage = 'url(' +this.imagePathBase+ 'live.png)';
			$(box).click( this.onLiveButtonClick.bind(this) );

			container.appendChild(box);
			return box;
		},

		putSpeedSlider: function(container) {
			var s = $H('input', 'mm-playctrl-speed-controller');
			s.type = 'range';
			this.speedSlider = s;
			
			s.setAttribute('min', 0);
			s.setAttribute('max', this.getLengthOfPreset() - 1);
			s.value = this.getLengthOfPreset() >> 1;

			var lab = $H('span', 'mm-playctrl-speed-label');
			this.speedLabelElement = lab;
			lab.innerHTML = '▸▸ ×1';
			
			container.appendChild(s);
			container.appendChild(lab);
			
			$(s).change( this.onSpeedSliderChange.bind(this) );
			
			return s;
		},

		setPlayButtonSelected: function(sel) {
			if (sel) {
				this.jPlayButton.addClass('selected');
			} else {
				this.jPlayButton.removeClass('selected');
			}
		},

		onPlayButtonClick: function(e) {
			this.eventDispatcher().trigger(PlayerController.Event.PlayButtonClick, this);
		},
		
		onLiveButtonClick: function(e) {
			this.eventDispatcher().trigger(PlayerController.Event.LiveButtonClick, this);
		},

		onStopButtonClick: function(e) {
			this.eventDispatcher().trigger(PlayerController.Event.StopButtonClick, this);
		},

		forceSetSpeed: function(desired) {
			var ls = this.scalePreset;
			var len = ls.length
			
			for (var i = 0;i < len;++i) {
				var presetVal = ls[i];
				if (presetVal >= desired) {
					this.speedSlider.value = i;
					this.onSpeedSliderChange();
					break;
				}
			}
		},

		onSpeedSliderChange: function(e) {
			this.eventDispatcher().trigger(PlayerController.Event.SpeedChange, this);
		},
		
		getPresetMappedValue: function() {
			var raw = parseInt( this.speedSlider.value );
			return this.scalePreset[raw] || 1;
		},
		
		showSpeed: function(s) {
			this.speedLabelElement.innerHTML = '▸▸ ×' + (s | 0);
		}
	}

	pkg.PlayerController = PlayerController;
})(window.mobmap);