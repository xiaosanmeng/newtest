mmDefineModule(function(pkg) {
	'use strict';
	
	var kColorDataAttr = 'data-color';
	
	var kQuickPickPreset = [
		'#b63',
		'#cd4',
		'#0a4',
		'#4cc',
		'#37d',
		'#a4d',
		null,
		'#f00',
		'#ff0',
		'#0f0',
		'#0ff',
		'#00f',
		'#f0f',
		null,
		'#800',
		'#880',
		'#080',
		'#088',
		'#008',
		'#808',
		null,
		'#000',
		'#777',
		'#ccc',
		'#fff',
		'lime'
	];

	function QuickColorPicker(containerElement) {
		this.currentColor = '#37d';

		this.outerElement = null;
		this.jOuterElement = null;
		this.typeSelectElement = null;
		this.pagesContainerElement = null;
		this.quickSelectPageElement = null;
		this.opacityInput = null;
		
		this.buildElements(containerElement);
		this.jOuterElement = $( this.outerElement );
		
		//////
		this.typeSelectElement.style.display = 'none';
		//////
		
		this.addQuickPickPreset(this.quickSelectPageElement);
		this.addOpacityControl(this.opacityPageElement);
		this.observeEvents();
	}

	QuickColorPicker.SpecialColor_Var = 'lime';
	QuickColorPicker.PICKED_EVENT = 'qcp-color-picked';

	QuickColorPicker.prototype = {
		eventDispatcher: function() {
			return this.jOuterElement;
		},

		buildElements: function(containerElement) {
			this.outerElement = document.createElement('div');
			this.typeSelectElement = document.createElement('ul');
			this.pagesContainerElement = document.createElement('div');
			this.quickSelectPageElement = document.createElement('div');
			this.opacityCaptionElement = document.createElement('div');
			this.opacityPageElement = document.createElement('div');

			this.outerElement.className = 'qcp-outer';
			this.typeSelectElement.className = 'qcp-type-select';
			this.quickSelectPageElement.className = 'qcp-picker-page';
			this.opacityCaptionElement.className = 'qcp-section-header';
			this.opacityPageElement.className = 'qcp-picker-page';

			this.typeSelectElement.innerHTML = '<li>Colors</li>';
			this.opacityCaptionElement.innerHTML = 'Opacity';
			this.outerElement.appendChild( this.typeSelectElement );
			this.outerElement.appendChild( this.pagesContainerElement );
			this.outerElement.appendChild( this.opacityCaptionElement );
			this.outerElement.appendChild( this.opacityPageElement );
			
			this.pagesContainerElement.appendChild( this.quickSelectPageElement );

			containerElement.appendChild( this.outerElement );
		},
		
		addQuickPickPreset: function(containerElement) {
			var ls = kQuickPickPreset;
			var n = ls.length;
			
			for (var i = 0;i < n;++i) {
				if (!ls[i]) {
					containerElement.appendChild( document.createElement('br') );
					continue;
				}
				
				var clr = ls[i];
				
				var bx = document.createElement('span');
				bx.setAttribute(kColorDataAttr, clr);
				bx.className = 'qcp-quick-pick-item';
				if (clr === QuickColorPicker.SpecialColor_Var) {
					bx.className += ' qcp-special-color-item';
					bx.title = 'Marker color';
					
					var back_url = '#e0d9d4 url(' + QuickColorPicker.generateVaryingColorButtonImage(36, 12).toDataURL() + ')';
					bx.style.background = back_url + ' center center no-repeat';
				} else {
					bx.style.backgroundColor = clr;
				}
				
				containerElement.appendChild(bx);
			}
		},

		addOpacityControl: function(containerElement) {
			var range = document.createElement('input');
			range.style.width = '100px';
			range.type = 'range';
			range.min = 0;
			range.max = 10;
			range.value = 10;
			containerElement.appendChild( range );
			
			this.opacityInput = range;
			$(range).change( this.onOpacityRangeChange.bind(this) );
		},
		
		getOpacity: function() {
			var m = parseInt(this.opacityInput.max, 10);
			var raw = parseInt(this.opacityInput.value, 10);
			
			// Special value
			if (raw == 0) {
				raw = 0.2;
			}
			
			return raw / m;
		},

		observeEvents: function() {
			$( this.quickSelectPageElement ).click( this.onQuickPageClick.bind(this) );
		},
		
		onOpacityRangeChange: function() {
			this.firePicked();
		},
		
		onQuickPageClick: function(e) {
			var el = e.target;
			if (el && el.getAttribute) {
				var data = el.getAttribute('data-color');
				if (data && data.length > 2) {
					this.currentColor = data;
					this.firePicked();
				}
			}
		},
		
		firePicked: function() {
			this.eventDispatcher().trigger( QuickColorPicker.PICKED_EVENT, [this, this.currentColor, this.getOpacity()] );
		},
		
		showSelection: function(color) {
			var q = this.jOuterElement.find('.qcp-quick-pick-item');
			q.removeClass('selected');
			
			q.each(
				function(index, element) {
					var data_color = element.getAttribute(kColorDataAttr);
					if (data_color === color) {
						$(element).addClass('selected');
					}
				}
			);
		}
	};

	QuickColorPicker.generateVaryingColorButtonImage = function(w, h) {
		var cv = document.createElement('canvas');
		var g = cv.getContext('2d');
		cv.width = w;
		cv.height = h;
		
		var hh = h >> 1;
		var qw = w >> 2;
		
		for (var i = 0;i < 3;++i) {
			var x = qw * (i+1);
			var y = hh;
			
			g.save();
			
			g.lineWidth = 2;
			g.strokeStyle = 'rgba(0,0,0,0.75)';
			g.fillStyle = (i === 0) ? '#e94' : (i === 1) ? '#6a6' : '#59c';
			
			g.beginPath();
			g.arc(x, y, Math.floor(w/12), 0, Math.PI*2, false);
			g.stroke();
			g.fill();
			g.restore();
		}
		
		cv.style.backgroundColor = '#def';
		return cv;
	}

	// export
	pkg.QuickColorPicker = QuickColorPicker;
});