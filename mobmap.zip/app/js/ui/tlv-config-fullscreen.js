mmDefineModule(function(pkg) {
	'use strict';

	function TLVConfigScreen() {
		this.targetLayer = null;
		this.currentConfig = new mobmap.EventTimeline.Configuration();
		
		this.jElement = mobmap.FullScreenBox.createBaseElementJ();
		this.element = this.jElement[0];
		this.typeRadioElements = [];
		this.limitNumInput = null;
		this.layerNameCaption = null;
		this.attributeSelector = null;

		mobmap.FullScreenBox.setupFullScreen(this);
		var backButton = this.addBackButton();
		$(backButton).click( this.onBackButtonClick.bind(this) );
		this.addTitle('Timeline visualization');
		
		this.contentElement = $H('div', 'mm-tlv-config-screen-content');
		this.element.appendChild(this.contentElement);
		this.initContent(this.contentElement);
	}
	
	TLVConfigScreen.prototype = {
		initContent: function(contentElement) {
			this.layerNameCaption = $H('h3');
			contentElement.appendChild( this.layerNameCaption );
			this.fillTypeSelector(contentElement);
		},

		fillTypeSelector: function(container) {
			var box = $H('div', 'mm-tlv-config-screen-type-form');
			
			var TP = mobmap.EventTimeline.Types;
			this.addTypeRadio(box, ' Count records', TP.RecordCount);
			this.addTypeRadio(box, ' Sum of attribute values (one shot)', TP.AttributeSum);
			this.addTypeRadio(box, ' Sum of attribute values (remain)', TP.AttributeRemainSum);
			
			var attrSelector = $H('select');
			var attrSelLabel = $H('label');
			attrSelLabel.innerHTML = 'Target attribute: ';
			attrSelLabel.appendChild( attrSelector );
			box.appendChild(attrSelLabel);
			
			this.limitNumInput = this.addLimitNumBox(box);
			
			this.attributeSelector = attrSelector;
			container.appendChild(box);
		},

		addTypeRadio: function(parent, labelText, val) {
			var lab = $H('label');
			
			var r = $H('input');
			r.value = val;
			r.type = 'radio';
			r.name = 'mm-tlv-count-type-radio';
			this.typeRadioElements.push(r); // <---------- hold
			lab.appendChild(r);
			lab.appendChild($T(labelText));
			
			parent.appendChild(lab);
			parent.appendChild($H('br'));
			return lab;
		},

		addLimitNumBox: function(parent) {
			var lab = $H('label');
			lab.innerHTML = 'Limit num: ';
			
			var box = $H('input');
			box.type = 'number';
			box.min = 0;
			box.max = 999999;
			
			parent.appendChild( $H('br') );
			lab.appendChild(box);
			parent.appendChild(lab);
			
			return box;
		},

		prepareForSelectedLayer: function() {
			this.clearAttributeList();
			this.currentConfig.reset();
			this.layerNameCaption.innerHTML = 'No selected layer.';
			
			var app = this.getOwnerApp();
			if (app) {
				var layer = app.getSelectedLayer();
				if (layer) {
					// Copy config
					var etl = layer.getEventTimeline();
					if (etl) {
						this.currentConfig.copyFrom( etl.configuration );
					}
					
					this.layerNameCaption.innerHTML = '';
					this.layerNameCaption.appendChild($T( 'Layer: '+ layer.getShortDescription() ));
					this.prepareAttributeList(layer);
				}

				this.targetLayer = layer;
			}

			this.showOldConfiguration();
		},
		
		clearAttributeList: function() {
			this.attributeSelector.innerHTML = '';
		},
		prepareAttributeList: function(layer) {
			var that = this;
			
			var al = layer.attributeList;
			if (al) {
				al.eachAdditionalAttribute( function(attr) {
					that.addTargetAttribute(attr.name);
				} );
			}
		},
		addTargetAttribute: function(name) {
			var sel = this.attributeSelector;
			var op = $H('option');
			op.value = name;
			op.appendChild($T(name));

			sel.appendChild(op);
		},
		
		showOldConfiguration: function() {
			this.checkType( this.currentConfig.type );
			this.limitNumInput.value = this.currentConfig.numLimit;
			
			if (this.currentConfig.targetAttribute) {
				this.attributeSelector.value = this.currentConfig.targetAttribute;
			}
		},
		checkType: function(val) {
			var ls = this.typeRadioElements;
			for (var i = 0;i < ls.length;++i) {
				var r = ls[i];
				if ( parseInt(r.value, 10) === val ) { r.checked = true; }
			}
		},
		getTypeValue: function() {
			var ls = this.typeRadioElements;
			for (var i = 0;i < ls.length;++i) {
				var r = ls[i];
				if (r.checked) { return parseInt(r.value, 10); }
			}
			return 0;
		},
		getLimitValue: function() {
			return parseInt( this.limitNumInput.value , 10);
		},

		syncFromUI: function() {
			this.currentConfig.type = this.getTypeValue();
			this.currentConfig.setTargetAttribute( this.attributeSelector.value );
			this.currentConfig.setNumLimit( this.getLimitValue() );
		},
		sendNewValue: function() {
			if (this.targetLayer) {
				var etl  = this.targetLayer.getEventTimeline();
				if (etl) {
					var dest = etl.configuration;
					if ( !(dest.equals( this.currentConfig )) ) {
						// Write new configuration
						dest.copyFrom( this.currentConfig );
						this.targetLayer.etlInvalidate();
						
						// Notify
						this.targetLayer.fire(
							mobmap.LayerEvent.EventTimelineConfigChange,
							this.targetLayer
						);
					}
				}
			}
		},

		open: function() {
			this.targetLayer = null;

			this.prepareForSelectedLayer();
			this.show();
		},

		onBackButtonClick: function() {
			this.syncFromUI();
			this.sendNewValue();
			this.hide();
		},

		addBackButton: mobmap.FullScreenBox.addBackButton,
		addTitle: mobmap.FullScreenBox.addTitle,
		show: mobmap.FullScreenBox.show,
		hide: mobmap.FullScreenBox.hide
	};

	// base classes
	mobmap.installBaseMethods(  TLVConfigScreen.prototype, mobmap.AppOwnedBase  );

	pkg.TLVConfigScreen = TLVConfigScreen;
});