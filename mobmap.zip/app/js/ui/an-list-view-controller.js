mmDefineModule(function(pkg) {
	'use strict';

	function AnalysisObjectListViewController() {
		this.aoListView = null;
	}

	AnalysisObjectListViewController.getListItemViewOfModel = function(m) {
		return m._lv_view || null;
	};

	AnalysisObjectListViewController.prototype = {
		
		connectModelAndView: function(aoListView, modelEventDispatcher) {
			this.aoListView  = aoListView;

			modelEventDispatcher.
				bind(mobmap.MMSensorPool.Events.ItemAdded,     this.onSensorItemAdded.bind(this)).
				bind(mobmap.MMSensorPool.Events.ItemRemoved,   this.onSensorItemRemoved.bind(this)).
				bind(mobmap.MMLandSensor.Events.GroupItemAdded  , this.onSensorGroupSubItemAdded.bind(this) ).
				bind(mobmap.MMLandSensor.Events.GroupItemRemoved, this.onSensorGroupSubItemRemoved.bind(this) ).
				bind(mobmap.MMLandSensor.Events.TitleChanged, this.onSensorItemTitleChanged.bind(this)).
				bind(mobmap.MMLandSensor.Events.ViewFormChangeRequired, this.onSensorItemViewFormChangeRequested.bind(this)).
				bind(mobmap.MMLandSensor.Events.RemoveRequest, this.onSensorItemRemoveRequestSent.bind(this));

			aoListView.eventDispatcher().
				bind( mobmap.ALGroupBuilderView.DROP_EVENT, this.onGroupBuilderItemDrop.bind(this) );

			aoListView.
			 getTopToolBar().
			 eventDispatcher().
			 bind( mobmap.MMToolbar.CLICK_EVENT, this.onTopToolbarItemClick.bind(this) );
			
			// Setup link rewriter
			var xbtn = aoListView.getAllExportButton();
			xbtn.addLinkTrap( this.rewriteAllExportLink.bind(this, xbtn) );
		},

		onListViewMouseEnter: function(e) {
			var itemId = get_upper_item_id(e);
			if (itemId !== null) {
				this.getActiveLandSensorPool().fireHighlight(itemId, true);
			}
		},

		onListViewMouseLeave: function(e) {
			var itemId = get_upper_item_id(e);
			if (itemId !== null) {
				this.getActiveLandSensorPool().fireHighlight(itemId, false);
			}
		},

		onTopToolbarItemClick: function(e, toolButtonItem) {
			var pool;
			var bname = toolButtonItem.name;
			if (bname === mobmap.AnalysisObjectListView.kToolButtonName_AddGroup ) {
				// 'Add new group' command
				pool = this.getActiveLandSensorPool();
				if (pool) {
					var sensorGroup = mobmap.createLandSensorInstance(
						mobmap.LandSensorTypes.Group, 0, 0, 0, 0); 
					
					pool.add(sensorGroup);
				}
			} else if (bname === mobmap.AnalysisObjectListView.kToolButtonName_Export) {
				// Export analysis features
				
				// --> move to link rewriter
				
				/*
				pool = this.getActiveLandSensorPool();
				if (pool) {
					var serializedObject = pool.serialize();
					console.log( JSON.stringify(serializedObject, null, ' ') );
					this.saveTextContent( JSON.stringify(serializedObject, null, ' ') );
				}
				*/
			} else if (bname === mobmap.AnalysisObjectListView.kToolButtonName_Import) {
				// BUTTON : JSON importer
				var loader = new mobmap.LandSensorFileImporter( this.getCurrentProject() );
				loader.openFileDialog();
			} else if (bname === mobmap.AnalysisObjectListView.kToolButtonName_ShapeImport) {
				// BUTTON : Shapefile importer
				const app = this.getOwnerApp();
				const shp_scr = app.ensureShapeImporterScreen();
				
				shp_scr.initAndOpen( app.getCurrentProject() );
			}
		},

		rewriteAllExportLink: function(exportButton) {
			var pool = this.getActiveLandSensorPool();
			if (pool) {
				var serializedObject = pool.serialize();
				var content = JSON.stringify(serializedObject, null, ' ');
				
				exportButton.configureLink('data:text/plain,' + content, "mobmap-gates-exported.json");
			}
		},

		// NOT USED (old ver.)
		saveTextContent: function(s) {
			var app = this.getOwnerApp();
			if (!app) { return; }

			app.saveSmallTextAsLocalFile(s);
		},

		getCurrentProject: function() {
			var app = this.getOwnerApp();
			if (!app) { return null; }
			
			return app.getCurrentProject();
		},

		getActiveLandSensorPool: function() {
			var pj = this.getCurrentProject();
			if (!pj) { return null; }

			return pj.getLandSensorPool();
		},

		onSensorItemAdded: function(e, sensorPool, newItem) {
			var liView = this.ensureViewForModel(newItem, sensorPool);
		},

		onSensorItemRemoved: function(e, sensorPool, removedItem) {
			this.disposeViewForModel(removedItem);
		},

		onSensorItemTitleChanged: function(e, senderItem, newValue) {
			var v = this.aoListView.getByItemId(senderItem.getId());
			if (v) {
				v.setTitle(newValue);
			}
			
			this.aoListView.bulkCall('changeSubItemTitleIf', senderItem.getId(), newValue);
		},

		onSensorItemViewFormChangeRequested: function(e, senderItem, newFormName) {
			var v = senderItem._lv_view;
			if (v && v.changeGroupForm) {
				v.changeGroupForm(newFormName);
			}
		},

		ensureViewForModel: function(itemModel, sensorPool) {
			if (!( itemModel._lv_view )) {
				var ii = this.calcInsertIndex(itemModel, sensorPool);
				var vw = this.aoListView.newGateItem( itemModel, ii );
				itemModel._lv_view = vw;

				vw.jElement.
				 mouseenter( this.onListViewMouseEnter.bind(this) ).
				 mouseleave( this.onListViewMouseLeave.bind(this) );

				vw.observeRemoveButtonClick( this.onLVItemRemoveButtonClick.bind(this, itemModel) );
				this.addExportLinkUpdater(vw, itemModel);
			}
			
			this.setToolbarInitialState(itemModel);
			this.observeItemToolbar(itemModel);

			return itemModel._lv_view;
		},

		addExportLinkUpdater: function(lvItem, itemModel) {
			var f = this.rewriteExportURL;
			var btn = lvItem.getExportButton();
			if (btn) {
				btn.addLinkTrap(function() {
					f(lvItem, itemModel);
				});
			}
		},

		rewriteExportURL: function(v, model) {
			if (v && v.updateExportLink) {
				var serObj = model.serialize();
				var j = JSON.stringify( [ serObj ] );
				v.updateExportLink('data:text/plain,' + j, model.getTitle());
			}
		},

		setToolbarInitialState: function(listItem) {
			var v = listItem._lv_view;
			if (!v) { return; }

			if (v.getMainToolBar) {
				var tb = v.getMainToolBar();
				
				if (listItem.type === mobmap.LandSensorTypes.Group) {
					var formName = v.getCurrentFormName();
					tb.setSelectedStateByname(formName, true, true);
				} else {
					tb.setSelectedStateByname(mobmap.AnalysisObjectListView.kItemToolButtonName_Visibility, listItem.getVisibility(), true);
				}
			}	
		},

		observeItemToolbar: function(listItem) {
			var v = listItem._lv_view;
			if (!v) { return; }

			if (v.getMainToolBar) {
				v.getMainToolBar().
				 eventDispatcher().
				 bind( mobmap.MMToolbar.TOGGLE_CHANGE_EVENT, this.onItemToolBarToggle.bind(this, listItem) );
			}
		},

		calcInsertIndex: function(newItem, sensorPool) {
			var iAfter = sensorPool.getItemAfter(newItem);
			if (!iAfter) {
				return -1;
			}

			return this.aoListView.getIndexOf(iAfter._lv_view);
		},

		disposeViewForModel: function(itemModel) {
			if (itemModel._lv_view) {
				itemModel._lv_view.off();
				this.aoListView.removeItem(itemModel._lv_view);
				itemModel._lv_view = null;
			}
		},
		
		onGroupBuilderItemDrop: function(e, groupBox, dropEvent) {
			if (dropEvent.draggable && dropEvent.draggable.element) {
				var el = dropEvent.draggable.element[0];
				
				if ( is_item_el(el) ) {
					this.onItemElementDrop(groupBox, el);
				}
			}
		},
		
		onItemElementDrop: function(groupBox, itemElement) {
			var pool = this.getActiveLandSensorPool();
			var itemId = parseInt( itemElement.getAttribute( mobmap.AnalysisObjectListView.kItemIdAttrName ) );
			
			var groupItem   = pool.findBySeqId( groupBox.getOwnerGroupId() );
			var droppedItem = pool.findBySeqId( itemId );
			if (groupItem && droppedItem) {
				groupItem.addGroupItem(droppedItem, groupBox.index);
			}
		},

		onItemToolBarToggle: function(itemModel, e, button) {
			var v = itemModel._lv_view;
			if (itemModel.type === mobmap.LandSensorTypes.Group) {
				if (v && button.selected) {
					v.changeGroupForm(button.name);
				}
			} else {
				if (button.name === mobmap.AnalysisObjectListView.kItemToolButtonName_Visibility) {
					itemModel.setVisibility(button.selected);
				}
			}
		},


		onSensorGroupSubItemAdded: function(e, groupItem, subIndex, targetItem) {
			var gview = AnalysisObjectListViewController.getListItemViewOfModel(groupItem);
//			var itemId = targetItem.getId();
			
			gview.addSubItem(targetItem, subIndex);
//			console.log('>', groupItem, subIndex, targetItem )
		},
		
		onSensorGroupSubItemRemoved: function(e, groupItem, subIndex, targetItem) {
			var gview = AnalysisObjectListViewController.getListItemViewOfModel(groupItem);
			
			gview.removeSubItemWithId(targetItem.getId(), subIndex);
//			console.log('<',  groupItem, subIndex, targetItem )
		},
		
		onLVItemRemoveButtonClick: function(item) {
			item.requestRemove();
		},
		
		onSensorItemRemoveRequestSent: function(e, targetItem) {
			var dlg = this.getOwnerApp().getConfirmDialog();
			dlg.showDialogOnCenter(
				'Remove analysis item',
				'Item "' + targetItem.getTitle() + '" will be removed.',
				{
					'ok': this.onRemoveDialogOkClick.bind(this),
					targetItem: targetItem
				});
		},
		
		onRemoveDialogOkClick: function(senderDialog, callbackSetting) {
			callbackSetting.targetItem.removeSelf();
		}
	};

	function is_item_el(el) {
		return el.getAttribute && 
			parseInt( el.getAttribute( mobmap.AnalysisObjectListView.kItemFlagAttrName ) ) === 1;
	}
	
	function get_upper_item_id(event) {
		var el = findUpperItemElement(event.target);
		if (el) {
			return parseInt( el.getAttribute( mobmap.AnalysisObjectListView.kItemIdAttrName ) );
		}

		return null;
	}

	function findUpperItemElement(el) {
		for (var i = 0;i < 5 && (!!el);++i) {
			if ( is_item_el(el) ) {
				return el;
			}
			
			el = el.parentNode;
		}
		
		return null;
	}


	// base classes
	mobmap.installBaseMethods(  AnalysisObjectListViewController.prototype, mobmap.AppOwnedBase  );

	// export
	pkg.AnalysisObjectListViewController = AnalysisObjectListViewController;
});