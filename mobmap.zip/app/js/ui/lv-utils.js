mmDefineModule(function(pkg) {
	'use strict';

	var LVUtility = {
		putTitleBarRemoveButton: function(titleElement) {
			return this.putTitleBarToolButton(titleElement,  'mm-ontitle-button mm-layer-remove-button', 'trash', 'Remove');
		},

		putTitleBarUpButton: function(titleElement) {
			return this.putTitleBarToolButton(titleElement,  'mm-ontitle-button mm-layer-up-button', 'up', 'Move up');
		},

		putTitleBarToolButton: function(titleElement, elementClass, filename, title) {
			var img = $H('img', elementClass);
			img.src = 'images/l-buttons/LB-' +filename+ '.png';
			img.title = title;
			
			titleElement.appendChild(img);
			
			return $(img);
		},
		
		addToolbarButtons: function(tb, itemList) {
			// item = { name , tip text , filename suffix , self-toggle }

			for (var i in itemList) if (itemList.hasOwnProperty(i)) {
				var item = itemList[i];
				var btn = tb.addButtonItem(item[0], item[1], 'images/l-buttons/LB-' +item[2]+ '.png'  ,item[3] ? mobmap.MMToolbar.SELF_TOGGLE : null);
				
				if (item[4]) {
					btn.enableOppositeSided();
				}
 			}
		}
	};

	// export
	pkg.LVUtility = LVUtility;
});