mmDefineModule(function(pkg) {
	'use strict';
	var kToolsBarHeight = 59;
	
	// Pane View Manager - - - - - - - - - - - - - - - - -
	function Mobmap3PanesScreen(paneOuterId, bodyPaneId, toolsPaneId) {
		this.toolsPaneElement       = 
			this.outerElement       = 
			this.infoPaneElement    = 
			this.extPaneElement     = 
			this.contentElement     = 
			this.jOuterElement      = 
			this.outerSplitter      = 
			this.innerSplitter      = 
			this.jBody              = 
			this.handleWindowResize = null;
		// ----------------------------------------------------------
		mmAddEventDispatcherMethod(this, document.body);
		this.toolsHeight = kToolsBarHeight;
		this.fetchElements(paneOuterId, bodyPaneId, toolsPaneId);
		this.handleWindowResize = this.setupAutoFitToWindow();
		
		// Generate splitter and all panes
		this.buildTopLevelPanes(bodyPaneId);
	}

	Mobmap3PanesScreen.RESIZE_EVENT = "mmscreen-resize";
	Mobmap3PanesScreen.prototype = {
		// == Useful getters ==
		getToolsPaneElement:   function() { return this.toolsPaneElement; },
		getInfoPaneElement:    function() { return this.infoPaneElement; },
		getContentPaneElement: function() { return this.contentElement; },
		getExtPaneElement:     function() { return this.extPaneElement; },

		// == Initialize ==
		fetchElements: function(paneOuterId, bodyPaneId, toolsPaneId) {
			this.outerElement = document.getElementById(paneOuterId);
			this.jOuterElement = $(this.outerElement);

			this.toolsPaneElement = document.getElementById(toolsPaneId);
		},
		
		buildTopLevelPanes: function(bodyPaneId) {
			// Panes:
			//  Tools
			//  --------------
			//  others

			this.outerSplitter = $(this.outerElement).kendoSplitter({
				orientation: "vertical",
				panes: [
					{resizable: false,size:$px(this.toolsHeight), scrollable:false},
					{resizable: true, scrollable:false} // Bottom container
				]
			});

			this.buildInsideBodyPane(bodyPaneId);
		},
		
		buildInsideBodyPane: function(bodyPaneId) {
			// Panes:
			//  Loader,Layers |  Map  |  Extension

			var bodyPane = document.getElementById(bodyPaneId);
			var jBody = $(bodyPane);
			var splitter = jBody.kendoSplitter({
				orientation: "horizontal",
				panes:[
				 {collapsible: true, size:'240px', scrollable:false},
				 {scrollable:false},
				 {collapsible: true, size:'240px', scrollable:false, collapsed: true}
				],
				collapse: this.onInfoPaneCollapse.bind(this),
				expand:   this.onInfoPaneExpand.bind(this),
				resize:   this.onInfoPaneSplitterResize.bind(this)
			});

			this.innerSplitter = splitter.data('kendoSplitter');

			// Pick up child panes
			var childPanes = jBody.find('>div.mm-pane');
			this.infoPaneElement = childPanes[0] || null;
			this.contentElement  = childPanes[1] || null;
			this.extPaneElement  = childPanes[2] || null;
		},

		toggleExtPane: function() {
			if (this.innerSplitter && this.extPaneElement) {
				this.innerSplitter.toggle(this.extPaneElement);
			}
		},

		// Resize handler
		setupAutoFitToWindow: function() {
			var j = $(window);
			var closure = this.resizePanes.bind(this, j);
			j.resize(closure);

			closure();
			return closure;
		},

		resizePanes: function(jResizeParent) {
			var h = jResizeParent.height();
			this.jOuterElement.height(h);

			this.fireResize();
		},
		
		fireResize: function(delayTime) {
			setTimeout(this.fire.bind(this, Mobmap3PanesScreen.RESIZE_EVENT), delayTime || 1);
		},
		
		// Splitter event handlers
		onInfoPaneCollapse: function()       { this.handleWindowResize(); },
		onInfoPaneExpand: function()         { this.handleWindowResize(); },
		onInfoPaneSplitterResize: function() { this.handleWindowResize(); }
	};
	
	Mobmap3PanesScreen.observeScreenResize = function(pane, scr) {
		scr.eventDispatcher().bind(mobmap.Mobmap3PanesScreen.RESIZE_EVENT,
			pane.afterScreenResize.bind(pane));
		
		pane.afterScreenResize();
	};
	
	// +++ Export +++
	pkg.Mobmap3PanesScreen = Mobmap3PanesScreen;
});