mmDefineModule(function(pkg) {
	'use strict';

	var FullScreenBox = {
		createBaseElementJ: function() {
			var element = $H('div');
			return $(element).hide().addClass('mm-loader-screen-base');
		},
		
		setupFullScreen: function(that) {
			// Auto set style
			var s = that.element.style;
			s.position = 'fixed';
			s.top = 0;
			s.left = 0;


			var b = document.body;
			b.appendChild(that.element);
			
			var j = $(b)
			var closure = this.onContainerResize.bind(that, j);
			$(window).resize( closure );
			
			closure();
		},
		
		onContainerResize: function(jContainer) {
			var w = jContainer.width();
			var h = jContainer.height();

			var j = this.jElement;
			j.width(w).height(h);
		},
		
		show: function() {
			this.jElement.show();
		},
		
		hide: function() {
			this.jElement.hide();
		},

		addBackButton: function() {
			var bb = $H('a', 'mm-fullscreen-backbutton');
			bb.appendChild( $T('◄ Back'));
			
			this.element.insertBefore(bb, this.element.firstChild);
			return bb;
		},

		addExecuteButton: function(containerElement, text) {
			var btn = $H('button', 'execute-button');
			btn.appendChild( $T(text) );
			
			containerElement.appendChild(btn);
			return btn;
		},

		addTitle: function(text) {
			var h = $H('h2');
			h.appendChild( $T(text));
			
			this.element.insertBefore(h, this.element.firstChild);
		},

		addFooterArea: function() {
			var el = $H('div', 'mm-fullscreen-footer');
			this.element.appendChild(el);
			return el;
		}
	};

	pkg.FullScreenBox = FullScreenBox;
});
