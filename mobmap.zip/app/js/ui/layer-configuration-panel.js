mmDefineModule(function(pkg) {
	'use strict';

	function LayerConfigurationPanel() {
		this.element = document.createElement('div');
		this.element.className = 'mm-layer-config';
		this.jElement = $(this.element);

		this.opened = false;
	}
	
	LayerConfigurationPanel.prototype = {
		setOpened: function(bOpened) {
			this.opened = bOpened;
			if (bOpened) {
				this.jElement.addClass('opened');
			} else {
				this.jElement.removeClass('opened');
			}
		},

		getElement: function() {
			return this.element;
		}
	};

	// export
	pkg.LayerConfigurationPanel = LayerConfigurationPanel;
});