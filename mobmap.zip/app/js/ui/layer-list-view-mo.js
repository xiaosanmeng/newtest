mmDefineModule(function(pkg) {
	'use strict';
	var kNoBind = ',none,';
	var kMarkerPreviewLightBackground = '#ddd';
	var kMarkerPreviewDarkBackground = '#000';
	
	// Form name sequence IDs
	var gMarkerConfigRadioSeq = 0;
	var gTrajCmpConfigRadioSeq = 0;
	var gTrajStyleConfigRadioSeq = 0;
	var gMarkerCmpConfigRadioSeq = 0;
	var gMarkerSizingRadioSeq = 0;
	var gTrajLimitRadioSeq = 0;

	function LayerListViewMovingObjectItem() {
		this.mconf = null;
		this.selToolbarLabel = null;
		this.attrbindSelectElement = null;
		this.coloringListElement = null;
		this.jTailConfigSection = null;
		this.jTrajectoryConfigSection = null;
		this.trajectoryColorPicker = null;
		this.tailLengthNumInput = null;
		this.perceptualScalingCheckbox = null;
		this.remainOutsideCheckbox = null;
		
		this.jLimitDistanceRadios    = null;
		this.jLimitDistanceConfigBox = null;
		this.jLimitDistanceNumber    = null;
		this.jLimitTimeConfigBox     = null;
		this.jLimitTimeNumber        = null;

		this.markerSequencePreviewOuterElement = null;
		this.markerSequencePreviewCanvas  = null;
		
		this.initBaseProperties();
		this.generateBoxElement();
	}
	
	LayerListViewMovingObjectItem.NoBind = kNoBind;
	
	LayerListViewMovingObjectItem.TrajLimitNone     = 0;
	LayerListViewMovingObjectItem.TrajLimitDistance = 1;
	LayerListViewMovingObjectItem.TrajLimitTime     = 2;
	
	LayerListViewMovingObjectItem.prototype = {
		generateAdditionalToolBars: function(containerElement) {
			var tb = new mobmap.MMToolbar();
			tb.addClass('layer-selection-tool-bar');
			this.selToolbarLabel = tb.addLabelItem('000', 'sel-toolbar-title-label');
			tb.addButtonItem(mobmap.LayerListView.kToolButtonName_SelClear,       'Clear',    'images/l-buttons/LB-x2.png');
			
			this.selToolbarLabel.title = "Selection";
			containerElement.appendChild(tb.getElement());
			tb.hide();
			this.selectionToolbar = tb;
		},

		resizeFlexibleElements: function() {
			if (!this.jElement) { return; }
			
			this.pvFitWidth(this.jElement);
			
			var containerWidth = this.jElement.width() | 0;
			if (this.markerSequencePreviewCanvas) {
				var sw = this.markerSequencePreviewCanvas.width | 0;
				var newWidth = containerWidth - 4;
				if (sw !== newWidth) {
					this.markerSequencePreviewCanvas.width = newWidth;
					this.updateMarkerSequencePreview();
				}
			}
		},
		
		observeTypeSpecificEvents: function() {
			var m = this.getModel();
			if (m) {
				m.eventDispatcher().
				 bind(mobmap.MarkerOptionModelProxy.CHANGE_EVENT, this.onMarkerOptionChange.bind(this));
			}
		},

		observeTrajectoryConfigurationSection: function(
			colorPickerHandler,
			compositionHandler,
			lineStyleHandler,
			limitChkHandler,
			limitNumHandler,
			limitTimeNumHandler)  {

			if (colorPickerHandler && this.trajectoryColorPicker) {
				this.trajectoryColorPicker.
				     eventDispatcher().
				     bind(  mobmap.QuickColorPicker.PICKED_EVENT, colorPickerHandler  );
			}
			
			if (compositionHandler) {
				this.findTrajectoryCompositionRadios().click(
					compositionHandler
				);
			}
			
			if (lineStyleHandler) {
				this.findTrajectoryLineStyleRadios().click(
					lineStyleHandler
				);
			}
			
			if (limitChkHandler) {
				this.getJLimitDistanceRadios().
					click( limitChkHandler );
			}
			
			if (limitNumHandler) {
				this.getJLimitDistanceNumber().
					change(limitNumHandler).
					keyup(limitNumHandler);
			}
			
			if (limitTimeNumHandler) {
				this.getJLimitTimeNumber().
					change(limitTimeNumHandler).
					keyup(limitTimeNumHandler);
			}
		},

		findTrajectoryCompositionRadios: function() {
			return this.jTrajectoryConfigSection.find('.mm-trajcomp-radio');
		},

		findTrajectoryLineStyleRadios: function() {
			return this.jTrajectoryConfigSection.find('.mm-trajstyle-radio');
		},

		notifySelectionChange: function() {
			var selp = this.getModel().getSelectionPool();
			var n = selp.count();
			this.selToolbarLabel.innerHTML = (n | 0);
			this.selToolbarLabel.title = n + " selected";

			if (n > 0) {
				this.selectionToolbar.show();
			} else {
				this.selectionToolbar.hide();
			}
		},
		
		onMarkerOptionChange: function() {
			this.syncFromMarkerOptionModel();
			this.pvUpdateLayerPreview();
		},
		
		// [][][] Configuration panel [][][]
		fillConfigurationPanelContent: function(panel) {
			var panel_el = panel.getElement();

			// + DATA SECTION
			this.generateDataConfigurationBox(panel_el);

			// + MARKER SECTION
			this.generateMarkerConfigurationBox(panel_el);
			
			// + TAIL SECTION
			this.jTailConfigSection = $( this.generateTailConfigurationBox( panel_el ) );

			// + TRAJECTORY SECTION
			this.jTrajectoryConfigSection = $(
				this.generateTrajectoryConfigurationBox( panel_el )
			).hide();
		},

		generateMarkerConfigurationBox: function(containerElement) {
			var box = this.addConfigurationSectionBox(containerElement, 'mm-marker-conf', 'Marker', 'images/symbol-mk.png', true); 

			this.generateMarkerSequencePreviewBox( box );
			
			// 'Num of markers' slider
			var n_pair = mobmap.LayerConfigWidgets.generateNumMarkers(
				this.onNumSliderChange.bind(this)
			);
			box.appendChild(n_pair.label);

			// 'Index scaling' slider
			var s_pair = mobmap.LayerConfigWidgets.generateNumIndexScaling(
				this.onIndexScalingSliderChange.bind(this)
			);
			box.appendChild(s_pair.label);

			this.mconf = {
				jNumOfMarkers: n_pair.jInput,
				jNumIndexScaling: s_pair.jInput
			};

			this.generateAttributeBindConfigurationBox( box );
			this.generateMarkerSizingChooser( box );
			this.generateMarkerCompositionChooser( box );
			this.generatePresetSelector( box );
			
			return box;
		},

		// - - - Configuration panel sections - - -

		// panel creation - - -

		generateMarkerCompositionChooser: function(containerElement) {
			mobmap.LayerListView.addConfigSubCaption(containerElement, 'Composition');

			var box = $H('div', 'mm-markercomp-conf');
			var rname = 'mcmp-radio-' + (++gMarkerCmpConfigRadioSeq);
			mobmap.LayerConfigWidgets.generateCompositionRadioSet(box, rname, 'mm-markercomp-radio');

			containerElement.appendChild(box);
			return box;
		},

		generateMarkerSizingChooser: function(containerElement) {
			var rname = 'msizing-radio-' + (++gMarkerSizingRadioSeq);
			var box = mobmap.LayerConfigWidgets.generateSizingRadioSet(rname);

			// Perceptual scaling option
			var pair = generateInputWithLabel({
				text: 'Perceptual scaling',
				type: 'checkbox',
				reverse: true,
				labelClass: 'mm-perceptual-scaling-checkbox'
			});
			box.appendChild(pair.label);
			this.perceptualScalingCheckbox = pair.input;

			containerElement.appendChild(box);
		},

		// __________________________________________
		// o   o  o o o  COLORING RULES  o o o  o   o
		generatePresetSelector: function(containerElement) {
			var caption = mobmap.LayerListView.addConfigSubCaption(containerElement, 'Coloring');
			this.coloringListElement = $H('div');
			containerElement.appendChild(this.coloringListElement);

			// More colors...
			var a_btn = mobmap.LayerConfigWidgets.generatePresetAppendButton(caption);
			$(a_btn).click( this.onColorPresetAddButtonClick.bind(this) );
		},

		fillPresetSelector: function() {
			var containerElement = this.coloringListElement;
			if (containerElement.childNodes.length > 0) { return; }
			// Abort if NOT explicitly cleared

			var layer = this.getModel();
			var mopt = layer.getMarkerOption();
			var rname = 'mcolor-radio-' + (++gMarkerConfigRadioSeq);

			mobmap.generateMarkerSetPresetPreviewImages(function(presetData, previewCanvas, seqIndex, allCount) {
				var radio = mobmap.LayerConfigWidgets.generateMarkerColoringRadio(
					seqIndex, rname,
					containerElement, presetData, previewCanvas
				);

				if ( (seqIndex % 2) && seqIndex < (allCount-1) ) {
					containerElement.appendChild( document.createElement('br') );
				}
			}, mopt.getCustomColoringList() );
		},

		clearPresetSelector: function() {
			var containerElement = this.coloringListElement;
			var n = containerElement.childNodes.length;
			for (var i = (n-1);i >= 0;--i) {
				var ch = containerElement.childNodes[i];
				containerElement.removeChild(ch);
			}
		},


		generateMarkerSequencePreviewBox: function(containerElement) {
			var box = $H('div', 'mm-marker-seq-preview');

			var cv = document.createElement('canvas');
			cv.height = mobmap.LayerListView.kMarkerPreviewStandardHeight;
			cv.style.backgroundColor = kMarkerPreviewLightBackground;

			this.markerSequencePreviewOuterElement = box;
			this.markerSequencePreviewCanvas = cv;
			
			box.appendChild(cv);
			containerElement.appendChild(box);
			
			return box;
		},

		setMarkerSequencePreviewDark: function(enabled) {
			this.markerSequencePreviewCanvas.style.backgroundColor = 
			 enabled ? kMarkerPreviewDarkBackground : kMarkerPreviewLightBackground;
		},

		generateAttributeBindConfigurationBox: function(containerElement) {
			var box = $H('div', 'mm-marker-attrbind-conf');

			var lab = $H('label');
			lab.innerText = 'Bind attr ';
			
			var sel = $H('select');
			lab.appendChild(sel);

			box.appendChild(lab);
			containerElement.appendChild(box);
			
			this.attrbindSelectElement = sel;
		},

		addConfigurationSectionBox: function(containerElement, boxClass, title, iconURL, isSecondary) {
			var box = $H('div', boxClass);
			var h = mobmap.LayerListView.addConfigCaption(box, title, iconURL);
			if (isSecondary) {
				h.className += ' secondary-section';
			}
			
			containerElement.appendChild(box);
			return box;
		},

		// : : : : : : data configuration : : : : : :
		
		generateDataConfigurationBox: function(containerElement) {
			var box = this.addConfigurationSectionBox(containerElement,  'mm-layerdata-conf', 'Data', 'images/symbol-dat.png', false);
			
			// Perceptual scaling option
			var pair = generateInputWithLabel({
				text: 'Remain out-of-time records',
				type: 'checkbox',
				reverse: true,
				labelClass: 'mm-remainout-checkbox'
			});
			box.appendChild(pair.label);
			this.remainOutsideCheckbox = pair.input;
			
			return box;
		},
		
		// <-<-<-<-<-<-<-<- Tail Configuration ->->->->->->->->
		generateTailConfigurationBox: function(containerElement) {
			var box = this.addConfigurationSectionBox(containerElement,  'mm-tail-conf', 'Tail', 'images/symbol-tail.png', true);

			mobmap.LayerListView.addConfigSubCaption(box, 'Length');
			var numLen = $H('input');
			numLen.type = 'number';
			numLen.min = '1';
			numLen.max = '9999';
			box.appendChild(numLen);
			box.appendChild($T(' sec.'));

			this.tailLengthNumInput = numLen;
			return box;
		},

		showTailConfigurationSection: function(v) {
			if (v) { this.jTailConfigSection.show(); }
			else   { this.jTailConfigSection.hide(); }
		},

		syncTailConfigurationSectionVisibility: function() {
			var tb = this.getMainToolBar();
			var pushed = tb.getSelectedStateByName( mobmap.LayerListView.kToolButtonName_Tail );

			this.showTailConfigurationSection(pushed);
		},

		setTailDurationValue: function(v) {
			var old = this.getTailDurationValue();
			if (old !== v) {
				this.tailLengthNumInput.value = v;
			}
		},

		getTailDurationValue: function() {
			return parseInt( this.tailLengthNumInput.value , 10);
		},

		getTailDurationNumInput: function() {
			return this.tailLengthNumInput;
		},

		// -___---__- trajectory configuration -__---___-
		generateTrajectoryConfigurationBox: function(containerElement) {
			var box = this.addConfigurationSectionBox(containerElement,  'mm-trajoverlay-conf', 'Trajectory', 'images/symbol-trj.png', true);

			// Composition selector   - - - - - - - - - - - - - - - -
			mobmap.LayerListView.addConfigSubCaption(box, 'Composition');
			this.generateTrajectoryCompositionTypeChooser(box);

			// Coloring selector   - - - - - - - - - - - - - - - -
			mobmap.LayerListView.addConfigSubCaption(box, 'Coloring');
			var picker = new mobmap.QuickColorPicker(box);
			this.trajectoryColorPicker = picker;

			// Linestyle selector   - - - - - - - - - - - - - - - -
			mobmap.LayerListView.addConfigSubCaption(box, 'Line Style');
			mobmap.LayerConfigWidgets.generateTrajectoryLineStyleChooser(box , ++gTrajStyleConfigRadioSeq );
			
			// Limit distance - - - - - - - - - - -
			this.generateLimitDistanceConfig(box);

			return box;
		},

		generateTrajectoryCompositionTypeChooser: function(containerElement) {
			var box = $H('div', 'mm-trajcomp-conf');
			var rname = 'tcmp-radio-' + (++gTrajCmpConfigRadioSeq);
			mobmap.LayerConfigWidgets.generateCompositionRadioSet(box, rname, 'mm-trajcomp-radio');

			containerElement.appendChild(box);
			return box;
		},
		
		// == LIMIT DISTANCE ===
		generateLimitDistanceConfig: function(containerElement) {
			var box = document.createElement('span');
			this.jLimitDistanceConfigBox = $(box).hide();
			this.jLimitDistanceNumber = mobmap.LayerConfigWidgets.generateLimitConfigNumberInput(box, true);

			var t_box = document.createElement('span');
			this.jLimitTimeConfigBox = $(t_box).hide();
			this.jLimitTimeNumber = mobmap.LayerConfigWidgets.generateLimitConfigNumberInput(t_box, false);
			
			// Radio(limit type)
			mobmap.LayerListView.addConfigSubCaption(containerElement, 'Limit trajectory by');
			var rname = 'trajlimit-radio-' + (++gTrajLimitRadioSeq);
			function make_radio(lab, val, sideBox) {
				mobmap.LayerConfigWidgets.generateTrajLimitRadio(containerElement, rname, lab, val, sideBox);
			}
			
			var L = LayerListViewMovingObjectItem;
			make_radio('None',     L.TrajLimitNone);
			make_radio('Distance ', L.TrajLimitDistance, box);
			make_radio('Time ',     L.TrajLimitTime, t_box);
			
			this.jLimitDistanceRadios = $(containerElement).find("input[name=\""+rname+"\"]");
			return box;
		},

		// --== toggle ==--
		showTrajectoryConfigurationSection: function(v) {
			if (v) { this.jTrajectoryConfigSection.show(); }
			else   { this.jTrajectoryConfigSection.hide(); }
		},
		
		showLimitDistanceConfigBox: function(v) {
			if (v) { this.jLimitDistanceConfigBox.show(); }
			else   { this.jLimitDistanceConfigBox.hide(); }
		},

		showLimitTimeConfigBox: function(v) {
			if (v) { this.jLimitTimeConfigBox.show(); }
			else   { this.jLimitTimeConfigBox.hide(); }
		},

		// panel events - - -

		bindAttrBindSelectChange: function(handler) {
			if (this.attrbindSelectElement) {
				$(this.attrbindSelectElement).change(handler);
			}
		},

		getAttrBindSelectValue: function() {
			return this.attrbindSelectElement.value;
		},

		syncTypeSpecData: function() {
			this.syncFromMarkerOptionModel();
		},

		syncFromMarkerOptionModel: function() {
			this.syncNumOfMarkersFromModel();
			this.updateMarkerSequencePreview();
		},

		updateMarkerSequencePreview: function() {
			var mg = this.getAssociatedMarkerGenerator();
			if (mg && this.markerSequencePreviewCanvas) {
				mg.generate();
				mg.renderPreview(this.markerSequencePreviewCanvas);
			}
		},

		pvUpdateLayerPreview: function() {
			this.updateMovingMarkerPreview();
		},

		updateMovingMarkerPreview: function() {
			var mg = this.getAssociatedMarkerGenerator();
			if (mg) {
				var layer = this.getModel();
				var varying = !!(layer.getMarkerOption().getMarkerColorBoundAttribute());
				
				mg.generate();
				mg.renderLayerPreview(this.layerPreviewCanvas, varying);
			}
		},

		getAssociatedMarkerOption: function() {
			var m = this.getModel();
			if (!m) { return null; }
			
			return m.getMarkerOption() || null;
		},

		getAssociatedMarkerGenerator: function() {
			var mo = this.getAssociatedMarkerOption();;
			if (!mo) { return null; }
			
			return mo.getMarkerGenerator();
		},


		clearAdditionalAttributes: function() {
			if (this.attrbindSelectElement) {
				this.attrbindSelectElement.innerHTML = '';
				this.addAttrBindOption('(none)', kNoBind);
			}
		},

		addAdditionalAttribute: function(attrInfo) {
			if (this.attrbindSelectElement) {
				this.addAttrBindOption(attrInfo.name, attrInfo.name);
			}
		},
		
		addAttrBindOption: function(name, inputValue) {
			var o = $H('option');
			o.appendChild( $T(name) );
			o.value = inputValue;
			
			this.attrbindSelectElement.appendChild(o);
			
			return o;
		},

		// form sync
		syncFromModel: function() {
			var lyr = this.getModel();
			this.fillPresetSelector();
			
			this.syncNumOfMarkersFromModel();
			this.syncIndexScalingFromModel();
			this.syncTrajectoryColorPicker( lyr.trajectoryDefaultColor );
			this.syncTrajectoryCompositionChooser( lyr.trajectoryAddComposition );
			this.syncTrajectoryLineStyleChooser( lyr.trajectoryLineStyle );
			this.syncRemainOutsideCheckbox( lyr.getRemainOutsideRecords() );
			this.syncTailConfigurationSectionVisibility();

			var mo = this.getAssociatedMarkerOption();
			if (mo) {
				this.syncMarkerColorBoundAttribute( mo.getMarkerColorBoundAttribute() );
				this.syncMarkerCompositionChooser( mo.isAddCompositionEnabled() );
				this.syncMarkerSizingChooser( mo.getMarkerAutoSizing() );
				this.syncPerceptualScalingCheckbox( mo.getPerceptualScalingEnabled() );
				
				this.setTailDurationValue( mo.getTailDuration() );
			}
		},

		syncMarkerColorBoundAttribute: function(attrName) {
			var formVal = (!attrName) ? kNoBind : attrName;
			if (this.attrbindSelectElement.value !== formVal) {
				this.attrbindSelectElement.value = formVal;
			}
		},

		syncNumOfMarkersFromModel: function() {
			var mg = this.getAssociatedMarkerGenerator();
			if (mg) {
				this.setNumSliderValue( mg.numOfMarkers );
				this.mconf.jNumOfMarkers.forceUpdateCounter();
			}
		},
		
		syncIndexScalingFromModel: function() {
			var mg = this.getAssociatedMarkerGenerator();
			if (mg) {
				this.setIndexScalingSliderValue( mg.indexScaling );
				this.mconf.jNumIndexScaling.forceUpdateCounter();
			}
		},

		syncPerceptualScalingCheckbox: function(val) {
			check_bool_if(this.perceptualScalingCheckbox, val);
		},
		
		syncRemainOutsideCheckbox: function(val) {
			check_bool_if(this.remainOutsideCheckbox, val);
		},

		syncMarkerSizingChooser: function(val) {
			check_with_num(this.getJMarkerSizingRadio() , val);
		},
		
		syncMarkerCompositionChooser: function(enabled) {
			check_with_bool(this.getJMarkerCompositionRadio() , enabled);
		},
		
		syncTrajectoryColorPicker: function(color) {
			if (this.trajectoryColorPicker) {
				this.trajectoryColorPicker.showSelection(color);
			}
		},

		syncTrajectoryCompositionChooser: function(enabled) {
			check_with_bool(this.findTrajectoryCompositionRadios() , enabled);
		},

		syncTrajectoryLineStyleChooser: function(val) {
			check_with_num(this.findTrajectoryLineStyleRadios(), val);
		},

		// form getters and setters
		getNumSliderValue: function() {
			return this.mconf.jNumOfMarkers.val() - 0;
		},
		setNumSliderValue: function(newValue) {
			this.setRangeVal(this.mconf.jNumOfMarkers, this.getNumSliderValue(), newValue);
		},

		getIndexScalingSliderValue: function() {
			return this.mconf.jNumIndexScaling.val() - 0;
		},
		setIndexScalingSliderValue: function(newValue) {
			this.setRangeVal(this.mconf.jNumIndexScaling, this.getIndexScalingSliderValue(), newValue);
		},
		
		setRangeVal: function(j, oldValue, newValue) {
			newValue |= 0;
			if (newValue !== oldValue) {
				j.val( newValue );
			}
		},

		// Form accessors
		//  sizing radio
		getJMarkerSizingRadio: function() {
			return this.jElement.find('.mm-markersizing-radio');
		},

		//  composition radio
		getJMarkerCompositionRadio: function() {
			return this.jElement.find('.mm-markercomp-radio');
		},
		
		//  color preset radio
		getJMarkerColorPresetRadio: function() {
			return this.jElement.find('.mm-markercolor-radio');
		},
		liveObserveMarkerColorPresetRadio: function(event, handler) {
			return this.jElement.on(event, '.mm-markercolor-radio', handler);
		},

		getJMarkerColorReverseButtons: function() {
			return this.jElement.find('.mm-markercolor-reverse-subbutton');
		},
		liveObserveColorReverseButtons: function(event, handler) {
			return this.jElement.on(event, '.mm-markercolor-reverse-subbutton', handler);
		},

		getSelectedMarkerColorPresetId: function() {
			return this.jElement.find('.mm-markercolor-radio:checked').val();
		},

		getJMarkerPresetRadioByPId: function(presetId) {
			return this.jElement.find('.mm-markercolor-radio[value="' +presetId+ '"]');
		},
		
		
		renewMarkerPresetPreview: function(pid) {
			var j = this.getJMarkerPresetRadioByPId(pid);
			if (j.length > 0) {
				var box = j[0].nextSibling;
				if (box.className && box.className.indexOf('style') >= 0) {
					var previewCanvas = mobmap.generateMarkerSetPreviewImageByPID(pid);
					var img_url = "url('" + previewCanvas.toDataURL() +"')";

					box.style.backgroundImage = img_url;
				}
			}
		},
		
		// perceptual scaling checkbox
		getPerceptualScalingCheckbox: function() {
			return this.perceptualScalingCheckbox;
		},
		
		// remain out-of-time records checkbox
		getRemainOutsideCheckbox: function() {
			return this.remainOutsideCheckbox;
		},

		// form listeners
		onNumSliderChange: function() {
			var newValue = this.getNumSliderValue();
			var mo = this.getAssociatedMarkerOption();
			
			mo.setNumOfMarkers(newValue);
		},
		
		onIndexScalingSliderChange: function() {
			var newValue = this.getIndexScalingSliderValue();
			var mo = this.getAssociatedMarkerOption();

			mo.setIndexScaling(newValue);
		},
		
		// LIMIT DISTANCE FORM - - - -
		getJLimitDistanceNumber: function() { return this.jLimitDistanceNumber; },
		getJLimitTimeNumber: function() { return this.jLimitTimeNumber; },
		getTrajLimitType: function() {
			var val = 0;
			this.jLimitDistanceRadios.each(function(i,el) {
				if (el.checked) { val = parseInt(el.value,10); }
			});
			return val;
		},
		
		getJLimitDistanceRadios: function() { return this.jLimitDistanceRadios; },
		
		// Configure color preset
		onColorPresetAddButtonClick: function() {
			this.jElement.trigger(mobmap.LayerListView.REQUIRE_COLOR_CONFIG_EVENT, this);
		}
	};

	LayerListViewMovingObjectItem.generateMarkerSizingIcon = function(width, height, startSize, dr, nMarkers) {
		var n = nMarkers || 5;
		var stepX = width / (n+1);
		var hh = height / 2;
		
		var cv = document.createElement('canvas');
		cv.width = width;
		cv.height = height;
//cv.style.backgroundColor = '#eee';
		
		var x = stepX;
		var r = startSize;
		var g = cv.getContext('2d');
		g.fillStyle = 'rgba(0,0,0,0.5)';
		for (var i = 0;i < n;++i) {
			var t = i / (n-1);
			
			g.beginPath();
			g.arc(x, hh, r, 0, Math.PI*2, false);
			g.fill();

			x += stepX;
			r += dr;
		}
		
		return cv;
	};

	function check_with_bool(j, selectedValue) {
		j.each(function(i, el) {
			if ( (parseInt(el.value) > 0) === selectedValue ) {
				el.checked = true;
			}
		});
	}

	function check_with_num(j, selectedValue) {
		j.each(function(i, el) {
			if ( parseInt(el.value) === selectedValue ) {
				el.checked = true;
			}
		});
	}
	
	function check_bool_if(checkbox, val) {
		if (checkbox) {
			checkbox.checked = !!( val );
		}
	}

	mobmap.installBaseMethods(  LayerListViewMovingObjectItem.prototype, mobmap.LayerListView.ItemBase  );
	mobmap.installBaseMethods(  LayerListViewMovingObjectItem.prototype, mobmap.LayerListView.ItemWithPreviewBase  );
	pkg.LayerListViewMovingObjectItem = LayerListViewMovingObjectItem;
});
