mmDefineModule(function(pkg) {
	'use strict';

	function WaitScreen() {
		this.chartSize = 128;
		this.jElement = mobmap.FullScreenBox.createBaseElementJ();
		this.element = this.jElement[0];

		mobmap.FullScreenBox.setupFullScreen(this);
		this.addTitle('Processing...');
		
		this.indicatorElement = this.addIndicator(this.element);
		this.chartCanvas = this.setupChartCanvas(this.indicatorElement, this.chartSize);
		this.chartG = this.chartCanvas.getContext('2d');
	}
	
	WaitScreen.prototype = {
		addIndicator: function(container) {
			var box = $H('div', 'mm-waitscreen-indicator');
			container.appendChild(box);
			return box;
		},
		
		setPercentage: function(val, partIndex, partsCount) {
			this.redrawChart(val, partIndex, partsCount);
		},
		
		setupChartCanvas: function(container, size) {
			var cv = document.createElement('canvas');
			cv.width = size;
			cv.height = size;
			
			container.appendChild(cv);
			return cv;
		},
		
		redrawChart: function(percentage, partIndex, partsCount) {
			var g = this.chartG;
			var s = this.chartSize;
			var hs = s >> 1;
			var HPI = Math.PI / 2.0;
			
			g.clearRect(0, 0, s, s);
			var angle = Math.PI * percentage / 50.0
		
			g.save();
				g.strokeStyle = '#fff';
				g.lineWidth = 3;
				g.lineCap = 'butt';
				g.beginPath();
				
				if (!partIndex || 0 == (partIndex % 2)) {
					g.arc(hs, hs, hs - 4, -HPI, angle -HPI, false);
				} else {
					g.arc(hs, hs, hs - 4, -HPI, angle -HPI, true);
				}
				
				
				g.stroke();
				
				var ty = hs+6;
				if (partsCount) { ty += 10; }
		
				g.fillStyle = '#fff';
				g.textAlign = 'right';
				g.font = '12px sans-serif';
				g.fillText(Math.floor(percentage) + '%', hs+12, ty);
				
				if (partsCount) {
					g.fillText((partIndex + 1) + ' of ' + partsCount, hs+12, ty-20);
				}
			g.restore();
		},

		addTitle: mobmap.FullScreenBox.addTitle,
		show: mobmap.FullScreenBox.show,
		hide: mobmap.FullScreenBox.hide
	};

	pkg.WaitScreen = WaitScreen;
});
