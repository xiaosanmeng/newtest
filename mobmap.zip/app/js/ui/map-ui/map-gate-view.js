mmDefineModule(function(pkg) {
	'use strict';
	var GATE_DEMO_MODE = false;
	
	var kGateLineStyle = GATE_DEMO_MODE ? '#F00' : '#2233ff';
	var kGateStdWeight = GATE_DEMO_MODE ? 7 : 2;
	var kPolygonStdWeight = GATE_DEMO_MODE ? 5 : 1;
	var kHighlightedColorStyle = '#99ff00';
	var kHighlightedStrokeWidth = 6;
	var kHandleImageURL = 'images/map-ui/handle.png';
	var kAddHandleImageURL = 'images/map-ui/add-handle.png';
	var kGearButtonImageURL = 'images/map-ui/gear-button.png';

	function GateViewController() {
		this.modelList = [];
		this.mapPane = null;
		this.selectionStateProviderFunc = null;
	}
	
	GateViewController.prototype = {
		setSelectionStateProviderFunc: function(f) {
			this.selectionStateProviderFunc = f;
		},

		connectModelAndView: function(mapPane, modelEventDispatcher) {
			this.mapPane = mapPane;
			modelEventDispatcher.
			 bind(mobmap.SelectionPool.CHANGE_EVENT ,       this.onAnySelectionChanged.bind(this) ).
			 bind(mobmap.MMSensorPool.Events.ItemAdded,     this.onModelItemAdded.bind(this)).
			 bind(mobmap.MMSensorPool.Events.ItemRemoved,   this.onModelItemRemoved.bind(this)).
			 bind(mobmap.MMLandSensor.Events.VertexChanged, this.onModelVertexChanged.bind(this)).
			 bind(mobmap.MMLandSensor.Events.VertexAdded,   this.onModelVertexAdded.bind(this)).
			 bind(mobmap.MMLandSensor.Events.VertexRemoved, this.onModelVertexRemoved.bind(this)).
			 bind(mobmap.MMLandSensor.Events.AppearanceChanged, this.onModelAppearanceChanged.bind(this)).
			 bind(mobmap.MMSensorPool.Events.ItemHighlightRequired, this.onModelItemHighlightRequired.bind(this));
		},

		onAnySelectionChanged: function() {
			
		},

		onModelAppearanceChanged: function(e, item, newValue) {
			if (item._view) {
				item._view.setVisible(newValue);
			}
		},

		onModelItemAdded: function(e, sensorPool, newItem) {
			var v = this.ensureItemHasView(newItem);
			if (v && this.modelList.indexOf(newItem) < 0) {
				this.modelList.push(newItem);
				// setTimeout(this.showFunctionPopup.bind(this, v), 100);
			}
		},
		
		onModelItemRemoved: function(e, sensorPool, removedItem) {
			if (removedItem._view) {
				removedItem._view.dispose();
				
				var i = this.modelList.indexOf(removedItem);
				if (i >= 0) {
					this.modelList.splice(i, 1);
				}
			}
		},

		onModelVertexChanged: function(e, changedItem) {
			this.setViewVertices(changedItem);
		},

		onModelVertexAdded: function(e, changedItem, insertedAfter) {
			if (changedItem._view) {
				changedItem._view.renewNumOfVertices(changedItem.getVertexCount());
				
				this.setViewVertices(changedItem);
			}
		},

		onModelVertexRemoved: function(e, changedItem, removedIndex) {
			if (changedItem._view) {
				changedItem._view.renewNumOfVertices(changedItem.getVertexCount());
				
				this.setViewVertices(changedItem);
			}
		},

		onModelItemHighlightRequired: function(e, senderModel, newState) {
			var v = this.getViewOfModel(senderModel);
			if (v && v.setHighlightState) {
				v.setHighlightState(newState);
			}
		},

		ensureItemHasView: function(sensorItem) {
			if (!sensorItem._view) {
				if (sensorItem.type === mobmap.LandSensorTypes.Group) {
					// Invisible item
					return null;
				}
				
				sensorItem._view = this.createSensorViewInstance(sensorItem.type, sensorItem.getVertexCount());
				this.setViewVertices(sensorItem);

				if (sensorItem._view.setDirection) {
					sensorItem._view.setDirection( sensorItem.getDirection() );
				}

				sensorItem._view.show();
			}
			
			return sensorItem._view;
		},

		createSensorViewInstance: function(sensorItemType, numOfInitialVertices) {
			if (sensorItemType === mobmap.LandSensorTypes.LineGate) {
				return new LineGateView(this, numOfInitialVertices);
			} else {
				return new PolygonGateView(this, numOfInitialVertices);
			}
		},

		setViewVertices: function(sensorItem) {
			var v1, v2;
			
			switch(sensorItem.type) {
			case mobmap.LandSensorTypes.LineGate:
				v1 = sensorItem.getVertexAt(0);
				v2 = sensorItem.getVertexAt(1);
				sensorItem._view.setEndLocations(v1.lat, v1.lng, v2.lat, v2.lng);
				break;
				
			case mobmap.LandSensorTypes.PolygonGate:
				var count = sensorItem.getVertexCount();
				var pview = sensorItem._view;
				for (var i = 0;i < count;++i) {
					var v = sensorItem.getVertexAt(i);
					pview.setVertexLocationAt(i, v.lat, v.lng);
				}

				pview.applyVerticesToOverlay();
				pview.updateHandleLocation();
				pview.updateAddHandleLocation();
				break;
			}
			
			sensorItem._view.locateUIs();
			sensorItem._view.hideNotificationBadge();
		},

		getAssociatedMap: function() {
			if (!this.mapPane) { return null; }
			return this.mapPane.getGoogleMaps();
		},
		
		findModelForView: function(viewObject) {
			var ls = this.modelList;
			var len = ls.length;
			
			for (var i = 0;i < len;++i) {
				var m = ls[i];
				if (m._view === viewObject) {
					return m;
				}
			}
			
			return null;
		},
		
		getViewOfModel: function(m) {
			if (!m) { return null; }
			return m._view || null;
		},

		// Communication with model
		sendHandlePositionToModel: function(viewObject, handleIndex) {
			var modelObject = this.findModelForView(viewObject);
			var hpos = viewObject.getHandlePositionAt(handleIndex);

			if (modelObject && hpos) {
				modelObject.setVertexPositionAt(handleIndex, hpos.lat, hpos.lng);
			} else {
				console.log("NULL WARNING", modelObject, hpos);
			}
		},

		sendDirOptionToModel: function(viewObject) {
			var modelObject = this.findModelForView(viewObject);
			if (modelObject && viewObject.gateDirection) {
				modelObject.setDirection(viewObject.gateDirection);
			}
		},

		sendAddVertexRequestToModel: function(viewObject, insertAfter) {
			var modelObject = this.findModelForView(viewObject);
			modelObject.insertVertexAfter(insertAfter);
		},
		
		sendRemoveVertexRequestToModel: function(viewObject, vertexIndex) {
			var modelObject = this.findModelForView(viewObject);
			modelObject.removeVertexAt(vertexIndex);
		},
		
		// Function menu
		showFunctionPopup: function(viewObject) {
			var mk = viewObject.getFunctionButtonMarker();
			var wnd = mk.functionWindow;
			if (!wnd) {
				mk.functionWindow = wnd = new google.maps.InfoWindow({
					content: this.generateGateFunctionWindowContent(viewObject)
				});
			}
			
			var shouldClose = false;
			if (wnd.getMap) { // already opened?
				if (wnd.getMap()) {
					shouldClose = true;
				} 
			}

			if (shouldClose) {
				wnd.close();
			} else {
				this.showSubOperationIfNeeded(viewObject);
				wnd.open(mk.getMap(), mk);
			}
		},
		
		closeImmediately: function(viewObject) {
			var mk = viewObject.getFunctionButtonMarker();
			var wnd = mk.functionWindow;
			if (wnd) {
				wnd.close();
			}
		},

		generateGateFunctionWindowContent: function(ownerViewObject) {
			var topNode = $H('div');
			
//			this.generateGateFunctionWindowConditionForm(topNode);
			this.generateGateFunctionWindowCommandButtons(topNode, ownerViewObject);

			return topNode;
		},

		generateGateFunctionWindowCommandButtons: function(container, ownerViewObject) {
			var div = $H('div', 'gate-func-commands-row');
			container.appendChild(div);

			var runButton = $H('button', 'gate-func-run-button');
			runButton.appendChild($T('✓ Make selection'));
			div.appendChild(runButton);

			var removeButton = $H('button', 'gate-func-remove-button');
			removeButton.appendChild($T('× Remove'));
			div.appendChild(removeButton);

			var booleanOperationBox = this.generateBooleanOperationButtons(container);

			// observe
			runButton.addEventListener('click', this.onFuncRunButtonClick.bind(this, ownerViewObject), false);
			removeButton.addEventListener('click', this.onFuncRemoveButtonClick.bind(this, ownerViewObject), false);
			booleanOperationBox.addEventListener('click', this.onSubOpButtonClick.bind(this, ownerViewObject), false);

			ownerViewObject.setMainOpView(div);
			ownerViewObject.setSubOpView(booleanOperationBox);
			this.toggleSubOperationView(ownerViewObject, false);
			return div;
		},


		// AND/OR/NOT
		generateBooleanOperationButtons: function(container) {
			var boolean_box = $H('div', 'gate-suboperation-box gate-func-commands-row');
			var caption = $H('h5');
			
			var tip = $H('img', 'mm-box-tip');
			tip.src = 'images/up-tip.png';
			boolean_box.appendChild(tip);

			/*
			var backButton = $H('button', 'gate-func-back-button gate-subop-x');
			backButton.appendChild($T( '←' ));
			backButton.title = 'Back';
			backButton.setAttribute('data-subop', 'x');
			caption.appendChild(backButton);
			*/
			
			caption.appendChild($T('Boolean operations'));
			boolean_box.appendChild(caption);

			this.addSubOperationButton(boolean_box, '＋ OR'  , kBooleanOpNames.Or);
			this.addSubOperationButton(boolean_box, '・ AND' , kBooleanOpNames.And);
			this.addSubOperationButton(boolean_box, '〜 NOT' , kBooleanOpNames.Not);

			container.appendChild(boolean_box);
			return boolean_box;
		},

		addSubOperationButton: function(container, label, op_name) {
			var btn = $H('button', 'gate-func-run-button gate-subop-' + op_name);
			btn.appendChild($T(label));
			btn.setAttribute('data-subop', op_name);
			container.appendChild(btn);
			return btn;
		},

		shouldShowBooleanOperation: function() {
			if (this.selectionStateProviderFunc) {
				return this.selectionStateProviderFunc();
			}
			return false;
		},


		generateGateFunctionWindowConditionForm: function(container) {
			var div = $H('div');
			
			generateInputWithLabel({
				container: div,
				text: 'Condition ',
				type: 'text'
			});
			
			container.appendChild(div);
			return div;
		},

		// Function window
		
		onSubOpButtonClick: function(viewObject, e) {
			if (e && e.target) {
				var d = e.target.getAttribute('data-subop');
				if (d && d.length > 0) {
					switch(d) {
					case 'x':
						this.toggleSubOperationView(viewObject, false);
						break;
					
					default:
						this.doGateSelection(viewObject, d);
						this.toggleSubOperationView(viewObject, false);
						break;
					}
				}
			}
		},
		
		onFuncRemoveButtonClick: function(viewObject) {
			var modelObject = this.findModelForView(viewObject);
			modelObject.requestRemove();
		},

		onFuncRunButtonClick: function(viewObject) {
			this.doGateSelection(viewObject, null);
		},
		
		doGateSelection: function(viewObject, operation) {
			var modelObject = this.findModelForView(viewObject);
			this.sendDirOptionToModel(viewObject);

			var app = this.getOwnerApp();
			var that = this;

			if (app) {
				var job = app.createGateSensorJob(modelObject);
				if (job) {
					job.then(function(){
						var count = that.makeSelectionFromGateResult(job, operation);
						viewObject.showNotificationBadge(count);
					});
					job.start();
				}
			}
			
			this.closeImmediately(viewObject);
		},

		showSubOperationIfNeeded: function(gateView) {
			this.toggleSubOperationView(gateView, this.shouldShowBooleanOperation());
		},

		toggleSubOperationView: function(gateView, visible) {
			var v = gateView.getSubOpView();
			if (v) {
				v.style.display = visible ? '' : 'none';
			}
		},

		makeSelectionFromGateResult: function(gateJob, operation) {
			var app = this.getOwnerApp();
			var ls = gateJob.getResultBuffer();
			var len = ls.length;
			
			var idmap = {};
			var count = 0;

			for (var i = 0;i < len;++i) {
				var r = ls[i];
				var tp = r.type;
								
				if (tp === mobmap.GateResultType.LineGatePassed || 
					tp === mobmap.GateResultType.PolygonGateEdgePassed || 
					 (tp === mobmap.GateResultType.PolygonGateInOutChanged && r.inside) ) {
					
					if (r.firstRecord) {
						var oid = r.firstRecord.id;
						if ( !(idmap.hasOwnProperty(oid)) ) {
							idmap[ oid ] = oid;
							++count;
						}
					}
					
				}
			}

			var layerId = gateJob.getTargetLayerId();
			app.selectObjectsOnLayer(layerId, idmap, operation);
			
			return count;
		}
	};


	// Gate view base methods
	var GateViewBase = {
		setMainOpView: function(v) { this.functionMainOpView = v; },
		getMainOpView: function() { return this.functionMainOpView; },
		setSubOpView: function(v) { this.functionSubOpView = v; },
		getSubOpView: function() { return this.functionSubOpView; },
		
		saveOverlayOption: function(o) {
			this.originalOverlayOption = {};
			this.highlightOverlayOption = {};
			
			for (var i in o) if (o.hasOwnProperty(i)) {
				this.originalOverlayOption[i] = o[i];
				this.highlightOverlayOption[i] = o[i];
			}
			
			// tweak highlighted style
			var h = this.highlightOverlayOption;
			h.strokeWeight = kHighlightedStrokeWidth;
			h.strokeColor  = kHighlightedColorStyle;
			if (h.hasOwnProperty('fillColor')) {
				h.fillColor = kHighlightedColorStyle;
			}

			return o
		},

		setHighlightState: function(bHighlighted) {
			var o = this.getMainOverlay();
			if (o) {
				o.setOptions(bHighlighted ? this.highlightOverlayOption : this.originalOverlayOption);
			}
		},

		getFunctionButtonMarker: function() {
			return this.functionButtonMarker;
		},
		
		getVerticesCount: function() {
			return this.pathArray.length;
		},
	
		getHandlePositionAt: function(index) {
			if (!this.handleArray) {
				return null;
			}

			return this.handleArray.getPositionAt(index);
		},

		setVertexLocationAt: function(index, lat, lng) {
			if (!this.pathArray[index]) {
				this.pathArray[index] = new MMLatLng();
			}
		
			this.pathArray[index].lat = lat;
			this.pathArray[index].lng = lng;
		},

		observeOverlayEvents: function() {
			var o = this.getMainOverlay();
			if (o) {
				o.addListener('click', this.onMainOverlayClick.bind(this, o));
			}
		},

		onMainOverlayClick: function(overlay, e) {
		},

		notifyHandleDrag: function(handleIndex, sender) {
			if (sender === this.handleArray) {
				this.ownerController.sendHandlePositionToModel(this, handleIndex);
				this.checkStraight(handleIndex);
			}
		},

		checkStraight: function(centerIndex) {
			var ov = this.getMainOverlay();
			if (!ov) {return;}
			
			var gmap = ov.getMap();
			if (!gmap) {return;}

			var len = this.getVerticesCount();
			if (len < 4) { return; }

			var prevIndex = (centerIndex+len-1) % len;
			var nextIndex = (centerIndex+1) % len;

			var vPrev = this.pathArray[prevIndex];
			var vMid  = this.pathArray[centerIndex];
			var vNext = this.pathArray[nextIndex]

			var pj = gmap.getProjection();
			var ptPrev = pj.fromLatLngToPoint(new google.maps.LatLng(vPrev.lat, vPrev.lng));
			var ptMid  = pj.fromLatLngToPoint(new google.maps.LatLng(vMid.lat , vMid.lng));
			var ptNext = pj.fromLatLngToPoint(new google.maps.LatLng(vNext.lat, vNext.lng));
			
			var should_show_label = checkLinesStraight(0.94, ptPrev, ptMid, ptNext); 
			if (this.handleArray) {
				this.handleArray.setRemoveIndicatorVisible(centerIndex, should_show_label);
			}
		},

		createHandleOverlays: function(gmap, numOfInitialVertices, handleType) {
			var ha = new HandleArray(gmap, this, handleType);
			for (var i = 0;i < numOfInitialVertices;++i) {
				ha.add();
			}

			return ha;
		},

		applyVerticesToOverlay: function() {
			this.getMainOverlay().setPath(this.pathArray);
		},

		show: function() {
			if (!this.pathArray[0]) { return; }

			this.applyVerticesToOverlay();
			this.setVisible(true);
		},

		setVisible: function(v) {
			// Bulk set
			this.getMainOverlay().setVisible(v);
			this.handleArray.setVisible(v);
			if (this.a_handleArray) {
				this.a_handleArray.setVisible(v);
			}
			
			if (this.setVisibleAdditional) {
				this.setVisibleAdditional(v);
			}
			
			if (this.functionButtonMarker) {
				this.functionButtonMarker.setVisible(v);
			}
			
			if (this.notificationMarker) {
				this.notificationMarker.setVisible(v);
			}
			
			this.visible = v;
		},
		
		getVisible: function() {
			return this.visible;
		},

		updateHandleLocation: function() {
			if (this.handleArray) {
				var len = this.pathArray.length;
				for (var i = 0;i < len;++i) {
					this.handleArray.setPositionAt(i, this.pathArray[i].lat, this.pathArray[i].lng);
				}
			}
		},
		
		renewNumOfVertices: function(newCount) {
			var df = newCount - this.getVerticesCount();
			var i;
			if (df === 0) {return;} // not changed

			if (df > 0) {
				for (i = 0;i < df;++i) {
					if (this.appendNewVertex) {
						this.appendNewVertex();
					} else {
						console.log("WARNING: This view does not support appendNewVertex() method.");
					}
				}
			} else {
				df = -df;
				
				for (i = 0;i < df;++i) {
					if (this.removeLastVertex) {
						this.removeLastVertex();
					} else {
						console.log("WARNING: This view does not support removeLastVertex() method.");
					}
				}
			}
		},
		
		locateUIs: function() {
			var mlngIdx = this.getLeftEndIndex();
			if (mlngIdx < 0) { return; }

			var lng = this.pathArray[mlngIdx].lng;
			var lat = this.findDynamicTopLat(mlngIdx);
			
			if (this.notificationMarker) {
				this.notificationMarker.setPosition(new google.maps.LatLng(lat, lng));
			}
			
			if (this.functionButtonMarker) {
				this.functionButtonMarker.setPosition(new google.maps.LatLng(lat, lng));
			}
		},

		findDynamicTopLat: function(leftEndIndex) {
			var threshWidth = 25;
			
			var len = this.pathArray.length;
			var llat = this.pathArray[leftEndIndex].lat;
			var spLeftEnd = this.transformToScreenCoord(llat, this.pathArray[leftEndIndex].lng);

			for (var i = 0;i < len;++i) {
				if (i === leftEndIndex) { continue; }

				var ll = this.pathArray[i];
				var sp = this.transformToScreenCoord(ll.lat, ll.lng);
				if (Math.abs(sp.x - spLeftEnd.x) < threshWidth) {
					if (ll.lat < llat) {
						llat = ll.lat;
					}
				}
			}
			
			return llat;
		},

		getLeftEndIndex: function() {
			var m = 180;
			var mi = -1;
			var len = this.pathArray.length;
			for (var i = 0;i < len;++i) {
				if (this.pathArray[i].lng < m) {
					m = this.pathArray[i].lng;
					mi = i;
				}
			}

			return mi;
		},

		transformToScreenCoord: function(lat, lng) {
			var o = this.getMainOverlay();
			if (!o) { return null; }

			var gmap = o.getMap();
			var pj = gmap.getProjection();

			var mapSize = Math.pow(2, gmap.getZoom());
			var pt = pj.fromLatLngToPoint(new google.maps.LatLng(lat, lng));

			pt.x *= mapSize;
			pt.y *= mapSize;
			return pt;
		},

		generateBadgeIconObject: (function() {
			var iconbase = null;
			return function(num) {
				if (!iconbase) {
					iconbase = {
						url: null,
						size: new google.maps.Size(20,20),
						scaledSize: new google.maps.Size(20,20),
						origin: new google.maps.Point(0,0),
						anchor: new google.maps.Point(19,23)
					};
				}
				
				iconbase.url = generateNotificationBadge(num);
				return iconbase;
			}
		})(),
		
		createNotificationMarker: function(gmap) {
			var mk = new google.maps.Marker({
				map: null,
				draggable: false,
				crossOnDrag: false,
				zIndex: 99,
				icon: this.generateBadgeIconObject()
			});
		
			this.observeFunctionButton(mk);
			return mk;
		},

		createFunctionButton: function(gmap) {
			var mk = new google.maps.Marker({
				map: gmap,
				draggable: false,
				crossOnDrag: false,
				zIndex: 98,
				icon: new google.maps.MarkerImage(
					kGearButtonImageURL,
					new google.maps.Size(22,22),   // size
					new google.maps.Point(0,0),  // origin
					new google.maps.Point(27,17)   // anchor
				)
			});

			mk.functionWindow = null;
			this.observeFunctionButton(mk);

			return mk;
		},
		
		observeFunctionButton: function(mk) {
			mk.addListener('click', this.onFunctionButtonClick.bind(this, mk));
		},
		
		onFunctionButtonClick: function(buttonMarker) {
			if (this.ownerController) {
				this.ownerController.showFunctionPopup(this);
			}
		},
		
		hideNotificationBadge: function() {
			if (this.notificationMarker) {
				this.notificationMarker.setMap(null);
			}
		},
		
		showNotificationBadge: function(num) {
			if (this.notificationMarker) {
				this.notificationMarker.setMap( this.functionButtonMarker.getMap() );
				this.notificationMarker.setIcon( this.generateBadgeIconObject(num) );
			}
		},
		
		dispose: function() {
			this.handleArray.dispose();
			if (this.a_handleArray) {
				this.a_handleArray.dispose();
			}
			
			var mo = this.getMainOverlay();
			if (mo) { mo.setMap(null); }
			
			if (this.additinalDispose) {
				this.additinalDispose();
			}
			
			if (this.functionButtonMarker) { this.functionButtonMarker.setMap(null); }
			if (this.notificationMarker) { this.notificationMarker.setMap(null); }
		}
	};

	// Specific view objects

	function LineGateView(ownerController, numOfInitialVertices) {
		this.ownerController = ownerController;
		this.nullInitProperties();
		this.gateDirection = this.getDefaultDirection();
		this.dirIconOption = {
			url: 'images/aim.png', 
			size: new google.maps.Size(24,24),
			origin: new google.maps.Point(0,0),
			anchor: new google.maps.Point(12,12)
		};

		this.pathArray = [null, null];
		this.tmpLL = {lat:0, lng:0};

		this.dirIconMaker = new mobmap.GMapDirectionIcon();

		this.initMapFeatures(numOfInitialVertices);
		this.observeOverlayEvents();
		this.observeDirectionIconEvent();
	}

	LineGateView.prototype = {
		getDefaultDirection: function() {
			return mobmap.GMapDirectionIcon.FWD | mobmap.GMapDirectionIcon.BACK;
		},

		setDirection: function(d) {
			this.gateDirection = d;
			this.updateDirOverlayLocation();
			this.ownerController.sendDirOptionToModel(this);
		},

		getMainOverlay: function() {
			return this.lineOverlay;
		},

		nullInitProperties: function() {
			this.visible = false;
			this.lineOverlay = null;
			this.handleArray = null;
			this.directionOverlay = null;

			this.notificationMarker = null;
			this.functionButtonMarker = null;
			this.functionSubOpView = null;
			this.functionMainOpView = null;
		},

		initMapFeatures: function(numOfInitialVertices) {
			var m = this.ownerController.getAssociatedMap();
			this.lineOverlay = this.createLineOverlay(m);
			this.handleArray = this.createHandleOverlays(m, numOfInitialVertices);
			this.directionOverlay = this.createDirectionOverlay(m);

			this.notificationMarker = this.createNotificationMarker(m);
			this.functionButtonMarker = this.createFunctionButton(m);
		},
		
		createLineOverlay: function(gmap) {
			var o = new google.maps.Polyline( this.saveOverlayOption({
				strokeColor: kGateLineStyle,
				strokeOpacity: 1,
				strokeWeight: kGateStdWeight
			}) );
			
			o.setMap(gmap);
			o.setVisible(false);
			return o;
		},

		createDirectionOverlay: function(gmap) {
			var o = new google.maps.Marker({
				map: gmap,
				icon: this.dirIconOption
			});
			
			o.setVisible(false);
			return o;
		},

		setEndLocations: function(lat1, lng1, lat2, lng2) {
			this.setVertexLocationAt(0, lat1, lng1);
			this.setVertexLocationAt(1, lat2, lng2);
			
			this.applyVerticesToOverlay();
			this.updateHandleLocation();
			this.updateDirOverlayLocation();
		},
		
		updateDirOverlayLocation: function() {
			var p1 = this.getHandlePositionAt(0);
			var p2 = this.getHandlePositionAt(1);

			this.tmpLL.lat = 0.5 * (p1.lat + p2.lat);
			this.tmpLL.lng = 0.5 * (p1.lng + p2.lng);

			this.dirIconMaker.update(p1.lat, p1.lng , p2.lat, p2.lng, this.gateDirection);
			this.dirIconOption.url = this.dirIconMaker.toDataURL();

			this.directionOverlay.setPosition(this.tmpLL);
			this.directionOverlay.setIcon( this.dirIconOption );
		},
		
		setVisibleAdditional: function(v) {
			this.directionOverlay.setVisible(v);
		},
		
		onDirectionIconClick: function() {
			this.toggleDirection();
		},
		
		observeDirectionIconEvent: function() {
			var h = this.onDirectionIconClick.bind(this);
			this.directionOverlay.addListener('click', h);
		},
		
		toggleDirection: function() {
			var d = (this.gateDirection % 3) + 1;
			this.setDirection(d);
			
			if (this.ownerController.sendDirOptionToModel) {
				this.ownerController.sendDirOptionToModel(this);
			}
			
			this.hideNotificationBadge();
		},
		
		additinalDispose: function() {
			if (this.directionOverlay) {
				this.directionOverlay.setMap(null);
			}
		}
	};

	mobmap.installBaseMethods(  LineGateView.prototype, GateViewBase  );

	function PolygonGateView(ownerController, numOfInitialVertices) {
		this.ownerController = ownerController;
		this.nullInitProperties();
		this.pathArray = new Array(numOfInitialVertices);

		this.initMapFeatures(numOfInitialVertices);
	}

	PolygonGateView.prototype = {
		getMainOverlay: function() {
			return this.polygonOverlay;
		},

		nullInitProperties: function() {
			this.visible = false;
			this.polygonOverlay = null;
			this.handleArray = null;
			this.a_handleArray = null;

			this.notificationMarker = null;
			this.functionButtonMarker = null;
			this.functionSubOpView = null;
			this.functionMainOpView = null;
		},

		initMapFeatures: function(numOfInitialVertices) {
			var m = this.ownerController.getAssociatedMap();
			this.polygonOverlay = this.createPolygonOverlay(m);
			this.handleArray = this.createHandleOverlays(m, numOfInitialVertices);
			this.a_handleArray = this.createHandleOverlays(m, numOfInitialVertices, HandleArray.Types.Add);

			this.notificationMarker = this.createNotificationMarker(m);
			this.functionButtonMarker = this.createFunctionButton(m);
		},
		
		createPolygonOverlay: function(gmap) {
			var o = new google.maps.Polygon( this.saveOverlayOption({
				fillColor: kGateLineStyle,
				fillOpacity: 0.25,
				strokeColor: kGateLineStyle,
				strokeOpacity: 0.8,
				strokeWeight: kPolygonStdWeight
			}) );
			
			o.setMap(gmap);
			o.setVisible(false);
			return o;
		},
		
		updateAddHandleLocation: function() {
			if (this.a_handleArray) {
				var len = this.pathArray.length;
				for (var i = 0;i < len;++i) {
					var v1 = this.pathArray[i];
					var v2 = this.pathArray[ (i+1) % len ];

					var lat = 0.5 * ( v1.lat + v2.lat );
					var lng = 0.5 * ( v1.lng + v2.lng );
					this.a_handleArray.setPositionAt(i, lat, lng);
				}
			}
		},
		
		notifyHandleClick: function(index, sender) {
			if (sender === this.a_handleArray) {
				this.ownerController.sendAddVertexRequestToModel(this, index);
			}
		},
		
		notifyToRemoveHandleReleased: function(index, sender) {
			if (sender === this.handleArray) {
				this.ownerController.sendRemoveVertexRequestToModel(this, index);
				sender.setRemoveIndicatorVisible(index, false);
			}
		},
		
		appendNewVertex: function() {
			this.handleArray.add();
			this.a_handleArray.add();
			
			var newLL = new MMLatLng();
			this.pathArray.push(newLL);
			
			var v = this.getVisible();
			this.setVisible(v);
		},
		
		removeLastVertex: function() {
			this.handleArray.removeLast();
			this.a_handleArray.removeLast();
			
			this.pathArray.pop();
		}
	};
	
	mobmap.installBaseMethods(  PolygonGateView.prototype, GateViewBase  );

	// Drawing utility functions ------------------------------------
	function HandleArray(gmap, listener, type) {
		this.type = type || HandleArray.Types.Move;
		this.gmap = gmap;
		this.visible = false;
		this.list = [];
		
		this.listener = listener;
	}

	HandleArray.Types = {
		Move: 0,
		Add: 1
	};

	HandleArray.prototype = {
		add: function() {
			var mk = (this.type === HandleArray.Types.Move)        ? 
			         createDragHandleIcon(this.gmap, this.visible) :
			         createAddHandleIcon(this.gmap, this.visible);

			var nextIndex = this.list.length;
			this.list.push(mk);
			
			mk.addListener('drag', this.onMarkerDrag.bind(this, nextIndex));
			mk.addListener('click', this.onMarkerClick.bind(this, nextIndex));
			mk.addListener('dragend', this.onMarkerDragEnd.bind(this, nextIndex));
			return mk;
		},
		
		dispose: function() {
			var n = this.list.length;
			for (var i = 0;i < n;++i) {
				this.removeLast();
			}
		},

		removeLast: function() {
			var mk = this.list.pop();
			mk.setMap(null);
		},

		onMarkerDrag: function(index) {
			this.updateMarkerInternalPosition(index);
			
			if (this.listener && this.listener.notifyHandleDrag) {
				this.listener.notifyHandleDrag(index, this);
			}
		},

		onMarkerDragEnd: function(index) {
			var mk = this.list[index];
			if (mk) {
				var lb = mk.getLabel();
				if (lb && lb.text && lb.text.length > 0 &&
					this.listener && this.listener.notifyToRemoveHandleReleased) {
					this.listener.notifyToRemoveHandleReleased(index, this);
				}
			}
		},

		onMarkerClick: function(index) {
			if (this.listener && this.listener.notifyHandleClick) {
				this.listener.notifyHandleClick(index, this);
			}
		},

		updateMarkerInternalPosition: function(index) {
			var mk = this.list[index];
			if (!mk) {return;}
			
			var pos = mk.getPosition();
			mk.mmLatLng.lat = pos.lat();
			mk.mmLatLng.lng = pos.lng();
		},

		setVisible: function(v) {
			var ls = this.list;
			for (var i in ls) if (ls.hasOwnProperty(i)) {
				ls[i].setVisible(v);
			}
		},
		
		setPositionAt: function(index, lat, lng) {
			var mk = this.list[index];
			if (!mk) {return;}

			mk.mmLatLng.lat = lat;
			mk.mmLatLng.lng = lng;

			mk.setPosition( mk.mmLatLng );
		},
		
		getPositionAt: function(index) {
			var mk = this.list[index];
			if (!mk) {return null;}

			return mk.mmLatLng;
		},
		
		setRemoveIndicatorVisible: function(index, visible) {
			var mk = this.list[index];
			if (!mk) {return null;}

			mk.setLabel(visible ? kRemoveLabel : null);
		}
	};
	
	function createDragHandleIcon(gmap, initialVisibility) {
		var mk = new google.maps.Marker({
			draggable: true,
			crossOnDrag: false,
			icon: new google.maps.MarkerImage(
				kHandleImageURL,
				new google.maps.Size(9,9),   // size
				new google.maps.Point(0,0),  // origin
				new google.maps.Point(4,4)   // anchor
			)
		});
		mk.mmLatLng = new MMLatLng();

		mk.setMap(gmap);
		mk.setPosition( mk.mmLatLng );
		mk.setVisible(initialVisibility);

		return mk;
	}

	function createAddHandleIcon(gmap, initialVisibility) {
		var mk = new google.maps.Marker({
			draggable: false,
			crossOnDrag: false,
			icon: new google.maps.MarkerImage(
				kAddHandleImageURL,
				new google.maps.Size(11,11),   // size
				new google.maps.Point(0,0),  // origin
				new google.maps.Point(5,5)   // anchor
			)
		});

		mk.mmLatLng = new MMLatLng();

		mk.setMap(gmap);
		mk.setPosition( mk.mmLatLng );
		mk.setVisible(initialVisibility);

		return mk;
	}

	var kRemoveLabel = {
		color: '#F00',
		fontSize: '32px',
		text: '×'
	};
	
	// straight check core routine
	var checkLinesStraight = (function() {
		var a1 = [0,0];
		var a2 = [0,0];
		var a3 = [0,0];
		var a4 = [0,0];
		
		return function(thresh, pt1, pt2, pt3) {
			a1[0] = pt2.x - pt1.x;
			a1[1] = pt2.y - pt1.y;
			
			a2[0] = pt3.x - pt2.x;
			a2[1] = pt3.y - pt2.y;
			
			vec2.normalize(a3, a1);
			vec2.normalize(a4, a2);
			
			return (vec2.dot(a3, a4) > thresh);
		}
	})();
	
	// ( ( (  BADGE RENDERER  ) ) )
	
	var generateNotificationBadge = (function() {
		var ScrSize = 20;
		var TempCanvas = null;
		
		function renderCircleBadge(g) {
			g.arc(ScrSize, ScrSize, ScrSize-8, 0, Math.PI*2, false);
		}
		
		function renderRoundedRectBadge(g) {
			var c = ScrSize;
			var w = ScrSize - 4;
			var h = ScrSize - 8;
			var r = 10;
			var rr = 4;
			
			g.moveTo(c-w, c-h +r);
			g.bezierCurveTo(c-w, c-h +rr, c-w +rr, c-h, c-w+ r, c-h);
			g.lineTo(c+w -r, c-h);
			g.bezierCurveTo(c+w -rr,c-h, c+w,c-h +rr, c+w,c-h+r);
			g.lineTo(c+w, c+h -r);
			g.bezierCurveTo(c+w,c+h -rr, c+w -rr,c+h, c+w-r, c+h);
			g.lineTo(c-w +r, c +h);
			g.bezierCurveTo(c-w +rr,c+h, c-w,c+h -rr, c-w, c+h -r);
			g.closePath();
		}
		
		function fillBadge(g) {
			g.strokeStyle = '#128';
			g.lineWidth = 4;
			g.stroke();

			g.strokeStyle = '#79d';
			g.lineWidth = 2;
			g.stroke();
			
			g.fillStyle = '#35c';
			g.fill();
		}
		
		return function(n) {
			if (!n) {
				n = 0;
			}

			if (!TempCanvas) {
				TempCanvas = document.createElement('canvas');
				TempCanvas.width  = ScrSize*2;
				TempCanvas.height = ScrSize*2;
			}
			
			var g = TempCanvas.getContext('2d');
			g.clearRect(0, 0, ScrSize*2, ScrSize*2);
			
			g.save();
				
				g.beginPath();
				if (n < 100) {
					renderCircleBadge(g);
				} else {
					renderRoundedRectBadge(g);
				}
				fillBadge(g);
				
				
				g.fillStyle = '#fff';
				g.beginPath();
				g.textAlign = 'center';
				g.textBaseline = 'middle';

				if (n < 100) {
					g.font = "14px monospace";
				} else if (n < 1000) {
					g.font = "13px monospace";
				} else {
					g.font = "11px monospace";
				}
				
				if (n > 0) {
					g.fillText(n, ScrSize, ScrSize);
					g.fill();
				}
			
			g.restore();
			
			return TempCanvas. toDataURL();
		};
	})();
	
	// test
	/*
	checkLinesStraight(0.9,
		{x:10 ,y:10},
		{x:20 ,y:10},
		{x:30 ,y:9}
	);*/
	
	// base classes
	mobmap.installBaseMethods(  GateViewController.prototype, mobmap.AppOwnedBase  );

	pkg.GateViewController = GateViewController;
});