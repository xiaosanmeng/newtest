mmDefineModule(function(pkg) {
	'use strict';

	var kLineGateItemName = 'l-gate';
	var kPolygonGateItemName = 'p-gate';
	var kDefaultDockItems = [
		[kLineGateItemName   , 'Line Gate',    'images/map-ui/lands-gate.png'],
		[kPolygonGateItemName, 'Polygon Gate', 'images/map-ui/lands-polygon.png']
	];

	function MapDockController(mapPane) {
		this.mapPane = mapPane;
		this.mapDock = mapPane.getDock();
		
		this.addDefaultDockItems();
		this.observeEvents();
	}
	
	MapDockController.prototype = {
		// Initialization
		addDefaultDockItems: function() {
			var ls = kDefaultDockItems;
			for (var i in ls) if (ls.hasOwnProperty(i)) {
				var info = ls[i];
				this.mapDock.add(info[0], info[1], info[2]);
			}
			
			this.mapDock.adjustSize();
		},

		observeEvents: function() {
			this.mapDock.eventDispatcher().bind(
				// When icon is dropped
				mobmap.MapDockControl.Item.DropEvent,
				this.onDockItemDrop.bind(this)
			).bind(
				// When icon is dragging
				mobmap.MapDockControl.Item.DragMoveEvent,
				this.onDockItemDragMove.bind(this)
			);
		},

		setVisibility: function(v) {
			this.mapDock.setVisibility(v);
		},

		// Event handlers
		onDockItemDragMove: function(e, mouseEvent) {
			// Mouse event is not dispatched on the map during dragging. So relay it here.
			this.mapPane.updatePrevMouseMoveLocationWithMouseEvent(mouseEvent);
		},
		
		onDockItemDrop: function(e, droppedItem) {
			var loc = this.mapPane.getPreviousMouseMoveLocation();

			switch(droppedItem.name) {
			case kLineGateItemName:
				this.getOwnerApp().putNewLineGate(loc.lat, loc.lng);
				break;

			case kPolygonGateItemName:
				this.getOwnerApp().putNewPolygonGate(loc.lat, loc.lng);
				break;

			default:
				console.log("Unknown dock item:", droppedItem.name);
				break;
			}
		}
	};

	// base classes
	mobmap.installBaseMethods(  MapDockController.prototype, mobmap.AppOwnedBase  );
	
	pkg.MapDockController = MapDockController;
});
