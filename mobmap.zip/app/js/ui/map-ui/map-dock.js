mmDefineModule(function(pkg) {
	'use strict';

	var kAppearAnimationDivs = 10;

	var kDockClassName = 'mm-map-dock';
	var kDockInnerClassName = 'mm-map-dock-inner';
	var kDockItemOuterClassName = 'mm-map-dock-item-outer';
	var kDockItemInnerClassName = 'mm-map-dock-item-inner';
	var kDockItemLabelClassName = 'mm-dock-item-label';

	var kDockIconWidth   = 40;
	var kDockIconHeight  = 40;
	var kDockItemPadding = 18;
	var kDockItemTopPadding = 12;

	function MapDockControl() {
		this.itemList = [];
		
		this.animationClosure = this.doAnimation.bind(this);
		this.visibility = true;
		this.appearAnimationFrame = 0;
		
		this.borderWidth  = 1;
		this.bottomMargin = 20;
		this.generateElements();
		mmAddEventDispatcherMethod(this, this.element);
	}

	MapDockControl.prototype = {
		generateElements: function() {
			this.element  = $H('div', kDockClassName);
			this.jElement = $(this.element);

			this.innerBoxElement = $H('div', kDockInnerClassName);
			this.jInner = $(this.innerBoxElement);

			this.element.appendChild( this.innerBoxElement );
			this.initPositioningStyles();
		},
		
		initPositioningStyles: function() {
			var s = this.innerBoxElement.style;
			s.position = 'absolute';

			s.bottom = '20px';
		},

		adjustSize: function() {
			var s = this.innerBoxElement.style;
			s.position = 'absolute';
			var w = this.calcEntireWidth();
			
			s.left = $px(-(w >> 1) -this.borderWidth);
			s.width = $px(w);
		},

		setControlPositionIndex: function(index) {
			this.element.index = index;
		},
		
		getControlElement: function() {
			return this.element;
		},
		
		add: function(name, labelText, iconURL) {
			var newItem = new MapDockControl.Item(this, name, labelText, iconURL);
			this.itemList.push(newItem);
			
			this.appendItemElement(newItem);
		},
		
		appendItemElement: function(item) {
			this.innerBoxElement.appendChild( item.getElement() );
		},
				
		calcEntireWidth: function() {
			var sum = 0;
			
			var ls = this.itemList;
			for (var i = 0;i < ls.length;++i) {
				var item = ls[i];
				sum += item.getOuterWidth();
			}
			
			return sum;
		},

		getVisibility: function() {
			return this.visibility;
		},

		setVisibility: function(v, skipAnimation) {
			if (this.visibility === v) {
				return v;
			}

			this.visibility = v;
			this.appearAnimationFrame = skipAnimation ? (kAppearAnimationDivs-1) : 1;
			this.doAnimation();
		},
		
		doAnimation: function() {
			if (this.appearAnimationFrame !== 0) {
				++this.appearAnimationFrame;
			}
			
			var t = (this.appearAnimationFrame-1) / (kAppearAnimationDivs-1);
			var y;
			if (this.visibility) {
				y = (1.0 - t) * (1.0 - t);
			} else {
				y = t*t;
			}
			
			this.element.style.transform = 'translateY(' + Math.floor(y * kDockIconHeight*3) + 'px)';
			this.element.style.visibility = (y > 0.95) ? 'hidden' : '';

			if (this.appearAnimationFrame < kAppearAnimationDivs) {
				window.setTimeout(this.animationClosure, 17);
			}
		}
	};


	MapDockControl.Item = function(owner, name, labelText, iconURL) {
		this.outerElement = this.jOuterElement = null;
		this.innerElement = this.jInnerElement = null;
		
		this.outerWidth  = kDockIconWidth  + kDockItemPadding*2;
		this.outerHeight = kDockIconHeight + kDockItemPadding*2;
		
		this.innerWidth  = kDockIconWidth;
		this.innerHeight = kDockIconHeight;
		
		this.owner = owner;
		this.name = name;
		this.labelText = labelText;
		this.generateElements(labelText, iconURL);
		mmAddEventDispatcherMethod(this, this.outerElement);
	};

	MapDockControl.Item.DropEvent = 'mm-map-dock-item-drop';
	MapDockControl.Item.DragMoveEvent = 'mm-map-dock-item-drag-move';
	MapDockControl.Item.prototype = {
		generateElements: function(labelText, iconURL) {
			this.outerElement = $H('div', kDockItemOuterClassName);
			this.jOuterElement = $(this.outerElement);

			this.innerElement = $H('div', kDockItemInnerClassName);
			this.jInnerElement = $(this.innerElement);
			
			this.labelElement = $H('div', kDockItemLabelClassName);
			this.labelElement.appendChild( $T(labelText) );
			
			this.outerElement.appendChild( this.innerElement );
			this.outerElement.appendChild( this.labelElement );
			this.setGeometricStyles();
			this.setIconImageURL(this.innerElement, iconURL);
			
			this.jOuterElement.kendoDraggable({
				hint: function(element) { return element.clone(); },
				drag:    this.onDragMove.bind(this),
				dragend: this.onDragEnd.bind(this)
			});
		},

		setIconImageURL: function(element, url) {
			var s = element.style;
			
			s.backgroundImage    = url ? "url('" +url+ "')" : 'none';
			s.backgroundPosition = 'center center';
			s.backgroundRepeat   = 'no-repeat';
			if(url){ s.backgroundColor = 'transparent'; }
		},

		getElement: function() {
			return this.outerElement;
		},
		
		setGeometricStyles: function() {
			var o_s = this.outerElement.style;
			o_s.width  = $px( this.outerWidth  );
			o_s.height = $px( this.outerHeight );

			var i_s = this.innerElement.style;
			i_s.width  = $px(this.innerWidth);
			i_s.height = $px(this.innerHeight);
			i_s.marginLeft = $px(kDockItemPadding);
			i_s.marginRight = $px(kDockItemPadding);
			i_s.marginTop = $px(kDockItemTopPadding);
			
			i_s.backgroundColor = "rgba(255,0,0,0.3)";
		},
		
		getOuterWidth: function() {
			return this.outerWidth;
		},
		
		
		// Drag and drop handling
		
		getDraggable: function() {
			return this.jOuterElement.data('kendoDraggable');
		},

		onDragMove: function(e) {
			this.fire(
				MapDockControl.Item.DragMoveEvent,
				e
			);
		},

		onDragEnd: function() {
			this.getDraggable().hint.hide();
			this.fireDrop();
		},
		
		fireDrop: function() {
			this.fire(
				MapDockControl.Item.DropEvent,
				this
			);
		}
	};

	pkg.MapDockControl = MapDockControl;
});
