mmDefineModule(function(pkg) {
	'use strict';

	function GMapDirectionIcon() {
		this.size = 24;
		this.offscreenCanvas = null;
		this.g = null;
		
		this.tempP1 = {x:0, y:0};
		this.tempP2 = {x:0, y:0};
	}
	
	GMapDirectionIcon.FWD  = 0x01;
	GMapDirectionIcon.BACK = 0x02;
	
	GMapDirectionIcon.prototype = {
		ensureCanvas: function() {
			if (!this.g) {
				var cv = document.createElement('canvas');
				cv.width  = this.size;
				cv.height = this.size;

				this.offscreenCanvas = cv;
				this.g = cv.getContext('2d');
			}

			return this.g;
		},

		toDataURL: function() {
			return this.offscreenCanvas.toDataURL();
		},

		update: function(lat1, lng1, lat2, lng2, dir) {
			var g = this.ensureCanvas();
			g.clearRect(0, 0, this.size, this.size);
			
			fromLatLngToXY(lat1, lng1, this.tempP1);
			fromLatLngToXY(lat2, lng2, this.tempP2);
			
			const dx = this.tempP2.x - this.tempP1.x;
			const dy = this.tempP2.y - this.tempP1.y;
			const len = Math.sqrt(dx*dx + dy*dy);
			
			// ** swap x,y to rotate **
			const nx = (dy / len) *  8.0;
			const ny = (dx / len) * -8.0;
			
			g.save();
				for (var phase = 0;phase < 2;++phase) {
					g.strokeStyle = (0 == phase) ? '#008' : '#fff';
					g.lineWidth   = (0 == phase) ? 3 : 1;

					if (dir & GMapDirectionIcon.FWD) {
						this.render(g, nx, ny);
						this.render(g, nx, ny);
					}

					if (dir & GMapDirectionIcon.BACK) {
						const bidir = !!(dir & GMapDirectionIcon.FWD);
						this.render(g, -nx, -ny, bidir);
						this.render(g, -nx, -ny, bidir);
					}
				}
			g.restore();
		},
		
		render: function(g, dx, dy, head_only) {
			const cx = this.size >> 1;
			const cy = this.size >> 1;
			
			// rotate
			const nx = -dy * 0.5;
			const ny =  dx * 0.5;
			
			g.save();
				g.lineCap = 'square';
				g.lineJoin = 'miter';
			
				if (!head_only) {
					g.beginPath();
					g.moveTo(cx - dx, cy - dy);
					g.lineTo(cx + dx*0.8, cy + dy*0.8);
					g.stroke();
				}

				g.beginPath();
				g.moveTo(cx + nx + dx*0.5, cy + ny + dy*0.5);
				g.lineTo(cx + dx         , cy + dy         );
				g.lineTo(cx - nx + dx*0.5, cy - ny + dy*0.5);
				g.stroke();
			g.restore();
		}
	};

	function fromLatLngToXY(lat, lng, outXY) {
		const DPI = Math.PI * 2.0;
		const HPI = Math.PI / 2.0;

		const s = Math.sin(lat * Math.PI / 180.0);
		const c = Math.cos(lat * Math.PI / 180.0);

		const x = (lng / 360.0) + 0.5;

		//const x = (lng / Math.PI) / 180.0 + 0.5;
		const y = Math.log((1+c+s)/(1+c-s)) / -DPI + 0.5;

		outXY.x = x;
		outXY.y = y;
		return outXY;
	}

	pkg.GMapDirectionIcon = GMapDirectionIcon;
});