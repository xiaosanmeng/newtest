mmDefineModule(function(pkg) {
	'use strict';

	var kDarkMapTitle = "Dark";
	var kLightDarkMapTitle = "Lite dark";
	
	var kDarkMapStyle = [
		{
			featureType: "all", elementType: "all",
			stylers: [ { saturation: -99 }, { invert_lightness: true }, { lightness: -59 }, { gamma: 1 } ]
		},

		{ featureType: "poi", elementType: "all", stylers: [ { visibility: "off" } ] }
	];

	var kLightDarkMapStyle = [
		{
			featureType: "all", elementType: "all",
			stylers: [ { saturation: -99 }, { invert_lightness: true }, { lightness: -39 }, { gamma: 1.6 } ]
		},
		
		{ featureType: "poi", elementType: "all", stylers: [ { visibility: "off" } ] }
	];

	var GoogleMapsCustom = {
		setupDarkMap: function(gmap) {
			return this.setupStyledMap(gmap, kDarkMapTitle, kDarkMapStyle);
		},
		
		setupLightDarkMap: function(gmap) {
			return this.setupStyledMap(gmap, kLightDarkMapTitle, kLightDarkMapStyle);
		},
		
		setupStyledMap: function(gmap, title, styleObj) {
			var styledMap = new google.maps.StyledMapType(styleObj, { map: gmap, name: title });
			return styledMap;
		}
	};

	pkg.GoogleMapsCustom = GoogleMapsCustom;
});
