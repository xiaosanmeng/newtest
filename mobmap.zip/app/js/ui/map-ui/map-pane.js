mmDefineModule(function(pkg) {
	'use strict';
	var _tmpPt1 = {x:0, y:0};
	/*
	var ExtraMapTypeID = {
		DARK:       'dark',
		LIGHT_DARK: 'light_dark',
		OSM:        'osm',
		TONER:      'toner'
	};*/

	var DO_BENCHMARK = false;

	function MapPane(containerElement, mapExtender) {
		this.nullInitProperties();
		if (DO_BENCHMARK) {
			this.setupBenchmarkDisp();
		}
		
		this.mapExtender = mapExtender || null;
		this.savedMapOptions = null;

		// Hold container element
		this.containerElement = containerElement;
		this.jContainerElement = $(containerElement);
		
		this.nowCapturingDrag = false;
		this.pointingMode = MapPane.PointingMode.Default;
		this.initialLocation = {
			zoom: 8,
			lat: 36.6,
			lng: 138.7
		};
		
		this.prevRenderTargetTime = -1;
		this.prevMouseMoveLocation = {lat:0, lng:0};
		
		this.initGoogleMaps();
		this.setupUIMarkers();
		this.initMapUIEvents(this.gmap);
		this.initCaptureEvents(containerElement);
		this.initDockUI();
		this.initClockWidget();
		
		this.internalStyleSheet = this.insertStyleSheet();

		mmAddEventDispatcherMethod(this, this.containerElement);
	}
	
//	MapPane.ExtraMapTypeID = ExtraMapTypeID;
	
	MapPane.PointingMode = {
		Default: 0,
		Drawing: 1
	};
	
	MapPane.PointingEvent = {
		Begin: 'mm-map-pointing-begin',
		Move:  'mm-map-pointing-move',
		End:   'mm-map-pointing-end'
	};
	
	MapPane.NEED_OVERLAYS_RENDER_EVENT = "mappane-needs-overalys-render";
	MapPane.prototype = {
		// ============ Initialization ============
		nullInitProperties: function() {
			this.gmap = null;
			this.aimMarker = null;
			this.benchDispElement = null;
			this.benchLog = null;

			this.osmMapType  = null;
			this.tonerMapType  = null;
			this.exploreMapType = null;
			
			this.clock = null;
			this.dock = null;
		},
		
		setupBenchmarkDisp: function() {
			if (!this.benchDispElement) {
				this.benchLog = [];
				this.benchDispElement = document.createElement('div');
				this.benchDispElement.innerHTML = '-- FPS';

				var s = this.benchDispElement.style;
				s.fontSize = '20px';
				s.padding = '2px';
				s.color = '#fff';
				s.backgroundColor = 'rgba(0,0,0,0.8)';
				s.position = 'absolute';
				s.left = '4px';
				s.top = '4px';

				document.body.appendChild(this.benchDispElement);
			}
		},

		updateBenchmarkDisp: function(mslog) {
			if (!this.benchDispElement) {
				return;
			}
			
			var sum = 0;
			var n = mslog.length;
			for (var i = 0;i < n;++i) {
				sum += mslog[i];
			}
			
			var avg = sum / n;
			this.benchDispElement.firstChild.nodeValue = (1000.0 / avg).toFixed(1) + ' FPS';
		},

		// Map internal style sheet
		
		insertStyleSheet: function() {
			var s = document.createElement('style');
			document.body.appendChild(s);
			return s.sheet;
		},
		
		clearStyleSheetRules: function() {
			var s = this.internalStyleSheet;
			var n = s.cssRules.length;
			
			for (var i = 0;i < n;++i) {
				s.deleteRule(0);
			}
		},

		addStyleSheetMarkerColorRule: function(markerIndex, color) {
			this.internalStyleSheet.insertRule(".mm-inmap-legend-marker-" +markerIndex+ " { color: " +color+ " }", 0);
		},

		addStyleSheetAttributeBoundDisplay: function(attrName) {
			this.internalStyleSheet.insertRule(".mm-inmap-legend-onlyfor-" +attrName+ " { display:block; }", 0);
		},

		// Map initialization - - - -
		initGoogleMaps: function(overrideInitialCenter) {
			var centerLocation = this.updateInitialCenter(overrideInitialCenter);
			var mapOptions = this.generateInitialMapOptions(centerLocation);

			this.gmap = new google.maps.Map(this.containerElement, mapOptions);
			this.initCustomMapTypes(this.gmap);

			this.saveMapOptions(mapOptions);
		},
		
		saveMapOptions: function(o) {
			// delete initializers
			delete o.center;
			delete o.zoom;
			delete o.mapTypeId;
			delete o.mapTypeControlOptions;
			
			this.savedMapOptions = o;
		},

		applyMapOptions: function() {
			if (this.gmap && this.savedMapOptions) {
				this.gmap.setOptions( this.savedMapOptions );
			}
		},

		getGoogleMaps: function() { return this.gmap; },
		
		updateInitialCenter: function(overrideInitialCenter) {
			if (overrideInitialCenter) {
				this.initialLocation.lat = overrideInitialCenter.lat;
				this.initialLocation.lng = overrideInitialCenter.lng;
			}
			
			return this.initialLocation;
		},
		
		generateInitialMapOptions: function(center) {
			return {
				zoom: this.initialLocation.zoom,
				center: new google.maps.LatLng(center.lat, center.lng),
				fullscreenControl: false,
				mapTypeId: google.maps.MapTypeId.ROADMAP,
				mapTypeControlOptions: {
					mapTypeIds: this.generateDefaultMapTypeList(),
					style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
				}
			};
		},

		generateDefaultMapTypeList: function() {
			var mapTypeList = [
				google.maps.MapTypeId.HYBRID,
				google.maps.MapTypeId.ROADMAP,
				google.maps.MapTypeId.SATELLITE,
				google.maps.MapTypeId.TERRAIN,
//				ExtraMapTypeID.OSM,
//				ExtraMapTypeID.TONER
			];
			
			if (this.mapExtender && this.mapExtender.extendMapTypeList) {
				this.mapExtender.extendMapTypeList(mapTypeList);
			}
			
			return mapTypeList;
		},

		initCustomMapTypes: function(gmap) {
			// this.initDarkMap      (gmap, ExtraMapTypeID.DARK);
			// this.initLightDarkMap (gmap, ExtraMapTypeID.LIGHT_DARK);
			// this.initOpenStreetMap(gmap, "OSM"         , ExtraMapTypeID.OSM);
			// this.initTonerMap     (gmap, "Stamen toner", ExtraMapTypeID.TONER);
			
			this.exploreMapType = this.createExploreMapType();
			
			if (this.mapExtender && this.mapExtender.initMapTypes) {
				this.mapExtender.initMapTypes(gmap);
			}
		},

		setupUIMarkers: function () {
			this.aimMarker = new google.maps.Marker({
				clickable: false,
				position: new google.maps.LatLng(35.7, 139.9),
				icon: new google.maps.MarkerImage(
				    'images/aim.png',
				    new google.maps.Size(16, 16),
				    new google.maps.Point(0, 0),
				    new google.maps.Point(8, 8)
				)
			});
			
		},

		applyLayerDesiredSettings: function(layer) {
			var s = layer.getInitialSettings();
			if (!s) { return; }
			
			var t = s.getMapType();
			var z = s.getMapZoom();
			if (t) {  this.gmap.setMapTypeId(t);  }
			if (z) {  this.gmap.setZoom(z); }
			
			var content = s.getInMapContent();
			if (content) {
				var nodes = $(content.html);
				if (nodes[0]) {
					this.gmap.controls[google.maps.ControlPosition.LEFT_BOTTOM].push(nodes[0]);
				}
			}
		},

		aim: function(lat, lng) {
			this.aimMarker.setPosition( new google.maps.LatLng(lat, lng) );
			this.aimMarker.setMap(this.gmap);
		},
		
		hideAimMarker: function() {
			if ( this.aimMarker.getMap() ) {
				this.aimMarker.setMap( null );
			}
		},

		showMapControls: function(visible) {
			this.modifyControlOptions(visible);
			this.applyMapOptions();
		},
		
		modifyControlOptions: function(visible) {
			this.savedMapOptions.streetViewControl = visible;
			this.savedMapOptions.zoomControl = visible;
			this.savedMapOptions.mapTypeControl = visible;
		},

		// Trajectory layer

		createExploreMapType: function() {
			var x = mobmap.ExploreMapType.installMapType( this.getGoogleMaps() );
			x.ownerObject = null;
			this.exploreMapType = x;
			return x;
		},
		
		setTrajectoryMapDataSource: function(ds) {
			if (this.exploreMapType) {
				// this.exploreMapType.setVisibility( !!(ds) );
				this.exploreMapType.setDataSource(ds);
			}
		},

		setTrajectoryOwner: function(ownerObject) {
			if (this.exploreMapType) {
				this.exploreMapType.setOwnerObject(ownerObject);
			}
		},

		notifyTrajectoryMapSelectionChange: function() {
			if (this.exploreMapType) {
				this.exploreMapType.referSelectionIfNeeded();
			}
		},

		notifyTrajectoryMapColoringChange: function(senderLayer) {
			if (this.exploreMapType) {
				if (senderLayer) {
					if (this.exploreMapType.getOwnerObject() !== senderLayer) { return; }
				}

				this.exploreMapType.restartTrajectoryDrawing();
			}
		},

		initOpenStreetMap: function(gmap, label, typeId) {
			if (this.osmMapType) {return;}
			
		},

		initTonerMap: function(gmap, label, typeId) {
			if (this.tonerMapType) {return;}
		},

		// Control
		panTo: function(lat, lng) {
			this.gmap.panTo(new google.maps.LatLng(lat, lng));
		},

		// Clock widget
		initClockWidget: function() {
			this.clock = new mobmap.MapClockWidget();
			
			var el = this.clock.getElement();
			this.gmap.controls[google.maps.ControlPosition.TOP_RIGHT].push(el);
			
			this.updateClock(null);
		},

		setClockVisibility: function(v) {
			this.clock.setVisibility(v);
		},
		
		updateClock: function(targetProject) {
			var msec = 0;
			if (targetProject) {
				msec = targetProject.currentDateTime.getCurrentTime() * 1000.0;
			}

			var d = new Date(msec);
			this.clock.setTime(d.getHours(), d.getMinutes(), d.getSeconds(),
				mobmap.DateTime.makePrettyDateFromDateObj(d) );
		},

		// Dock UI
		initDockUI: function() {
			this.dock = new mobmap.MapDockControl();
			this.dock.setControlPositionIndex(1);

			var controlElement = this.dock.getControlElement();
			this.gmap.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(controlElement);
		},

		getDock: function() {
			return this.dock;
		},

		getSuitableMapTypeProjection: function() {
			var types = this.gmap.mapTypes;
			var candidate = types[ google.maps.MapTypeId.ROADMAP ];

			// Look other types
			if (!candidate) {
				for (var i in types) {
					if (types[i].maxZoom) {
						candidate = types[i];
						break;
					}
				}
			}
			
			return candidate.projection;
		},

		// Event handling
		initMapUIEvents: function(gmap) {
			gmap.addListener('mousemove', this.onMapMouseMove.bind(this));
		},
		
		onMapMouseMove: function(e) {
		},
		
		getPreviousMouseMoveLocation: function() {
			return this.prevMouseMoveLocation;
		},


		onContainerResize: function() {
			if (this.gmap) {
				google.maps.event.trigger(this.gmap, 'resize');
			}
		},

		// Redraw with project object - - - - -
		redraw: function(targetProject) {
			if (!targetProject) { return; }
			this.hideAimMarker();
			
			var targetTime = targetProject.currentDateTime;
			var sec = targetTime.getCurrentTimeAsInt();
			
			var benchStartTime = null;
			var dt = sec - this.prevRenderTargetTime;
			var timeDir = (dt > 0) ? 1 : (dt < 0) ? -1 : 0;
			
			if (DO_BENCHMARK) {
				benchStartTime = new Date();
			}
			
			// ----------------------------------------------------------------------------
			//  Rendering routine is not here.
			//  Event observer will render overlays.
			this.eventDispatcher().trigger(MapPane.NEED_OVERLAYS_RENDER_EVENT, [this, sec, timeDir]);
			// ----------------------------------------------------------------------------
			
			this.prevRenderTargetTime = sec;
			
			if (DO_BENCHMARK) {
				var elapsed_time = ( new Date() ) - benchStartTime;
				console.log('Render time:', elapsed_time);

				this.benchLog.push(elapsed_time);
				if (this.benchLog.length === 10) {
					this.updateBenchmarkDisp(this.benchLog);
					this.benchLog.length = 0;
				}
			}
		},
		
	
		setPointingMode: function(newMode) {
			this.nowCapturingDrag = false;
			this.pointingMode = newMode;
			this.changePointerStyle();
		},
		
		changePointerStyle: function() {
			var j = this.jContainerElement;
			if (this.pointingMode === MapPane.PointingMode.Drawing) {
				j.addClass('on-selection').
				  removeClass('on-click-selection');
			} else {
				j.removeClass('on-selection').
				  removeClass('on-click-selection');
			}
		},
	
		
		// Capture mouse events

		initCaptureEvents: function(el) {
			el.addEventListener('mousedown', this.captureMouseDown.bind(this), true);
			el.addEventListener('mousemove', this.captureMouseMove.bind(this), true);
			el.addEventListener('mouseup',   this.captureMouseUp.bind(this),   true);
		},

		captureMouseDown: function(e) {
			this.fire(MapPane.PointingEvent.Begin, e);
			
			this.blockMouseEventIfNeeded(e);
			this.nowCapturingDrag = true;
		},

		captureMouseMove: function(e) {
			if (this.nowCapturingDrag) {
				this.fire(MapPane.PointingEvent.Move, e);
			}

			this.updatePrevMouseMoveLocationWithMouseEvent(e);
		},
		
		updatePrevMouseMoveLocationWithMouseEvent: function(e) {
			var rc = this.containerElement.getBoundingClientRect();
			this.updatePrevMouseMoveLocationWithScreenCoord(e.clientX - rc.left, e.clientY - rc.top);
		},
		
		updatePrevMouseMoveLocationWithScreenCoord: function(x, y) {
			if (!this.gmap) {return;}
			if ( !(this.gmap.getBounds()) ) {return;}
			convertGMapScreenCoordToLatLng(this.gmap, x, y, this.prevMouseMoveLocation);
		},

		captureMouseUp: function(e) {
			if (this.nowCapturingDrag) {
				this.fire(MapPane.PointingEvent.Move, e);
				this.fire(MapPane.PointingEvent.End, e);
			}
			
			this.blockMouseEventIfNeeded(e);
			this.nowCapturingDrag = false;
		},
		
		blockMouseEventIfNeeded: function(e) {
			if (this.pointingMode === MapPane.PointingMode.Drawing) {
				e.stopPropagation();
				e.preventDefault();
			}
		},

		// Pointing utility functions
		elementX: function(e){ return e.pageX - this.jContainerElement.offset().left; },
		elementY: function(e){ return e.pageY - this.jContainerElement.offset().top;  },
		latLngFromClick: function(e) {
			var app = this.getOwnerApp();
			if (!app) { return null; }
			var lc = app.getLayerController();
			var overlay = lc.getTopLayerOverlay();
			if (!overlay) { return null; }

			var sx = this.elementX(e);
			var sy = this.elementY(e);
			var pt = overlay.getProjection().fromContainerPixelToLatLng(new google.maps.Point(sx , sy));

			pt.screenX = sx;
			pt.screenY = sy;
			return pt;
		}
	};

	// base classes
	mobmap.installBaseMethods(  MapPane.prototype, mobmap.AppOwnedBase  );

	pkg.MapPane = MapPane;
});
