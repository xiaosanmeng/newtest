mmDefineModule(function(pkg) {
	'use strict';

	function ToolPaneController() {
		this.toolPane = null;
	}
	
	ToolPaneController.prototype = {
		connectModelAndView: function(toolPane, modelEventDispatcher) {
			this.toolPane = toolPane;
			var L = mobmap.LayerEvent;

			modelEventDispatcher.bind(
				L.DataTimeRangeChange, this.onDataTimeRangeChange.bind(this)
			).bind(
				mobmap.Mobmap3App.Events.ProjectCreated, this.onNewProject.bind(this)
			);
		},
		
		onDataTimeRangeChange: function(e, layer) {
			var pj = layer.getOwnerProject();
			if (pj) {
				var minT = pj.calcMinTimeAmongAllLayers();
				var maxT = pj.calcMaxTimeAmongAllLayers();
				
				if (minT <= maxT) {
					var tl = this.toolPane.getTimelineBar();
					tl.setTimeRange(minT, maxT);
					tl.resetAndFullViewport();
				}
			}
		},
		
		onNewProject: function(e, app) {
			var pj = app.getCurrentProject();
			if (pj) {
				var tl = this.toolPane.getTimelineBar();
				tl.bindDateTime( pj.currentDateTime );
			}
		}
	};

	pkg.ToolPaneController = ToolPaneController;
});