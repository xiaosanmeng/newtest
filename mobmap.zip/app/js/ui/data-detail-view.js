mmDefineModule(function(pkg) {
	'use strict';
	var kAttrNameDA = 'data-aname';
	var kAttrNameID = 'data-obj-id';

	function DataDetailView(containerElement) {
		mmAddEventDispatcherMethod(this, containerElement);

		this.containerElement = containerElement;
		this.jContainerElement = $(containerElement).
		                          bind( mobmap.InfoPane.INFOPANE_EVENT_RESIZED, this.onContainerResize.bind(this) );

		this.headingAreaElement = this.generateHeadingArea();
		this.jHeadingArea       = $( this.headingAreaElement );
		
		this.toolBar = null;
		this.toolBar = this.setupToolBar(this.containerElement);

		this.itemsHolderElement = this.generateItemsHolder();
		this.jItemsHolderElement = $(this.itemsHolderElement);

		this.mainTable  = this.generateMainTable(this.itemsHolderElement);
		this.jMainTable = $( this.mainTable );
		this.observeRowHover( this.jMainTable );

		this.sourceLayer = null;
		this.numLimit = 100;
	}
	
	DataDetailView.DATAROW_HOVER_EVENT = 'detail-view-data-row-hover';
	
	DataDetailView.prototype = {
		getToolBar: function() {
			return this.toolBar;
		},
		
		setSourceLayer: function(lyr) {
			if (this.sourceLayer !== lyr) {
				this.sourceLayer = lyr;
			}
		},

		getSourceLayer: function() {
			return this.sourceLayer;
		},

		generateHeadingArea: function() {
			var el = $H('h4', 'mm-detail-view-heading');
			this.containerElement.appendChild(el);

			el.innerHTML = 'Select a layer.';

			return el;
		},

		generateItemsHolder: function() {
			var el = $H('div', 'mm-detail-view-items-holder');
			this.containerElement.appendChild(el);
			
			return el;
		},

		generateMainTable: function(parentElement) {
			var el = $H('table', 'mm-detail-view-table');
			parentElement.appendChild(el);

			return el;
		},

		onContainerResize: function() {
			var others_height = 19;

			this.jItemsHolderElement.height( this.jContainerElement.height() - others_height );
		},

		// TOOLBAR - - - - - - - - - - - - - - - - - - - - - - - - - - - -

		setupToolBar: function(container) {
			var tb = new mobmap.MMToolbar();
			container.appendChild( tb.getElement() );
			this.fillToolBar(tb);
			return tb;
		},
		
		fillToolBar: function(tb) {
			tb.addLabelItem('Export', 'mm-apptoolbar-label');
			tb.addButtonItem(DataToolbarButtonName.ExportCSV, 'Export as CSV', 'images/l-buttons/LB-csvx.png');
		},
		
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

		setDataTitle: function(s) {
			this.jHeadingArea.text( s );
		},
		
		renew: function() {
			this.clear();
			
			if (this.sourceLayer) {
				var sortedAttributeList = this.addHeadingColumns( this.sourceLayer );
				
				var spool = this.sourceLayer.getSelectionPool();
				if (spool) {
					var num = spool.count();
					this.addDataRows(this.mainTable, this.sourceLayer, num, sortedAttributeList);
				}
			}
		},

		addHeadingColumns: function(layer) {
			var ls = [];
			
			if (layer.attributeList) {
				layer.attributeList.eachAttribute(function(attr){
					ls.push(attr);
				});
			}
			
			ls.sort(function(a,b){ return a.csvColumnIndex - b.csvColumnIndex; });
			
			var tr = $H('tr', 'mm-ddtable-heading-row');
			for (var i = 0;i < ls.length;++i) {
				var attrName = ls[i].name;
				var th = $H('th');
				th.setAttribute(kAttrNameDA, attrName);

				th.appendChild( $T(attrName) );
				tr.appendChild(th);
			}
			
			this.mainTable.appendChild( tr );
			return ls;
		},

		addDataRows: function(destTable, layer, num, attrList) {
			if (num > this.numLimit) {
				num = this.numLimit;
			}
			
			var selp = layer.getSelectionPool();

			var renderedCount = 0;
			var pickPool = mobmap.LayerController.ensureOverlayPickPool(layer._map_view);
			if (!pickPool) { return; }

			var pickedCount = pickPool.pickedCount;
			var src_array = pickPool.getArray();

			var alen = attrList.length;

			for (var i = 0;i < pickedCount;++i) {
				var rec = src_array[i];
				if ( selp.isIDSelected(rec.id) ) {
					var dataRow = $H('tr', 'mm-detail-view-data-row');
					dataRow.setAttribute(kAttrNameID, rec.id);
					
					for (var j = 0;j < alen;++j) {
						var attrInfo = attrList[j];
						var dataCol = $H('td');
						var aname = attrInfo.name;
						
						var val = rec[aname];
						dataCol.appendChild( $T(val) );
						dataCol.setAttribute(kAttrNameID, rec.id);
						dataRow.appendChild(dataCol);
					}

					destTable.appendChild(dataRow);
					++renderedCount;
					if (renderedCount >= num) {
						break;
					}
				}
			}
		},

		clear: function() {
			this.jMainTable.empty();
		},
		
		// Quick aiming(mouse over)
		observeRowHover: function(j) {
			j.on('mouseenter', '.mm-detail-view-data-row', this.onDataRowMouseEnter.bind(this));
		},
		
		onDataRowMouseEnter: function(e) {
			var element = e.target;
			this.fire(
				DataDetailView.DATAROW_HOVER_EVENT,
				element.getAttribute(kAttrNameID)
			);
		}
	};

	// export
	pkg.DataDetailView = DataDetailView;
});