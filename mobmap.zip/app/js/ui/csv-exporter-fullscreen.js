mmDefineModule(function(pkg) {
	'use strict';

	function CSVExporterScreen() {
		this.lastResultURL = null;
		this.checkboxAddHeader = null;
		this.resultContentElement = null;
		this.jElement = mobmap.FullScreenBox.createBaseElementJ();
		this.element = this.jElement[0];
		this.listener = null;

		this.attrSorter = null;
		this.sorterGridElement = null;
		this.jSorterGrid = null;

		mobmap.FullScreenBox.setupFullScreen(this);
		var backButton = this.addBackButton();
		$(backButton).click( this.onBackButtonClick.bind(this) );
		this.addTitle('CSV exporter');
		
		this.sorterContainerElement = $H('div', 'mm-exporter-config-section');
		this.configurationContainerElement = $H('div', 'mm-exporter-config-section');
		this.resultContentElement = $H('div', 'mm-exporter-result-section');
		this.element.appendChild( this.sorterContainerElement );
		this.element.appendChild( this.configurationContainerElement );
		this.element.appendChild( this.resultContentElement );

		this.sorterContainerElement.innerHTML = 'Choose and reorder columns to export.';

		// config
		this.addMiscConfigurations(this.configurationContainerElement);

		// Execute button
		this.footerElement = this.addFooterArea();
		var btn = this.addExecuteButton( this.footerElement );
		$(btn).click( this.onExecuteButtonClick.bind(this) );


		mmAddEventDispatcherMethod(this, this.element);
	}

	CSVExporterScreen.prototype = {
		setListener: function(listener) {
			this.listener = listener;
		},
		
		open: function() {
			this.show();
		},

		// ATTRIBUTE SORTER
		destroySorter: function() {
			if (this.sorterGridElement) {
				this.sorterContainerElement.removeChild( this.sorterGridElement );
				
				this.sorterGridElement = null;
				this.jSorterGrid = null;

				this.attrSorter.destroy();
				this.attrSorter = null;
			}
		},

		createSorter: function(attrList) {
			this.destroySorter();
			
			this.sorterGridElement = document.createElement('div');
			this.jSorterGrid = $( this.sorterGridElement );
			this.sorterContainerElement.appendChild( this.sorterGridElement );
			
			var name_list = [];
			attrList.eachAttribute( function(a) {
				name_list.push(a.name);
			} );
			
			this.attrSorter = new mobmap.SortableAttrListView(this.sorterGridElement, name_list);
		},

		getSorterResult: function() {
			return this.attrSorter.getResult();
		},

		addMiscConfigurations: function(containerElement) {

			var pair = generateInputWithLabel({
				text: 'Add header row',
				type: 'checkbox',
				reverse: true,
				labelClass: 'mm-csvexporter-config-checkbox'
			});

			containerElement.appendChild(pair.label);
			this.checkboxAddHeader = pair.input;
		},

		isAddHeaderChecked: function() {
			return this.checkboxAddHeader.checked;
		},


		addExecuteButton: function(containerElement) {
			var btn = $H('button', 'execute-button');
			btn.appendChild( $T('Export') );
			
			containerElement.appendChild(btn);
			return btn;
		},

		onExecuteButtonClick: function() {
			if (this.listener && this.listener.csvExporterGenerateButtonClick) {
				this.listener.csvExporterGenerateButtonClick(this);
			}
		},

		revokeLastResult: function() {
			if (this.lastResultURL) {
				window.URL.revokeObjectURL(this.lastResultURL);
				this.lastResultURL = null;
			}

			this.resultContentElement.innerHTML = '';
		},

		showResult: function(blob) {
			this.revokeLastResult();
			
			var a = $H('a', 'mm-export-download-link');
			a.setAttribute('download', 'mobmap-exported.csv');
			a.appendChild( $T('Save (' +make_pretty_size(blob.size) +')' ) );
			
			this.lastResultURL = window.URL.createObjectURL(blob);
			a.href = this.lastResultURL;
	
			this.resultContentElement.appendChild(a);
		},
		
		showProgress: function(ratio) {
			if (ratio > 0) {
				this.resultContentElement.innerHTML = Math.floor(ratio * 100.0) + '%';
			} else {
				this.resultContentElement.innerHTML = 'Wait...';
			}
		},

		onBackButtonClick: function() {
			if (this.listener && this.listener.csvExporterBackButtonClick) {
				this.listener.csvExporterBackButtonClick();
			}
		},
		
		addBackButton: mobmap.FullScreenBox.addBackButton,
		addTitle: mobmap.FullScreenBox.addTitle,
		addFooterArea: mobmap.FullScreenBox.addFooterArea,
		show: mobmap.FullScreenBox.show,
		hide: mobmap.FullScreenBox.hide
	};

	function make_pretty_size(i) {
		if (i < 2048) { return i + 'Bytes'; }
		return Math.floor(i / 1024) + ' KB';
	}

	pkg.CSVExporterScreen = CSVExporterScreen;
});
