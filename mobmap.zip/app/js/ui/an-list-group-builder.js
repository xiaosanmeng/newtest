mmDefineModule(function(pkg) {
	'use strict';

	function ALGroupBuilderView() {
		this.ownerGroupId = -1;
		this.subBoxList = [];
		this.element = $H('div', 'mm-an-group-builder');
		this.jElement = $(this.element);

		this.currentFormName = mobmap.ALGroupItem.GroupForm.Stack_121;
		this.buildSubBoxes_S121();
		mmAddEventDispatcherMethod(this, this.element);
	}
	
	ALGroupBuilderView.DROP_EVENT = 'group-builder-item-drop-event';
	
	ALGroupBuilderView.prototype = {
		getCurrentFormName: function() {
			return this.currentFormName;
		},

		setOwnerGroupId: function(i) {
			this.ownerGroupId = i;
		},

		getOwnerGroupId: function() {
			return this.ownerGroupId;
		},

		getElement: function() {
			return this.element;
		},
		
		addSubBox: function(altParent) {
			var newIndex = this.subBoxList.length;
			
			var sb = new GBSubBox(this, newIndex);
			this.subBoxList.push(sb);
			
			var parent = altParent || this.element;
			parent.appendChild(sb.getElement());
		},
		
		addTableBox: function() {
			var tbl = $H('div', 'mm-an-group-tablebox');
			this.element.appendChild(tbl);
			
			return tbl;
		},
		
		addInitialSubBoxes: function() {
			this.addSubBox();
			this.addSubBox();
			this.addSubBox();
		},
		
		setGroupFormDataAttribute: function(val) {
			this.jElement.attr('data-group-form', val);
		},

		buildSubBoxes_S121: function() {
			this.addSubBox();
			
			var tbox = this.addTableBox();
			this.addSubBox(tbox);
			this.addSubBox(tbox);
			
			this.addSubBox();
		},

		buildSubBoxes_S131: function() {
			this.addSubBox();
			
			var tbox = this.addTableBox();
			this.addSubBox(tbox);
			this.addSubBox(tbox);
			this.addSubBox(tbox);
			
			this.addSubBox();
		},

		buildSubBoxes_S141: function() {
			this.addSubBox();
			
			var tbox = this.addTableBox();
			this.addSubBox(tbox);
			this.addSubBox(tbox);
			this.addSubBox(tbox);
			this.addSubBox(tbox);
			
			this.addSubBox();
		},

		buildSubBoxes_S22: function() {
			var tbox = this.addTableBox();
			this.addSubBox(tbox);
			this.addSubBox(tbox);

			var tbox2 = this.addTableBox();
			this.addSubBox(tbox2);
			this.addSubBox(tbox2);
		},

		addItem: function(subIndex, itemId, itemTitle) {
			if (subIndex < 0 || subIndex >= this.subBoxList.length) {
				return null;
			}

			var v = new GBSubItemView(itemId, itemTitle);
			this.subBoxList[subIndex].addSubItemView(v);
			return v;
		},
		
		removeItemWithId: function(subIndex, itemId) {
			if (subIndex < 0 || subIndex >= this.subBoxList.length) {
				return false;
			}

			this.subBoxList[subIndex].removeSubItemViewWithId(itemId);
			return true;
		},
		
		changeSubItemTitleIf: function(itemId, newValue)  {
			var ls = this.subBoxList;
			for (var i in ls) if (ls.hasOwnProperty(i)) {
				var subBox = ls[i];
				subBox.changeSubItemTitleIf(itemId, newValue);
			}
		},
		
		changeGroupForm: function(groupModel, newTypeName) {
			if (this.currentFormName === newTypeName) {
				return;
			}
			
			var i;
			var ls = this.subBoxList;
			for (i in ls) if (ls.hasOwnProperty(i)) {
				var subBox = ls[i];
				subBox.dispose();
			}
			ls.length = 0;

			this.jElement.find('.mm-an-group-tablebox').remove();



			switch(newTypeName) {
			case mobmap.ALGroupItem.GroupForm.Stack_121:
				this.buildSubBoxes_S121();
				break;
				
			case mobmap.ALGroupItem.GroupForm.Stack_131:
				this.buildSubBoxes_S131();
				break;

			case mobmap.ALGroupItem.GroupForm.Stack_141:
				this.buildSubBoxes_S141();
				break;

			case mobmap.ALGroupItem.GroupForm.Stack_22:
				this.buildSubBoxes_S22();
				break;
			}


			// Resume items
			var ng = groupModel.countSubGroup();
			for (i = 0;i < ng;++i) {
				var subg = groupModel.getSubGroupAt(i);
				var subg_length = subg.length;
				
				for (var j = 0;j < subg_length;++j) {
					var item = subg[j];

					var itemId    = item.getId();
					var itemTitle = item.getTitle();
					this.addItem(i, itemId, itemTitle);
				}
			}

			this.setGroupFormDataAttribute(newTypeName);
			this.currentFormName = newTypeName;
		}
	};

	function GBSubItemView(itemId, initialItemTitle) {
		this.itemId = itemId;
		
		this.element = $H('div', 'mm-an-group-subitem');
		this.element.setAttribute('data-item-id', itemId);
		this.jElement = $(this.element);
		
		this.setTitle(initialItemTitle);
	}
	
	GBSubItemView.prototype = {
		getElement: function() {
			return this.element;
		},

		removeElement: function() {
			var p = this.element.parentNode;
			if (p) {
				p.removeChild(this.element);
			}
		},

		setTitle: function(t) {
			this.jElement.text(t);
		},
		
		dispose: function() {
			this.removeElement();
		}
	};


	function GBSubBox(owner, index) {
		this.owner = owner;
		this.index = index;
		this.element = $H('div', 'mm-an-group-builder-sub');
		this.jElement = $( this.element );
		
		this.itemViewList = [];
		
		this.jElement.kendoDropTarget({
			dragenter: this.onDragEnter.bind(this),
			dragleave: this.onDragLeave.bind(this),
			group: mobmap.AnalysisObjectListView.kAnDropGroup,
			drop: this.onDrop.bind(this) });
	}
	
	GBSubBox.prototype = {
		dispose: function() {
			this.jElement.unbind();

			var ls = this.itemViewList;
			for (var i in ls) if (ls.hasOwnProperty(i)) {
				ls[i].dispose();
			}
			
			if (this.element.parentNode) {
				this.element.parentNode.removeChild(this.element);
			}
		},

		getElement: function() {
			return this.element;
		},

		getItemHolderElement: function() {
			return this.element;
		},

		onDrop: function(e) {
			this.setDragEnterClass(false);
			this.owner.fire(ALGroupBuilderView.DROP_EVENT, [this, e]);
		},
		
		onDragEnter: function() {
			this.setDragEnterClass(true);
		},

		onDragLeave: function() {
			this.setDragEnterClass(false);
		},
		
		setDragEnterClass: function(b) {
			if (b) {
				this.jElement.addClass('mman-drop-active');
			} else {
				this.jElement.removeClass('mman-drop-active');
			}
		},
		
		getOwnerGroupId: function() {
			return this.owner.getOwnerGroupId();
		},
		
		addSubItemView: function(sv) {
			var el = sv.getElement();
			var holder = this.getItemHolderElement();
			
			holder.appendChild(el);
			this.itemViewList.push(sv);
		},
		
		removeSubItemViewWithId: function(itemId) {
			var v = this.findItemById(itemId);
			if (v) {
				v.removeElement();
				this.removeItemFromList(v);
			}
		},

		changeSubItemTitleIf: function(itemId, newValue)  {
			var v = this.findItemById(itemId);
			if (v) {
				v.setTitle(newValue);
			}
		},
		
		findItemById: function(itemId) {
			var ls = this.itemViewList;
			for (var i in ls) if (ls.hasOwnProperty(i)) {
				if (ls[i].itemId === itemId) {
					return ls[i];
				}
			}
			
			return null;
		},
		
		removeItemFromList: function(item) {
			var i = this.itemViewList.indexOf(item);
			if (i >= 0) {
				this.itemViewList.splice(i, 1);
			}
		}
	};

	// export
	pkg.ALGroupBuilderView = ALGroupBuilderView;
});