mmDefineModule(function(pkg) {
	'use strict';

	function DataDetailViewController() {
		this.detailView = null;
	}
	
	DataDetailViewController.prototype = {
		connectModelAndView: function(detailView, modelEventDispatcher) {
			this.detailView = detailView;
			var tb = this.detailView.getToolBar();
			if (tb) {
				this.observeToolBar(tb);
			}

			modelEventDispatcher.
				bind( mobmap.MMProject.Events.LAYER_SELECTED, this.onSelectedLayerChange.bind(this) ).
				bind( mobmap.SelectionPool.CHANGE_EVENT,      this.onLayerLocalSelectionChanged.bind(this) ).
				bind( mobmap.LayerEvent.LoadFinish,           this.onLayerLoadFinish.bind(this)) ;

		},

		observeToolBar: function(tb) {
			tb.eventDispatcher().
			 bind( mobmap.MMToolbar.CLICK_EVENT, this.onDataToolBarClick.bind(this) );
		},

		onLayerLocalSelectionChanged: function(e, senderPool) {
			var layer = senderPool.getOwner();
			if (layer) {
				if (this.detailView.getSourceLayer() === layer) {
					this.detailView.renew();
				}
			}
		},
		
		onSelectedLayerChange: function(e, senderProject) {
			var layer = get_project_sel_layer(senderProject);
			this.detailView.setSourceLayer(layer);
			this.updateLayerTitle(layer);
		},
		
		onLayerLoadFinish: function(e, layer) {
			this.updateLayerTitle(layer);
		},
		
		updateLayerTitle: function(layer) {
			var titleText = layer ? layer.getShortDescription() : '';
			if (this.detailView.getSourceLayer() === layer) {
				this.detailView.setDataTitle(titleText);
			}
		},
		
		onDataToolBarClick: function() {
			var curLayer = this.detailView.getSourceLayer();

			var app = this.getOwnerApp();
			if (app && app.mainUI) {
				app.mainUI.openCSVExporterScreen(this, curLayer);
			}
			
		},
		
		csvExporterGenerateButtonClick: function(exporterScreen) {
			var curLayer = this.detailView.getSourceLayer();
			if (curLayer) {
				var columnList = exporterScreen.getSorterResult();
				var addHeader  = exporterScreen.isAddHeaderChecked();
				console.log(columnList, addHeader);
				
				var x = new mobmap.MOLayerCSVExporter(curLayer, columnList, addHeader);
				this.onCSVGenerateProgress(0);
				x.start({
					complete: this.onCSVGenerateComplete.bind(this),
					progress: this.onCSVGenerateProgress.bind(this)
				});
			}
		},

		csvExporterBackButtonClick: function() {
			var app = this.getOwnerApp();
			app.mainUI.closeCSVExporterScreen();
		},

		onCSVGenerateComplete: function(blob) {
			var app = this.getOwnerApp();
			app.mainUI.showCSVExporterResult(blob);
		},
		
		onCSVGenerateProgress: function(ratio) {
			var app = this.getOwnerApp();
			app.mainUI.showCSVExporterProgress( ratio );
		}
	};

	// utilities
	function get_project_sel_layer(pj) {
		var layerId = pj.lyrselGetFirstId();
		if (layerId !== null) {
			var layer = pj.getLayerList().findById(layerId);
			return layer || null;
		}
		
		return null;
	}

	// base classes
	mobmap.installBaseMethods(  DataDetailViewController.prototype, mobmap.AppOwnedBase  );

	// export
	pkg.DataDetailViewController = DataDetailViewController;
});