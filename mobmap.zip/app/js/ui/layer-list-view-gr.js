mmDefineModule(function(pkg) {
	'use strict';
	var gRadioGroupNameIndex = 0;

	var kGridLayerToolBarItems = [
		[mobmap.LayerListView.kToolButtonName_Visibility,   'Toggle visibility' ,    'eye2'  , true],
		[mobmap.LayerListView.kToolButtonName_Config    ,   'Open configuration',    'config', true, 1]
	];

	var kColorSchemePresets = [
		{type: 0, params: [1  ]},
		{type: 0, params: [0.5]},
		null,
		{type: 1, params: [  0,0,255]},
		{type: 1, params: [255,0,0  ]},
		null
	];

	function LayerListViewGridItem() {
		this.initBaseProperties();
		this.colorSchemePresetList = [];
		
		this.jAutoMaxButton = null;
		this.labelCheck = null;
		this.txValueMax = null;
		this.jRenderValueMaxField = null;
		
		this.generateBoxElement('mm-layer-list-grid-item', kGridLayerToolBarItems);
	}

	LayerListViewGridItem.prototype = {
		resizeFlexibleElements: function() {
			if (!this.jElement) { return; }

			this.pvFitWidth(this.jElement);
		},
		
		// [][][] Configuration panel [][][]
		fillConfigurationPanelContent: function(panel) {
			this.generateLabelToggle( panel.getElement() );
			this.generateValueRangeConfig( panel.getElement() );
			this.generateColorSchemeSelector( panel.getElement() );
			this.generateSpecingSelector( panel.getElement() );
		},
		
		generateLabelToggle: function(containerElement) {
			var pair = generateInputWithLabel({
				text: 'Label',
				type: 'checkbox',
				reverse: true
			});
			
			this.labelCheck = pair.input;
			containerElement.appendChild(pair.label);
			containerElement.appendChild( document.createElement('br') );
			$(pair.input).click( this.onLabelCheckClick.bind(this) );
		},
		
		onLabelCheckClick: function() {
			var val = this.labelCheck.checked;
			
			this.getModel().setShowLabel(val);
		},

		generateColorSchemeSelector: function(containerElement) {
			mobmap.LayerListView.addConfigCaption(containerElement, 'Color scheme');
			this.addColorSchemeRadios(kColorSchemePresets, addConfigSubBox(containerElement) );
		},

		generateSpecingSelector: function(containerElement) {
			mobmap.LayerListView.addConfigCaption(containerElement, 'Spacing');
			this.addSpacingRadios( addConfigSubBox(containerElement) );
		},

		addColorSchemeRadios: function(list, containerElement) {
			var radioName = 'mm-colorscheme-radio-' + (++gRadioGroupNameIndex);
			
			var len = list.length;
			for (var i = 0;i < len;++i) {
				var item = list[i];
				if (!item) {
					// newline
					containerElement.appendChild(document.createElement('br'));
					continue;
				}
				
				var cl = new mobmap.GridColorList();
				if (item.type === 0) {
					mobmap.GridColorList.prototype.generateHueWheel.apply(cl, item.params);
				} else {
					mobmap.GridColorList.prototype.generateAplhaGradient.apply(cl, item.params);
				}

				var previewImage = cl.generatePreviewImage();
				var radio = mobmap.LayerListView.createBoxStyleRadio(
					'mm-colorscheme-radio',
					"url('" + previewImage.toDataURL() +"')",
					containerElement
				);
				radio.value = this.colorSchemePresetList.length;
				radio.name = radioName;
				radio.checked = (i === 0);
				
				this.colorSchemePresetList.push(cl);
			}
		},
		
		addSpacingRadios: function(containerElement) {
			var radioName = 'mm-gridspacing-radio-' + (++gRadioGroupNameIndex);

			for (var i = 0;i < 2;++i) {
				var radio = mobmap.LayerListView.createBoxStyleRadio(
													'mm-gridspacing-radio', 
													(0==i) ? "url(images/grid-ns.png)"
													　　　　　　　: "url(images/grid-sp.png)" ,
													containerElement
				);

				radio.type = 'radio';
				radio.value = i;
				radio.name = radioName;

				radio.title = i ? 'enabled' : 'disabled';
				
			}
		},
		
		getJColorSchemeRadio: function() {
			return this.jElement.find('.mm-colorscheme-radio');
		},

		getJGridSpacingRadio: function() {
			return this.jElement.find('.mm-gridspacing-radio');
		},

		getJRenderValueMaxField: function() {
			return this.jRenderValueMaxField;
		},

		getSelectedColorSchemeIndex: function() {
			return this.jElement.find('.mm-colorscheme-radio:checked').val() - 0;
		},
		
		getSelectedColorScheme: function() {
			return this.colorSchemePresetList[ this.getSelectedColorSchemeIndex() ] || null;
		},

		getGridSpacingEnabled: function() {
			return this.jElement.find('.mm-gridspacing-radio:checked').val() > 0;
		},

		getRenderValueMaxFieldValue: function() {
			if (this.txValueMax) {
				var n = parseInt(this.txValueMax.value, 10);
				if (!isFinite(n)) {
					n = 1;
				}

				return n;
			}
			
			return 1;
		},
		
		setRenderValueMaxFieldValue: function(newVal) {
			if (this.txValueMax) {
				var oldVal = this.getRenderValueMaxFieldValue();
				if (oldVal !== newVal) {
					this.txValueMax.value = newVal;
				}
			}
		},

		setGridSpacingFieldValue: function(enabled) {
			var sel = enabled ? '[value=1]' : '[value=0]';
			var el = this.jElement.find('.mm-gridspacing-radio' + sel)[0];
			if (el) {
				el.checked = true;
			}
		},

		generateValueRangeConfig: function(containerElement) {
			var pair = generateInputWithLabel({
				text: 'Value max: ',
				type: 'number',
				reverse: false
			});
			
			pair.input.min   = 1;
			pair.input.max   = 999999;
			pair.input.value = 1000;
			
			var autoButton = document.createElement('button');
			autoButton.appendChild( $T('Auto') );
			this.jAutoMaxButton = $(autoButton);
			
			containerElement.appendChild(pair.label);
			containerElement.appendChild($T(' '));
			containerElement.appendChild(autoButton);
			
			this.txValueMax = pair.input;
			this.jRenderValueMaxField = $( this.txValueMax );
		},


		getJAutoMaxButton: function() {
			return this.jAutoMaxButton;
		},
		
		syncFromModel: function() {
			var m = this.getModel();
			if (m) {
				this.setRenderValueMaxFieldValue( m.getRenderValueMax() );
				this.setGridSpacingFieldValue( m.getSpacingEnabled() );
			}
			
			if (this.pvUpdateLayerPreview) {
				this.pvUpdateLayerPreview();
			}
		},
		
		pvUpdateLayerPreview: function() {
			var m = this.getModel();
			var cv = this.layerPreviewCanvas;
			if (cv && m) {
				GridLayerPreviewRenderer.render(cv, m);
			}
		}
	};
	
	function addConfigSubBox(containerElement) {
		var box = document.createElement('div');
		containerElement.appendChild(box);

		return box
	}
	
	var GridLayerPreviewRenderer = {
		CellSize: 12,
		
		render: function(canvas, layerObj) {
			var g = canvas.getContext('2d');
			var w = canvas.width | 0;
			var h = canvas.height | 0;
			g.clearRect(0, 0, w+1, h+1);
			
			var spacing = layerObj.getSpacingEnabled();
			var colorList = layerObj.getColorList();
			var mgn = spacing ? 1 : 0;
			var sz  = spacing ? (this.CellSize-2) : this.CellSize;
			
			var cs = this.CellSize;
			
			var cols = this.calcNumOfCols(w);
			var rows = this.calcNumOfRows(h);
			for (var y = 0;y < rows;++y) {
				for (var x = 0;x < cols;++x) {
					var val = this.getExampleCellValue(x, y);
					g.fillStyle = colorList.getColor(val);
					
					g.fillRect(cs*x + mgn, cs*y + mgn, sz, sz);
				}
			}
		},
		
		calcNumOfCols: function(canvasWidth) {
			return Math.floor(canvasWidth / this.CellSize) + 1;
		},
		
		calcNumOfRows: function(canvasHeight) {
			return Math.floor(canvasHeight / this.CellSize) + 1;
		},
		
		getExampleCellValue: function(cx, cy) {
			var wx = ( (0.5 * Math.cos( (cx-6) * 0.3 )) + 0.6 ) / (cx*0.1 + 0.6);
			var wy = ( (0.5 * Math.cos( (cy+cx-2) * 0.4 )) + 0.5 );
			return Math.min(wx * wy, 1.0);
		}
	};

	mobmap.installBaseMethods(  LayerListViewGridItem.prototype, mobmap.LayerListView.ItemBase  );
	mobmap.installBaseMethods(  LayerListViewGridItem.prototype, mobmap.LayerListView.ItemWithPreviewBase  );
	pkg.LayerListViewGridItem = LayerListViewGridItem;
});
