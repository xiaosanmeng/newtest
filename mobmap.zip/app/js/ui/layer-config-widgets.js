mmDefineModule(function(pkg) {
	'use strict';

	var LayerConfigWidgets = {
		generatePresetAppendButton: function(headingElement) {
			var btn = $H('button', 'mm-config-preset-append-button');
			btn.innerHTML = '...';
			headingElement.appendChild(btn);

			return btn;
		},

		generateNumMarkers: function(handler) {
			return mobmap.FormUtils.generateRangeInLabel({
				labelText: 'Variation',
				labelClass: 'mm-config-range-label',
				min: 2,
				max: 30,
				enableCounter: true,
				change:  handler
			});
		},

		generateNumIndexScaling: function(handler) {
			return mobmap.FormUtils.generateRangeInLabel({
				labelText: 'Index scaling',
				labelClass: 'mm-config-range-label-2',
				min: 1,
				max: 10,
				enableCounter: true,
				change:  handler
			});
		},

		// Composition
		generateCompositionRadioSet: function(containerElement, rname, rclass) {
			var radio1 = mobmap.LayerListView.createBoxStyleRadio(
				rclass,
				'url(images/cmp-normal.png)',
				containerElement
			);

			var radio2 = mobmap.LayerListView.createBoxStyleRadio(
				rclass,
				'url(images/cmp-add.png)',
				containerElement
			);
			
			radio1.name = rname;
			radio2.name = rname;
			radio1.value = 0;
			radio2.value = 1;
		},
		
		// ********* MARKER COLORING *********
		generateReverseButton: function(data_value) {
			var rvbtn = $H('span', 'mm-markercolor-reverse-subbutton');
			rvbtn.addEventListener('click', event_stopper, true);
			rvbtn.setAttribute('data-radio-value', data_value);

			return rvbtn;
		},

		generateMarkerColoringRadio: function(seqIndex, radioName, containerElement, presetData, previewCanvas) {
			var rvbtn = LayerConfigWidgets.generateReverseButton(presetData.id);
			var radio = mobmap.LayerListView.createBoxStyleRadio(
				'mm-markercolor-radio',
				"url('" + previewCanvas.toDataURL() +"')",
				containerElement,
				rvbtn
			);

			radio.checked = (seqIndex === 0);
			radio.value = presetData.id;
			radio.name = radioName;

			return radio;
		},

		// O O o o . . MARKER SIZING . . o o O O
		generateSizingRadioSet: function(radioName) {
			var box = $H('div', 'mm-markersizing-conf');
			mobmap.LayerListView.addConfigSubCaption(box, 'Sizing');

			var func = this.addSizngRadio;
			var SZ = mobmap.MarkerOptionModelProxy.Sizing;
			func(box, radioName, SZ.Default , 3,  0, 'small', true);
			func(box, radioName, SZ.Mid     , 4,  0, 'mid',   true);
			func(box, radioName, SZ.Large   , 6,  0, 'large', true);
			box.appendChild($H('br'));
			func(box, radioName, SZ.ToLarge , 2,  1, 'small to large');
			func(box, radioName, SZ.ToSmall , 6, -1, 'large to small');

			return box;
		},
		
		addSizngRadio: function(containerElement, radioName, value, startSize, dr, title, shortStyle) {
			var cv = mobmap.LayerListViewMovingObjectItem.generateMarkerSizingIcon(
				shortStyle ? 64 : 96, 24,
				startSize, dr, shortStyle ? 3 : 5
			);
			var radio = mobmap.LayerListView.createBoxStyleRadio(
				'mm-markersizing-radio',
				"url('" + cv.toDataURL() +"')",
				containerElement
			);
			
			if (shortStyle) {
				radio.className += ' sizingradio-short-style';
			}
			
			radio.name = radioName;
			radio.title = title;
			radio.value = value;
		},
		
		// Trajectory limit
		generateLimitConfigNumberInput: function(parent, distance_mode) {
			var num = document.createElement('input');
			num.type = 'number';
			num.max = 99999;
			parent.appendChild(num);
			
			if (distance_mode) {
				num.min = 0.001;
				num.step = 0.001;
				num.value = 100;
				parent.appendChild($T('km'));
			} else {
				num.min = 0.1;
				num.step = 0.1;
				num.value = 60;
				parent.appendChild($T('min.'));
			}
			
			return $(num);
		},
		
		// line style
		generateTrajectoryLineStyleChooser: function(containerElement, radio_seq) {
			//var box = $H('div', 'mm-trajstyle-conf');
			var rname = 'trjstyle-radio-' + radio_seq;
			var rclass = 'mm-trajstyle-radio';

			var radio1 = mobmap.LayerListView.createBoxStyleRadio(
				rclass,
				'url(images/ls-normal.png)',
				containerElement
			);

			var radio2 = mobmap.LayerListView.createBoxStyleRadio(
				rclass,
				'url(images/ls-fat.png)',
				containerElement
			);

			radio1.name = rname;
			radio2.name = rname;
			radio1.value = kTrajLineStyle_Normal;
			radio2.value = kTrajLineStyle_Fat;
		},
		
		generateTrajLimitRadio: function(containerElement,  radioName, label, value, sideBox) {
			var pair = generateInputWithLabel({
				text: label, type:'radio', reverse:true
			});
			
			pair.input.checked = (value===0);
			pair.input.name = radioName;
			pair.input.value = value;

			containerElement.appendChild(pair.label);
			if (sideBox){ containerElement.appendChild(sideBox); }
			containerElement.appendChild( document.createElement('br') );

			return pair;
		}
	};

	function event_stopper(e) {
		e.preventDefault();
	}

	// export
	pkg.LayerConfigWidgets = LayerConfigWidgets;
});