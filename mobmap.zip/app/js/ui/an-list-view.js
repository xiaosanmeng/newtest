mmDefineModule(function(pkg) {
	'use strict';
	var kGroupFormToggle = 'gf-toggle';
	
	function AnalysisObjectListView(containerElement) {
		this.toolbarObject = null;
		this.toolbarElement = null;

		// Hold container element
		this.containerElement = containerElement;
		this.jContainerElement = $(containerElement).bind( mobmap.InfoPane.INFOPANE_EVENT_RESIZED, this.onContainerResize.bind(this) );
		this.initToolBarArea();
		this.itemsHolderElement = this.generateItemsHolder();
		this.jItemsHolderElement = $(this.itemsHolderElement);

		this.itemList = [];

		mmAddEventDispatcherMethod(this, this.containerElement);
	}

	AnalysisObjectListView.kToolButtonName_AddGroup    = 'add-group';
	AnalysisObjectListView.kToolButtonName_Export      = 'export';
	AnalysisObjectListView.kToolButtonName_Import      = 'import';
	AnalysisObjectListView.kToolButtonName_ShapeImport = 'shape-import';
	AnalysisObjectListView.kAnDropGroup = 'an-item';
	AnalysisObjectListView.kItemFlagAttrName = 'data-is-anitem';
	AnalysisObjectListView.kItemIdAttrName   = 'data-anitem-id';

	AnalysisObjectListView.kItemToolButtonName_Visibility = 'item-visibility';
	AnalysisObjectListView.kItemToolButtonName_SingleExport = 'single-export';

	AnalysisObjectListView.prototype = {
		getByIndex: function(i) {
			return this.itemList[i] || null;
		},

		getByItemId: function(iid) {
			var ls = this.itemList;
			for (var i in ls) if (ls.hasOwnProperty(i)) {
				var v = ls[i];
				if (v.ownerModel) {
					if (v.ownerModel.getId() === iid) {
						return v;
					}
				}
			}
			
			return null;
		},

		bulkCall: function(methodName, arg1,arg2) {
			var ls = this.itemList;
			for (var i in ls) if (ls.hasOwnProperty(i)) {
				var v = ls[i];
				if (v[methodName]) {
					v[methodName](arg1, arg2);
				}
			}
		},

		initToolBarArea: function() {
			var tb = new mobmap.MMToolbar();
			this.toolbarObject = tb;
			this.toolbarElement = tb.getElement();
			
			// Items
			tb.addButtonItem(AnalysisObjectListView.kToolButtonName_AddGroup,
				'New group',    'images/l-buttons/LB-group.png'  , null);

			tb.addButtonItem(AnalysisObjectListView.kToolButtonName_Export,
				'Export',    'images/l-buttons/LB-export.png'  , null, true);
	
			tb.addButtonItem(AnalysisObjectListView.kToolButtonName_Import,
				'Import',    'images/l-buttons/LB-import.png'  , null);

			const USE_SHP = false;
			if (USE_SHP) {
				tb.addButtonItem(AnalysisObjectListView.kToolButtonName_ShapeImport,
					'Import shape file', 'images/l-buttons/LB-in-shape.png'  , null);
			}

			this.containerElement.appendChild(this.toolbarElement);	
		},

		getTopToolBar: function() {
			return this.toolbarObject;
		},

		getAllExportButton: function() {
			return this.toolbarObject.getButtonByName(AnalysisObjectListView.kToolButtonName_Export);
		},

		generateItemsHolder: function() {
			var el = $H('div', 'mm-aolist-view-items-holder');
			this.containerElement.appendChild(el);

			return el;
		},

		removeItem: function(itemView) {
			var i = this.itemList.indexOf(itemView);
			if (i < 0) {
				return false;
			}

			this.itemList.splice(i, 1);
			this.itemsHolderElement.removeChild( itemView.getElement() );
			
			return true;
		},

		newGateItem: function(ownerModel, insertPos) {
			var v = null;
			if (ownerModel.type === mobmap.LandSensorTypes.Group) {
				v = new ALGroupItem(ownerModel);
			} else {
				v = new ALNormalGateItem(ownerModel);
			}

			this.addViewItem(v, insertPos);

			return v;
		},

		addViewItem: function(v, insertPos) {
			if (this.itemList.indexOf(v) >= 0) {
				return false;
			}
			
			var nextItem = this.getByIndex(insertPos);
			if (nextItem) {
				this.itemList.splice(insertPos, 0, v);
			} else {
				this.itemList.push(v);
			}
			
			this.appendItemElement(v, nextItem);

			return true;
		},

		appendItemElement: function(item, nextItem) {
			var el = item.getElement();
			var el2 = nextItem ? nextItem.getElement() : null;
			this.itemsHolderElement.insertBefore(el, el2);
		},
		
		getIndexOf: function(item) {
			return this.itemList.indexOf(item);
		},
		
		onContainerResize: function() {
			this.jItemsHolderElement.height( this.jContainerElement.height() - 20 );
		}
	};


	var ALGateItemBase = {
		initProperties: function(ownerModel) {
			this.ownerModel = ownerModel;
			this.element  = null;
			this.jElement = null;
			this.jTitleElement = null;
			this.jTitleInner   = null;
			this.jRemoveButtonImage = null;
			
			this.toolBar = null;
		},

		off: function() {
			this.jElement.off();
			this.jTitleElement.off();
			this.jTitleInner.off();
		},

		getElement: function() {
			return this.element;
		},

		generateBoxElement: function(ownerModel) {
			var boxClass = null;
			if (this.getItemBoxClass) {
				boxClass = this.getItemBoxClass();
			} else {
				boxClass = 'mm-ao-list-item';
			}
			
			this.element = $H('div', boxClass);
			this.jElement = $( this.element );

			this.element.setAttribute(AnalysisObjectListView.kItemFlagAttrName, '1');
			this.element.setAttribute(AnalysisObjectListView.kItemIdAttrName, ownerModel.getId());
			this.generateTitleArea(this.element, ownerModel);
			this.toolBar = this.generateToolbarArea(this.element, ownerModel.type);
			
			var contentArea = $H('div', 'mm-ao-list-item-content');
			this.element.appendChild(contentArea);
			this.fillContentArea(contentArea, ownerModel);
			
			mmAddEventDispatcherMethod(this, this.element);
		},

		generateTitleArea: function(parentElement, ownerModel) {
			var ico = $H('img', 'lv-header-icon');
			var t = $H('h2', this.getTitleClass());
			var s = $H('span');
			t.appendChild(ico)
			t.appendChild(s)
			s.appendChild( $T( ownerModel.getTitle() ) );
	
			ico.width = 20;
			ico.src = getGateTypeIconURL(ownerModel.type);
			this.jTitleElement = $(t);
			this.jTitleInner   = $(s);
			parentElement.appendChild(t);
			this.putRemoveButton(t);
			
			var renamer = new mobmap.RenameButton(s, 'images/rename-btn.png', this);
		},

		// Item tool bar
		generateToolbarArea: function(parentElement, ownerModelType) {
			var tb = new mobmap.MMToolbar();
			if (this.fillToolItems) {
				this.fillToolItems(tb);
			}

			parentElement.appendChild(tb.getElement());
			
			return tb;
		},

		_fillGroupToolItems: function(toolBar) {
			toolBar.addButtonItem(ALGroupItem.GroupForm.Stack_121,   '1-2-1',  'images/gate-types/gg-2.png'  , kGroupFormToggle);
			toolBar.addButtonItem(ALGroupItem.GroupForm.Stack_131,   '1-3-1',  'images/gate-types/gg-3.png'  , kGroupFormToggle);
			toolBar.addButtonItem(ALGroupItem.GroupForm.Stack_141,   '1-4-1',  'images/gate-types/gg-141.png', kGroupFormToggle);
			toolBar.addButtonItem(ALGroupItem.GroupForm.Stack_22 ,   '2-2'  ,  'images/gate-types/gg-4.png'  , kGroupFormToggle);
		},

		_fillNormalToolItems: function(toolBar) {
			toolBar.addButtonItem(AnalysisObjectListView.kItemToolButtonName_Visibility,  'Toggle visibility',  'images/l-buttons/LB-eye2.png'  , mobmap.MMToolbar.SELF_TOGGLE);
			toolBar.addButtonItem(AnalysisObjectListView.kItemToolButtonName_SingleExport,'Export',  'images/l-buttons/LB-export.png', null, true);
		},
		
		_getMainToolBar: function() {
			return this.toolBar;
		},


		setTitle: function(newValue) {
			this.jTitleInner.text(newValue);
		},
		
		putRemoveButton: function(titleElement) {
			this.jRemoveButtonImage = mobmap.LVUtility.putTitleBarRemoveButton(titleElement);
			return this.jRemoveButtonImage;
		},

		observeRemoveButtonClick: function(handler) {
			return this.jRemoveButtonImage.click(handler);
		},

		getExportButton: function() {
			var tb = this.getMainToolBar();
			if (tb) {
				return tb.getButtonByName( AnalysisObjectListView.kItemToolButtonName_SingleExport );
			}
			return null;
		},

		updateExportLink: function(url, name) {
			var btn = this.getExportButton();
			if (btn) {
				btn.configureLink(url, name + '.json');
			}
		}
	};

	function getGateTypeIconURL(modelType) {
		switch(modelType) {
		case mobmap.LandSensorTypes.PolygonGate:
			return 'images/gate-types/gt-polygon.png';  break;

		case mobmap.LandSensorTypes.Group:
			return 'images/gate-types/gt-group.png';  break;
			
		default:
			break;
		}
		
		return 'images/gate-types/gt-line.png';
	}

	// Typed item views +++++++++++++++++++++++++++

	function ALNormalGateItem(ownerModel) {
		this.initProperties(ownerModel);
		
		this.generateBoxElement(ownerModel);
		this.setupDrag();
	}
	
	ALNormalGateItem.prototype = {
		fillToolItems: ALGateItemBase._fillNormalToolItems,
		getMainToolBar: ALGateItemBase._getMainToolBar,
		
		getTitleClass: function() {
			return 'mm-ao-list-title';
		},
		
		fillContentArea: function(contentAreaElement, ownerModel) {
			
		},
		
		setupDrag: function() {
			this.jElement.kendoDraggable({
				filter: '.mm-draggable',
				group: AnalysisObjectListView.kAnDropGroup,
				hint: function(element) { return element.clone(); },
				drag:    this.onDragMove.bind(this),
				dragend: this.onDragEnd.bind(this)
			});
			
			this.jTitleElement.addClass('mm-draggable');
		},

		onDragMove: function() {
			
		},

		onDragEnd: function() {
			
		},

		renamerWillStartEdit: function(renamer) {
			this.jTitleElement.removeClass('mm-draggable');
		},

		renamerDidFinishEdit: function(renamer, newValue, shouldAdopt) {
			this.jTitleElement.addClass('mm-draggable');
			if (shouldAdopt) {
				this.ownerModel.setTitle(newValue);
			}
		}
	};


	function ALGroupItem(ownerModel) {
		this.groupBuilder = null;
		this.initProperties(ownerModel);
		this.generateBoxElement(ownerModel);
	}

	ALGroupItem.GroupForm = {
		Stack_121: 's121',
		Stack_131: 's131',
		Stack_141: 's141',
		Stack_22: 's22'
	};

	ALGroupItem.prototype = {
		fillToolItems: ALGateItemBase._fillGroupToolItems,
		getMainToolBar: ALGateItemBase._getMainToolBar,

		getTitleClass: function() {
			return 'mm-ao-list-group-title';
		},

		getItemBoxClass: function() {
			return 'mm-ao-list-item mm-ao-list-group-item';
		},

		fillContentArea: function(contentAreaElement, ownerModel) {
			this.groupBuilder = new mobmap.ALGroupBuilderView();
			this.groupBuilder.setOwnerGroupId( ownerModel.getId() );
			
			contentAreaElement.appendChild( this.groupBuilder.getElement() );
		},
		
		addSubItem: function(targetItem, subIndex) {
			var iid   = targetItem.getId();
			var title = targetItem.getTitle();
			
			this.groupBuilder.addItem(
				subIndex,
				iid,
				title
			);
		},

		getCurrentFormName: function() {
			return this.groupBuilder.getCurrentFormName();
		},

		removeSubItemWithId: function(itemId, subIndex) {
			this.groupBuilder.removeItemWithId(subIndex, itemId);
		},

		renamerDidFinishEdit: function(renamer, newValue, shouldAdopt) {
			if (shouldAdopt) {
				this.ownerModel.setTitle(newValue);
			}
		},

		changeSubItemTitleIf: function(itemId, newValue) {
			this.groupBuilder.changeSubItemTitleIf(itemId, newValue);
		},
		
		changeGroupForm: function(typeName) {
			this.getMainToolBar().selectInToggleGroup(kGroupFormToggle, typeName);
			this.groupBuilder.changeGroupForm(this.ownerModel, typeName);
		}
	};

	// inherit
	mobmap.installBaseMethods(ALNormalGateItem.prototype, ALGateItemBase);
	mobmap.installBaseMethods(ALGroupItem.prototype, ALGateItemBase);

	// export
	pkg.AnalysisObjectListView = AnalysisObjectListView;
	pkg.ALGroupItem = ALGroupItem;
});