mmDefineModule(function(pkg) {
	'use strict';
	var kPopupNonce = Math.floor((new Date() - 0) + Math.random() * 10000000);

	function PopupManager() {
		this.nameMap = {};
		this.initialDataMap = {};
	}

	PopupManager.prototype = {
		open: function(ownerId, contentURL, initialData) {
			var features = "menubar=no,toolbar=no,dialog=yes";
			var name = this.makeWindowName(ownerId);
			
			// remember initial data (if specified)
			delete this.initialDataMap[name];
			if (initialData) {
				this.initialDataMap[name] = initialData;
			}

			// open - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
			this.nameMap[name] = window.open(contentURL + '?wid=' + name,  name, features);
		},

		sendMessage: function(ownerId, messageObject) {
			var name = this.makeWindowName(ownerId);
			var w = this.nameMap[name];
			if (w) {
				w.postMessage(messageObject, '*');
			}
		},

		makeWindowName: function(ownerId) {
			return "popup-" +kPopupNonce+ "-" + ownerId;
		},
		
		onOnloadMessageReceived: function(windowId) {
			var wnd = this.nameMap[windowId];
			if (wnd) {
				
				// Send initial data
				if (this.initialDataMap[windowId]) {
					wnd.postMessage({
						command: 'sendInitialData',
						content: this.initialDataMap[windowId]
					}, '*');
					
					delete this.initialDataMap[windowId];
				}
				
			}
		}
	};

	pkg.PopupManager = PopupManager;
});
