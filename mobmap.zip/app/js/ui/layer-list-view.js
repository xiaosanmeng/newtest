mmDefineModule(function(pkg) {
	'use strict';

	function LayerListView(containerElement) {

		// Hold container element
		this.containerElement = containerElement;
		this.jContainerElement = $(containerElement);
		this.listToolBar = null;
		this.itemsHolderElement = null;

		this.itemList = [];
		this.initializeTopBar(this.containerElement);
		this.itemsHolderElement = this.generateItemsHolder();
		this.jItemHolder = $( this.itemsHolderElement );

		mmAddEventDispatcherMethod(this, this.containerElement);
		this.eventDispatcher().bind(LayerListView.REQUIRE_COLOR_CONFIG_EVENT, this.onItemRequestedColorConfig.bind(this));
	}

	LayerListView.kListToolButtonName_AddMov       = 'l_addmov';
	LayerListView.kListToolButtonName_AddGrid      = 'l_addgrid';
	LayerListView.kListToolButtonName_AddLive      = 'l_addlive';
	LayerListView.kListToolButtonName_AddLiveGrid  = 'l_add_lvgrid';
	
	LayerListView.kToolButtonName_Config     = 'config';
	LayerListView.kToolButtonName_Visibility = 'visibility';
	LayerListView.kToolButtonName_SelOnly    = 'selonly';
	LayerListView.kToolButtonName_Tail       = 'tail';
	LayerListView.kToolButtonName_Trajectory = 'traj';
	LayerListView.kToolButtonName_SelClear   = 'sel-clear';
	LayerListView.kLayerPreviewStandardHeight = 48;
	LayerListView.kMarkerPreviewStandardHeight = 48;

	LayerListView.createButtonStyleRadio = function(className, bgURL) {
		var radio = document.createElement('input');
		radio.className = className + ' mm-image-button-style-radio';
		radio.type = 'radio';

		if (bgURL) {
			radio.style.backgroundImage = bgURL;
		}

		return radio;
	};

	LayerListView.createBoxStyleRadio = function(className, bgURL, labelContainer, optionalInnerElement) {
		var lab = document.createElement('label');

		var box = document.createElement('span');
		box.className = 'mm-image-button-style-radio';
		lab.appendChild(box);

		var radio = document.createElement('input');
		radio.style.display = 'none';
		radio.className = className;
		radio.type = 'radio';

		if (bgURL) {
			box.style.backgroundImage = bgURL;
		}
	
		lab.appendChild(radio);
		lab.appendChild(box);
		labelContainer.appendChild(lab);
		
		if (optionalInnerElement) {
			box.appendChild(optionalInnerElement);
		}
		
		return radio;
	};

	LayerListView.addHeadingElement = function(containerElement, text, tagname, markerURL) {
		var caption = document.createElement(tagname);
		
		if (markerURL) {
			var mk = document.createElement('img');
			mk.alt = '';
			mk.src = markerURL;
			caption.appendChild(mk);
		}
		
		caption.appendChild( $T(text) );
		containerElement.appendChild(caption);
		return caption;
	};

	LayerListView.addConfigCaption = function(containerElement, text, markerURL) {
		return LayerListView.addHeadingElement(containerElement, text, 'h4', markerURL);
	};
	
	LayerListView.addConfigSubCaption = function(containerElement, text) {
		return LayerListView.addHeadingElement(containerElement, text, 'h5');
	};

	LayerListView.addCheckboxSubCaption = function(containerElement, text) {
		var caption = document.createElement('h5');
		var lab = document.createElement('label');
		var chk = document.createElement('input');
		chk.type = 'checkbox';
		
		lab.appendChild( chk );
		lab.appendChild( $T(text) );
		caption.appendChild( lab );
		containerElement.appendChild(caption);
		
		return chk;
	};

	LayerListView.prototype = {
		// List global tool bar
		initializeTopBar: function(barContainerElement) {
			var tb = new mobmap.MMToolbar();
			this.listToolBar = tb;

			barContainerElement.appendChild(tb.getElement());
			this.addListToolButtons(tb);
		},

		addListToolButtons: function(tb) {
			// DATA LOAD BUTTONS - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
			tb.addButtonItem(LayerListView.kListToolButtonName_AddMov ,     'Add moving data',       'images/l-buttons/LB-addmov2.png'  , null);
			tb.addButtonItem(LayerListView.kListToolButtonName_AddLive,     'Add live moving data',  'images/l-buttons/LB-addlive2.png' , null);
			tb.addButtonItem(LayerListView.kListToolButtonName_AddGrid,     'Add grid data',         'images/l-buttons/LB-addgrid2.png' , null);
if (1) { // <------------- TEST
			tb.addButtonItem(LayerListView.kListToolButtonName_AddLiveGrid, 'Add live grid data',    'images/l-buttons/LB-livegrid2.png', null);
}
		},

		observeListToolBarButtonClick: function(closure) {
			this.listToolBar.eventDispatcher().
			 bind( mobmap.MMToolbar.CLICK_EVENT, closure );
		},
		

		generateItemsHolder: function() {
			var el = $H('div', 'mm-list-view-items-holder');
			this.containerElement.appendChild(el);

			return el;
		},

		addWelcomePanel: function(el) {
			el.className += ' mm-infopane-welcome-panel';
			this.itemsHolderElement.appendChild(el);
		},

		removeWelcomePanel: function(el) {
			this.jItemHolder.find('.mm-infopane-welcome-panel').remove();
		},

		addMovingObjectItem: function() {
			var v = new mobmap.LayerListViewMovingObjectItem();
			this.appendViewItemElement(v);
			return v;
		},

		addGridItem: function() {
			var v = new mobmap.LayerListViewGridItem();
			this.appendViewItemElement(v);
			return v;
		},

		appendViewItemElement: function(viewItem) {
			this.removeWelcomePanel();
			
			this.itemList.push(viewItem);
			this.itemsHolderElement.appendChild( viewItem.getBoxElement() );
		},

		removeItemView: function(viewItem) {
			var pos = this.itemList.indexOf(viewItem);
			if (pos >= 0) {
				this.itemList.splice(pos, 1);

				var el = viewItem.getBoxElement();
				if (el.parentNode) {
					el.parentNode.removeChild(el);
				}
			}
		},
		
		resizeView: function() {
			var h = Math.floor( this.jContainerElement.height() );
			this.jItemHolder.height(h - 20);
		},
		
		resizeFlexibleElements: function() {
			for (var i in this.itemList) if (this.itemList.hasOwnProperty(i)) {
				var viewItem = this.itemList[i];
				if (viewItem.resizeFlexibleElements) {
					viewItem.resizeFlexibleElements();
				}
			}
		},

		setSelectedStyleOne: function(layerId) {
			for (var i in this.itemList) if (this.itemList.hasOwnProperty(i)) {
				var viewItem = this.itemList[i];
				var m = viewItem.getModel();
				if (m && m.layerId === layerId) {
					viewItem.setSelectedStyle(true);
				} else {
					viewItem.setSelectedStyle(false);
				}
			}
		},

		getViewOfModel: function(layer) {
			for (var i in this.itemList) if (this.itemList.hasOwnProperty(i)) {
				var viewItem = this.itemList[i];
				var m = viewItem.getModel();
				if (m === layer) {
					return viewItem;
				}
			}
			
			return null;
		},

		turnOffTrajectoryButton: function(exceptLayerId) {
			for (var i in this.itemList) if (this.itemList.hasOwnProperty(i)) {
				var viewItem = this.itemList[i];
				var lyr = viewItem.getModel();
				if (lyr.layerId === exceptLayerId) { continue; }

				var tb = viewItem.getMainToolBar();
				tb.setSelectedStateByname(LayerListView.kToolButtonName_Trajectory, false, true);
			}
		},

		toggleTrajectoryConfigPanel: function(showForThisId) {
			for (var i in this.itemList) if (this.itemList.hasOwnProperty(i)) {
				var viewItem = this.itemList[i];
				var lyr = viewItem.getModel();
				var visible = (lyr.layerId === showForThisId);

				if (viewItem.showTrajectoryConfigurationSection) {
					viewItem.showTrajectoryConfigurationSection(visible);
				}
			}
		},

		swapItems: function(view1, view2) {
			var ls = this.itemList;
			var i1 = ls.indexOf(view1);
			var i2 = ls.indexOf(view2);

			if (i1 >= 0 && i2 >= 0) {
				// Swap inside list
				ls[i2] = view1;
				ls[i1] = view2;

				var j1 = view1.getBoxJElement();
				var j2 = view2.getBoxJElement();
				
				var y1 = j1.offset().top;
				var y2 = j2.offset().top;
				
				var dy2 = y2 - y1;
				var dy1 = (y1 + j1.height()) - (y2 + j2.height());

				// Swap elements
				var box2 = view2.getBoxElement();
				this.itemsHolderElement.removeChild(box2);

				var box1 = view1.getBoxElement();
				this.itemsHolderElement.insertBefore(box2, box1 );
				
				
				box2.style.top = dy2 + 'px';
				j2.animate({top: 0}, 250);
				
				box1.style.top = dy1 + 'px';
				j1.delay(100).animate({top: 0}, 250);
			}
		},
		
		onItemRequestedColorConfig: function(e, senderViewItem) {
			var app = this.getOwnerApp();
			var scr = app.mainUI.ensureColorConfigScreen();
			
			scr.openAndInit();
		}
	};

	// base classes
	mobmap.installBaseMethods(  LayerListView.prototype, mobmap.AppOwnedBase  );

	// Item Base Class =========================================
	
	// Standard tool buttons
	var kLayerToolBarItems = [
		[LayerListView.kToolButtonName_Config    ,   'Open configuration',    'config' , true, 1],
		[LayerListView.kToolButtonName_Visibility,   'Toggle visibility' ,    'eye2'   , true],
		[LayerListView.kToolButtonName_Tail,         'Show tail'         ,    'tail'   , true],
		[LayerListView.kToolButtonName_Trajectory,   'Show all trajectories', 'traj2'  , true],
		[LayerListView.kToolButtonName_SelOnly   ,   'Show selected only',    'vanish2', true]
	];

	LayerListView.REQUIRE_COLOR_CONFIG_EVENT = 'mm-color-config-required';

	LayerListView.ItemBase = {
		initBaseProperties: function() {
			this.model = null;
			this.element = null;
			this.jElement = null;
			
			this.titleElement = null;
			
			this.titleMainElement = null;
			this.jTitleMainElement = null;
			this.titleSubElement = null;
			this.jTitleSubElement = null;
			this.jRemoveButtonImage = null;
			this.jMoveUpButtonImage = null;
			
			this.titleSubTextNode = null;
			this.progressBackElement = null;
			
			this.mainToolBar = null;
			this.selectionToolbar = null;
			this.configurationPanel = null;
			
			if (this.pvInitBaseProperties) {
				this.pvInitBaseProperties();
			}
		},

		generateBoxElement: function(additionalClass, toolbarItemList) {
			var el = $H('div', 'mm-layer-list-item');
			
			this.element = el;
			this.jElement = $(el);
			mmAddEventDispatcherMethod(this, el);

			this.generateTitleArea(el);
			
			if (this.pvGenerateLayerPreviewArea) {
				this.pvGenerateLayerPreviewArea(el);
			}
			
			if (this.generateAdditionalToolBars) {
				this.generateAdditionalToolBars(el);
			}

			this.mainToolBar = this.generateToolbarArea(el, toolbarItemList);
			this.configurationPanel = this.generateConfigurationPanel(el);

			if (additionalClass) {
				this.jElement.addClass(additionalClass);
			}
			return el;
		},

		generateTitleArea: function(parentElement) {
			var t = $H('h2', 'mm-layer-list-title');
			var tmain_outer = $H('div', 'mm-layer-list-title-main-outer');
			var m = $H('span', 'mm-layer-list-title-main');
			var s = $H('span', 'mm-layer-list-title-sub');
			
			this.titleElement     = t;
			this.titleMainElement = m;
			this.titleSubElement  = s;
			this.jTitleMainElement = $(m).text('New layer');
			this.jTitleSubElement  = $(s);
			
			// Inside sub
			this.titleSubTextNode = $T('Unknown type');
			s.appendChild(this.titleSubTextNode);

			this.progressBackElement = $H('span', 'lv-progress-back');
			s.appendChild(this.progressBackElement);

			this.putRemoveLayerButton(tmain_outer);
			this.putMoveUpLayerButton(tmain_outer);
			
			tmain_outer.appendChild(m);
			t.appendChild(tmain_outer);
			t.appendChild(s);
			parentElement.appendChild(t);
		},

		// Buttons on title bar - - - - - -
		putMoveUpLayerButton: function(titleElement) {
			this.jMoveUpButtonImage = mobmap.LVUtility.putTitleBarUpButton(titleElement);
			return this.jMoveUpButtonImage;
		},

		putRemoveLayerButton: function(titleElement) {
			this.jRemoveButtonImage = mobmap.LVUtility.putTitleBarRemoveButton(titleElement);
			return this.jRemoveButtonImage;
		},

		observeRemoveButtonClick: function(handler) {  return this.jRemoveButtonImage.click(handler);  },
		observeMoveUpButtonClick: function(handler) {  return this.jMoveUpButtonImage.click(handler);  },


		generateToolbarArea: function(parentElement, toolbarItemList) {
			var tb = new mobmap.MMToolbar();
			parentElement.appendChild(tb.getElement());
			mobmap.LVUtility.addToolbarButtons(tb, toolbarItemList || kLayerToolBarItems);
			return tb;
		},

		generateConfigurationPanel: function(parentElement) {
			var cp = new mobmap.LayerConfigurationPanel();
			parentElement.appendChild( cp.getElement() );

			if (this.fillConfigurationPanelContent) {
				this.fillConfigurationPanelContent(cp);
			}

			return cp;
		},

		getBoxElement: function() {
			return this.element;
		},

		getBoxJElement: function() {
			return this.jElement;
		},

		setModel: function(m) {
			this.model = m;
			
			if (this.observeTypeSpecificEvents) {
				this.observeTypeSpecificEvents();
			}
		},
		
		getModel: function() {
			return this.model;
		},

		observeItemClick: function(callback) {
			this.jElement.click( callback );
		},

		setTitleText: function(text) {
			this.jTitleMainElement.text(text);
		},

		setTitleSubText: function(text) {
			this.titleSubTextNode.nodeValue = text;
		},

		showLoadingProgress: function() {
			this.setTitleSubText('Loading...');
			this.jTitleSubElement.
			 addClass('mm-loading');
		},

		hideLoadingProgress: function() {
			this.jTitleSubElement.
			 removeClass('mm-loading');
		},

		setLoadingProgressRatio: function(r) {
			var percent = Math.min(Math.floor(r * 100.0 + 0.4), 100);
			this.progressBackElement.style.left = percent + '%';
		},

		getMainToolBar: function() {
			return this.mainToolBar;
		},

		getSelectionToolBar: function() {
			return this.selectionToolbar;
		},

		getConfigurationPanel: function() {
			return this.configurationPanel;
		},
		
		updateConfigurationPanelFromModel: function() {
			if (!this.model) { return; }
			
			var tb = this.getMainToolBar();
			if (tb) {
				tb.setSelectedStateByname(LayerListView.kToolButtonName_Visibility, this.model.getVisibility());
			}
	
			if (this.syncTypeSpecData) {
				this.syncTypeSpecData();
			}

			if (this.pvUpdateLayerPreview) {
				this.pvUpdateLayerPreview();
			}
		},
		
		setSelectedStyle: function(enabled) {
			if (enabled) {
				this.jElement.addClass('selected');
			} else {
				this.jElement.removeClass('selected');
			}
		},

		showCantMoveUpAnimation: function() {
			this.jElement.animate({
				top: '-8px'
			},30).animate({
				top: 0
			},60);
		}
	};


	var kLayerPreviewLightBackground = '#e0dfcf';
	var kLayerPreviewDarkBackground  = '#000';

	LayerListView.ItemWithPreviewBase = {
		pvInitBaseProperties: function() {
			this.layerPreviewElement  = null;
			this.layerPreviewCanvas   = null;
			this.layerPreviewAddInfo  = null;
		},
		
		pvSetDarkBackground: function(enabled) {
			this.layerPreviewCanvas.style.backgroundColor = 
			  enabled ? kLayerPreviewDarkBackground
			          : kLayerPreviewLightBackground ;
		},
		
		pvGenerateLayerPreviewArea: function(containerElement) {
			this.layerPreviewElement = document.createElement('div');
			this.layerPreviewCanvas  = document.createElement('canvas');
			this.layerPreviewCanvas.height = mobmap.LayerListView.kLayerPreviewStandardHeight;
			this.layerPreviewCanvas.style.backgroundColor = kLayerPreviewLightBackground;
			
			this.layerPreviewElement.className = 'mm-layer-preview-box';
			this.layerPreviewElement.appendChild(this.layerPreviewCanvas);
			
			
			this.layerPreviewAddInfo = document.createElement('div');
			this.layerPreviewAddInfo.className = 'mm-layer-preview-box-additional';
			this.layerPreviewElement.appendChild(this.layerPreviewAddInfo);

			containerElement.appendChild(this.layerPreviewElement);
		},

		pvShowAdditionalInfo: function() {
			this.layerPreviewAddInfo.style.display = 'block';
		},

		pvSetAdditionalInfoText: function(tx) {
			this.layerPreviewAddInfo.innerHTML = '';
			this.layerPreviewAddInfo.appendChild( document.createTextNode(tx) );
		},

		pvFitWidth: function(jContainer) {
			var containerWidth = jContainer.width() | 0;
			var cv = this.layerPreviewCanvas;
			
			if (cv) {
				var cw = cv.width | 0;
				if (cw !== containerWidth) {
					cv.width = containerWidth;
					
					if (this.pvUpdateLayerPreview) {
						this.pvUpdateLayerPreview();
					}
					
					return true;
				}
			}
			
			return false;
		}
	};

	// export
	pkg.LayerListView = LayerListView;
});