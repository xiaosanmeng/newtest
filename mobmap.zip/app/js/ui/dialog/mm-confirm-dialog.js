mmDefineModule(function(pkg) {
	'use strict';
	var kButtonNameDataAttr = 'data-bname';
	
	function ConfirmDialog() {
		this.initProperties();
		this.buildView();
	}

	ConfirmDialog.prototype = {
		initProperties: function() {
			this.element = null;
			this.buttonAreaElement = null;
			this.jElement = null;
			this.jMessageArea = null;
			
			this.callbackSetting = null
		},

		buildView: function() {
			// outer
			var el = document.createElement('div');
			el.style.display = "none";
			
			this.element = el;
			this.jElement = $(el);

			// contents
			var msg_area = $H('div', 'mm-confirm-dialog-message');
			this.jMessageArea = $(msg_area).text('Sure?');
			el.appendChild(msg_area);
			
			this.buttonAreaElement = document.createElement('div');
			this.buttonAreaElement.setAttribute('class', 'mm-confirm-dialog-buttons');
			el.appendChild(this.buttonAreaElement);

			this.putButtons(this.buttonAreaElement);

			document.body.appendChild(el);
		},

		putButtons: function(containerElement) {
			var b_cancel = this.putAButton('Cancel', containerElement, 'cancel');
			var b_ok     = this.putAButton('OK', containerElement, 'ok');

			$(b_cancel).click( this.onCancelButton.bind(this) );
			$(b_ok).click( this.onOKButton.bind(this) );
		},

		putAButton: function(text, containerElement, name) {
			var btn = $H('button');
			btn.setAttribute(kButtonNameDataAttr, name)
			btn.appendChild( $T(text) );
			containerElement.appendChild(btn);
			return btn;
		},

		getDialog: function() {
			return this.jElement.data("kendoWindow");
		},

		close: function() {
			this.getDialog().close();
		},

		clearUserData: function() {
			this.callbackSetting = null
		},

		showDialogOnCenter: function(title, messageText, callbackSetting, specified_height) {
			var opt = {
				modal:true,
				pinned: true,
				animation: false
			};
			
			this.jElement.kendoWindow(opt);
			this.jMessageArea.text(messageText);
			
			if (this.beforeOpen) {
				this.beforeOpen();
			}
			
			this.callbackSetting = callbackSetting;
			var dialog = this.getDialog();

			dialog.setOptions({
				title: title,
				width: 288,
				height: specified_height || 72
			});

			dialog.open();
			dialog.center();
		},


		onOKButton: function() {
			this.invokeCallback('ok');
			this.clearUserData();
			this.close();
		},

		onCancelButton: function() {
			this.invokeCallback('cancel');
			this.clearUserData();
			this.close();
		},

		invokeCallback: function(buttonName) {
			if (this.callbackSetting) {
				var cb = this.callbackSetting[buttonName];
				if (cb) {
					cb(this, this.callbackSetting);
				}
			}
		}
	};

	pkg.ConfirmDialog = ConfirmDialog;
});