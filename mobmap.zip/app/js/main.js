var theApp = null;
mmDefineModule(function(pkg) {
	'use strict';

//	var PC_TEST_RELEASE = 9;
	var PC_TEST_RELEASE = true; // enable Route_A2
//	var PC_TEST_RELEASE = false; // ENABLE ALL
	var OCEAN_TEST = false;
	
	var LOAD_TEST_FILE = false&& OCEAN_TEST; //  false; // <<<===
//LOAD_TEST_FILE=true;

	var numPendingPlugins = 0;
	var gmap_ready = false;
	window.mmGmapInitialized = function() { gmap_ready = true; }

	// Entry point for the app =======================
	function main() {
		window.mmSecretParameters = pickSecretParameters();
		waitGoogleMaps();
	}

	// Entry point for plug-ins =======================
	function loadAllPluginScripts() {
		var ls = [
			'jp.ac.u-tokyo.daystrace',
			'jp.ac.u-tokyo.route-analysis-2',
//			'TraceGrid',
			'RouteAnalysis'
			 ,'StationTerritory'
		];
		
		if (PC_TEST_RELEASE) {
			if (PC_TEST_RELEASE === 9) {
				ls = [];
			} else {
				ls = ['jp.ac.u-tokyo.route-analysis-2', 'jp.ac.u-tokyo.g-takeout'  ];
//				ls = ['jp.ac.u-tokyo.route-analysis-2', 'jp.ac.u-tokyo.g-takeout'  ,'jp.ac.u-tokyo.stay-points'];
			}
		}

		if (OCEAN_TEST) {
			ls.push('jp.ac.u-tokyo.ocean');
		}

		numPendingPlugins = ls.length;
		for (var i = 0;i < ls.length;++i) {
			loadPluginScript(ls[i]);
		}
	}
	
	function loadPluginScript(dirName) {
		var s = document.createElement('script');
		s.src = 'plugins/' +dirName+ '/plugin.js';
		document.body.appendChild(s);
	}

	pkg.registerPlugin = function(pluginInfo) {
		var ret = mobmap.PluginHost.getInstance().register(pluginInfo);
		loadPluginStylesheets(pluginInfo.id, pluginInfo.stylesheets);
		loadPluginAdditionalScripts(pluginInfo.id, pluginInfo.scripts);
		
		if (numPendingPlugins > 0) {
			if (--numPendingPlugins < 1) {
				theApp.mainUI.getExtPane().loadPlugins();
			}
		}
		
		return ret;
	};
	
	function loadPluginAdditionalScripts(dirName, fileList) {
		loadAssetInList(fileList, 'script', function(element, filename) {
			element.type = 'text/javascript';
			element.src = 'plugins/' +dirName+ '/' +filename;
		});
	}
	
	function loadPluginStylesheets(dirName, fileList) {
		loadAssetInList(fileList, 'link', function(element, filename) {
			element.rel = 'stylesheet';
			element.href = 'plugins/' +dirName+ '/' +filename;
		});
	}
	
	function loadAssetInList(fileList, tagName, callback) {
		if (fileList) {
			for (var i = 0;i < fileList.length;++i) {
				var item = fileList[i];
				var el = document.createElement(tagName);
				
				callback(el, item);
				
				document.body.appendChild(el);
			}
		}
	}
	
	
	// Initialization of application body ============
	function startApp() {
		console.log("Launching mobmap...");
		mobmap.installMobLayer();
		mobmap.installMeshOverlay();

		var appScreen = new mobmap.Mobmap3PanesScreen(
							'mobmap-panes-view',
							'body-pane',
							'tools-pane'
						);

		hideInitialMessage();
		theApp = new mobmap.Mobmap3App(appScreen);
		observeIncomingMessage();
		mobmap.PluginHost.getInstance().setOwnerApp(theApp);

		theApp.newProject();

if (LOAD_TEST_FILE) {
// TEST**
var testFile = mobmap.createTestMovingDataFile();
theApp.loadMovingDataCSVFile(testFile, {id:0, time:3, x:4, y:5});
}

		loadAllPluginScripts();
		theApp.autoConnect( window.mmSecretParameters );
	}
	
	function hideInitialMessage() {  $('#content-pane').empty();  }
	
	function observeIncomingMessage() {
		window.addEventListener("message", onReceiveMessage, false);
	}
	
	function onReceiveMessage(e) {
		var dat = e.data;
		if (!dat) {return;}

		if (dat.hasOwnProperty('pluginId')) {
			theApp.sendMessageToPlugin(dat.pluginId, dat.command, dat.params);
		} else if (dat.command) {
			var method_name = 'onMessage_' + dat.command;
			if (theApp[method_name]) {
				theApp[method_name](dat.params);
			} else {
				// ignore remote downloader message
				if (dat.command.indexOf('rdl') !== 0) {
					console.log("Message handler not found: " + method_name);
				}
			}
		}
	}
	
	// ===============================================

	function waitGoogleMaps() {
		console.log("Waiting Google Maps API...");
		
		if (gmap_ready) {
			startApp();
			theApp.sendOuterMessage('notifyAppReady', {});
		} else {
			setTimeout(waitGoogleMaps, 50);
		}
	}

	// ===============================================
	// Pick secret parameters(and delete them)
	function pickSecretParameters() {
		var re = /([&?](auto_connect|read_token)=[^&]+)+/ ;
		if (re.test(location.href)) {
			var new_url = location.href.replace(re, '');
			var raw_params = RegExp['$&'];
			var plist = raw_params.split(/[&?]/);
			var dic = makeParamDic(plist);
			
			history.replaceState(null, null, new_url);
			return dic;
		}
		
		return null;
	}
	
	function makeParamDic(list) {
		var res = {};
		for (var i = 0;i < list.length;++i) {
			var s = list[i];
			if (s && s.length > 2 && s.indexOf('=' >= 0)) {
				var fields = s.split('=');
				res[ fields[0] ] = fields[1];
			}
		}
		
		return res;
	}

	// Set entry point
	window.onload = main;
});
