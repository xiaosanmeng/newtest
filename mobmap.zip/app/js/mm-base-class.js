mmDefineModule(function(pkg) {
	'use strict';

	pkg.AppOwnedBase = {
		setOwnerApp: function(app) {
			this._ownerApp = app;
			return app;
		},
		
		getOwnerApp: function() {
			return this._ownerApp;
		}
	};

	pkg.PseudoEventNodeBase = {
		ensurePseudoEventElement: function() {
			if ( !(this._pseudoEventElement) ) {
				this._pseudoEventElement = document.createElement('span');
				this.jEventDispatcherElement = $( this._pseudoEventElement );
			}
		},
		
		setParentEventDispatcher: function(jParent) {
			this.ensurePseudoEventElement();

			// Detach old parent
			if (this._pseudoEventElement.parentNode) {
				this._pseudoEventElement.parentNode.removeChild( this._pseudoEventElement );
			}

			// Attach new parent
			if (jParent) {
				jParent[0].appendChild( this._pseudoEventElement );
			}
		},

		eventDispatcher: function() {
			this.ensurePseudoEventElement();
			return this.jEventDispatcherElement;
		},
		
		fire: function(eventType, arg1) {
			this.eventDispatcher().trigger(eventType, arg1);
		}
	};
	
	pkg.installBaseMethods = function(targetPrototype, baseClass) {
		for (var i in baseClass) if (baseClass.hasOwnProperty(i)) {
			if (i.indexOf('_') === 0) {
				// optional method
				continue;
			}
			
			targetPrototype[i] = baseClass[i];
		}
	}
});