mmDefineModule(function(pkg) {
	'use strict';
	var theInstance = null;
	
	function PluginHost() {
		this.idmap = {};
	}
	
	PluginHost.getInstance = function() {
		if (!theInstance) {
			theInstance = new PluginHost();
		}
		
		return theInstance;
	};
	
	PluginHost.prototype = {
		register: function(info) {
			if (!(info.id)) {
				throw "Plugin information must have id.";
			}
			
			this.idmap[info.id] = info;
			console.log("+Added plugin:", info.id);
			
			return this;
		},

		getById: function(pid) {
			return this.idmap[pid] || null;
		},

		eachPlugin: function(callback) {
			var m = this.idmap;
			for (var i in m) if(m.hasOwnProperty(i)) {
				callback(i, m[i]);
			}
		},
		
		observeAnalysisFeatureWithFilter: function(observer, fn) {
			var E = mobmap.MMSensorPool.Events;
			var app = this.getOwnerApp();
			if (!app) { return false; }

			app.eventDispatcher().
			 bind(E.ItemAdded, fn.bind(this, E.ItemAdded, observer) ).
			 bind(E.ItemRemoved, fn.bind(this, E.ItemRemoved, observer) ).
			 bind(mobmap.MMLandSensor.Events.TitleChanged, fn.bind(this, mobmap.MMLandSensor.Events.TitleChanged, observer) ) ;
			return true;
		},
		
		observeAnalysisFeatureGroup: function(observer) {
			return this.observeAnalysisFeatureWithFilter(observer, 
				this.filterGroupItemEvent);
		},

		observeAnalysisFeatureLineGate: function(observer) {
			return this.observeAnalysisFeatureWithFilter(observer, 
				this.filterLineGateItemEvent);
		},


		observeObjectSelection: function(observer) {
			this.observeWithEventType(mobmap.SelectionPool.CHANGE_EVENT, observer, this.onObjectSelected);
		},

		observeLayerSelection: function(observer) {
			this.observeWithEventType(mobmap.MMProject.Events.LAYER_SELECTED, observer, this.onLayerSelected);
		},

		observeTimeChange: function(observer) {
			this.observeWithEventType(mobmap.DateTime.CURRENT_TIME_CHANGE_EVENT, observer, this.onTimeChange);
		},

		observeWithEventType: function(etype, observer, callback) {
			var app = this.getOwnerApp();
			if (!app) { return false; }
			
			app.eventDispatcher().
			 bind(etype, callback.bind(this, observer));
		},

		getMap: function() {
			var app = this.getOwnerApp();
			if (!app) { return null; }

			var mp = app.getMapPane();
			if (!mp) { return mp; }

			return mp.getGoogleMaps();
		},

		selectObjectIDsInHash: function(layerId, idmap) {
			var app = this.getOwnerApp();
			if (!app) { return false; }

			var pj = app.getCurrentProject();
			if (!pj) { return false; }
			
			var lyr = pj.getLayerList().findById(layerId);
			if (!lyr) { return false; }

			var selp = lyr.getSelectionPool();
			selp.clear(true);
			for (var i in idmap) if (idmap.hasOwnProperty(i)) {
				selp.addId(i, true);
			}
			selp.fireChange();

			return true;
		},

		filterAnalysisItemEvent: function(itemType, eventType, observer, e, arg1, item) {
			if (eventType === mobmap.MMLandSensor.Events.TitleChanged) { item = arg1; }
			if (!item) { return; }
			
			if (item.type !== itemType) { return; }

			if (eventType === mobmap.MMSensorPool.Events.ItemAdded) {
				callbackItemEvent(itemType, observer, 'Added', arg1, item);
			} else if (eventType === mobmap.MMSensorPool.Events.ItemRemoved) {
				callbackItemEvent(itemType, observer, 'Removed', arg1, item);
			} else if (eventType === mobmap.MMLandSensor.Events.TitleChanged) {
				callbackItemEvent(itemType, observer, 'TitleChanged', item);
			}
		},

		filterGroupItemEvent: function(eventType, observer, e, arg1, item) {
			this.filterAnalysisItemEvent(mobmap.LandSensorTypes.Group, eventType, observer, e, arg1, item);
		},

		filterLineGateItemEvent: function(eventType, observer, e, arg1, item) {
			this.filterAnalysisItemEvent(mobmap.LandSensorTypes.LineGate, eventType, observer, e, arg1, item);
		},

		onObjectSelected: function(observer) {
			if (observer.onObjectSelected) {
				observer.onObjectSelected();
			}
		},

		onLayerSelected: function(observer) {
			if (observer.onLayerSelected) {
				observer.onLayerSelected();
			}
		},
		
		onTimeChange: function(observer, e, f) {
			if (observer.onTimeChange) {
				observer.onTimeChange(e, f);
			}
		},

		openReportWindow: function(templateName, templateContentList, pluginId) {
			var app = this.getOwnerApp();
			if (!app) { return false; }

			app.openReportWindow(templateName, templateContentList, pluginId);
		},
		
		eachAnalysisItemGroup: function(proc) {
			return this.eachAnalysisItemWithType(proc, mobmap.LandSensorTypes.Group);
		},

		eachLineGate: function(proc) {
			return this.eachAnalysisItemWithType(proc, mobmap.LandSensorTypes.LineGate);
		},

		eachAnalysisItemWithType: function(proc, itemType) {
			var app = this.getOwnerApp();
			if (!app) { return; }

			var pj = app.getCurrentProject();
			if (!pj) { return; }

			var pool = pj.getLandSensorPool();
			var n = pool.count();
			
			for (var i = 0;i < n;++i) {
				var item = pool.getAt(i);
				if (item.type === itemType) {
					proc(item, i);
				}
			}			
		},


		getGroupFormById: function(groupId) {
			var app = this.getOwnerApp();
			if (!app) { return; }

			var lv = app.getAnalysisListView();
			if (lv) {
				var viewItem = lv.getByItemId(groupId);
				if (viewItem && viewItem.getCurrentFormName) {
					return viewItem.getCurrentFormName();
				}
			}
			
			return null;
		}
	};

	pkg.PluginTypes = {
		AnalysisPanel: 'analysis-panel'
	};

	function callbackItemEvent(itemType, target, suffix, arg1, arg2) {
		var prefix = (itemType === mobmap.LandSensorTypes.Group) ? 'Group' : 'LineGate' ;
		var methodName = 'on' + prefix + suffix;
		
		if (target[methodName]) {
			target[methodName](arg1, arg2);
		}
	}

	// base classes
	mobmap.installBaseMethods(  PluginHost.prototype, mobmap.AppOwnedBase  );

	pkg.PluginHost = PluginHost;
});
