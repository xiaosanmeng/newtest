mmDefineModule(function(pkg) {
	'use strict';
	function DataLoadController() {
		this.loaderScreen = null;
		
		this.pendingLoadData = {
			file: null,
			loader: null,
			layer: null
		};
	}

	DataLoadController.prototype = {
		bindView: function(loaderScreen) {
			this.loaderScreen = loaderScreen;
			loaderScreen.observeFileInputChange( this.onFileInputChange.bind(this));
			
			this.loaderScreen.eventDispatcher().bind(
				mobmap.CSVPreviewScreen.Events.ExecuteButtonClicked,
				this.onLoaderExecuteButtonClick.bind(this)
			).bind(
				mobmap.CSVPreviewScreen.Events.Cancelled,
				this.onLoaderCancelled.bind(this)
			);
		},

		onFileInputChange: function(e) {
			var files = this.loaderScreen.getSelectedFiles();
			if (files && !!(files[0])) {
				this.loaderScreen.show();
				
				this.initLoadData( files[0] );
				this.pendingLoadData.loader.prepare();
			}
		},

		initLoadData: function(sourceFile) {
			var d = this.pendingLoadData;
			var app = this.getOwnerApp();
			
			d.file   = sourceFile;
			d.layer  = app.addNewMovingObjectLayer();
			d.loader = new mobmap.MovingDataCSVLoader(this, sourceFile);
			return d;
		},
		
		csvloaderOnReaderLoadEnd: function() {
			var previewLines = loadPreviewLines(this.pendingLoadData.loader.getBytes(), 10);

			this.loaderScreen.setPreparingMessageVisibility(false);
			this.loaderScreen.fillPreviewTable(previewLines);
			
			// Check header if (not data) row exists - - - - - - - -
			this.loaderScreen.setIgnoreHeaderCheckValue(
				this.checkHeaderRowExists(previewLines)
			);
		},
		
		checkHeaderRowExists: function(lines) {
			var re = /[0-9]+/ ;

			if (lines.length < 1) {
				return false;
			}
			
			var count = 0;
			var fields = lines[0].split(',');
			for (var i in fields) if (fields.hasOwnProperty(i)) {
				if (re.test(fields[i])) {
					++count;
				}
			}
			
			// Data row must contain time, lat, lng (digits)
			if (count < 3) {
				return true;
			}
			
			return false;
		},

		onLoaderExecuteButtonClick: function(e) {
			var skip_header = this.loaderScreen.getIgnoreHeaderCheckValue();
			this.startFullLoad(skip_header, this.loaderScreen);
		},

		startFullLoad: function(skip_header, settingSource) {
			var layer = this.pendingLoadData.layer;
			var loader = this.pendingLoadData.loader;
			
			if (settingSource) {
				this.applyConfiguredColumnMapping(layer, settingSource);
			}
			layer.setLoader(loader);
			loader.setIgnoreFirstLine(skip_header);
			loader.setListener(layer);
			
			layer.startFullLoad();
			this.closeAndCleanup();
		},

		onLoaderCancelled: function(e) {
			var layer = this.pendingLoadData.layer;
			var loader = this.pendingLoadData.loader;

			var app = this.getOwnerApp();
			if (layer && app) {
				var pj = app.getCurrentProject();
				if (pj) {
					pj.getLayerList().removeItem(layer);
				}
			}
			
			this.closeAndCleanup();
		},
		
		applyConfiguredColumnMapping: function(layer, settingSource) {
			var rqList = kRequiredMovingObjectAttributes;
			for (var i = 0;i < rqList.length;++i) {
				var attr = rqList[i];
				var colIndex = settingSource.getColumnIndexOfAttrName(attr.name);
				if (colIndex >= 0) {
					layer.setExistingAttributeColumnIndex(attr.name, colIndex);
				}
			}
			
			settingSource.eachAditionalAttribute(function(columnIndex, nameAndType) {
				layer.addAttribute(nameAndType.name, nameAndType.type, columnIndex);
			});
		},

		closeAndCleanup: function() {
			var d = this.pendingLoadData;
			d.file   = null;
			d.layer  = null;
			d.loader = null;

			if (this.loaderScreen) {
				this.loaderScreen.closeAndCleanup();
			}
		}
	};

	function loadPreviewLines(arrayBuffer, nLines) {
		var i;
		var limit = 99999;
		var lineno = 0;
		
		var lineList = [];
		var charBuf = [];

		for (i = 0;i < limit;++i) {
			var k = arrayBuffer[i];
			if (k === 0x0A || k === 0x0D) {
				// Ignore next CR/LF
				var k2 = arrayBuffer[i+1] || 0;
				if (k2 === 0x0A || k2 === 0x0D) {
					++i;
				}
				
				// Add line as string and clear buffer
				lineList.push( mobmap.utf8bytesToString(charBuf) );
				charBuf.length = 0;

				if (++lineno >= nLines) {break;}
			} else {
				charBuf.push(k);
			}
		}
		
		return lineList;
	}

	// base classes
	mobmap.installBaseMethods(  DataLoadController.prototype, mobmap.AppOwnedBase  );

	pkg.DataLoadController = DataLoadController;
});