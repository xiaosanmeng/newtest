mmDefineModule(function(pkg) {
	'use strict';
	function GridDataLoadController(fileFormWrapper) {
		this.fileFormWrapper = fileFormWrapper;
		this.pendingLoadData = {
			file: null,
			loader: null,
			layer: null
		};
		
		fileFormWrapper.observeFileInputChange( this.onFileInputChange.bind(this) );
	}
	
	GridDataLoadController.prototype = {
		openFileDialog: function() {
			this.fileFormWrapper.renewFileInput();
			this.fileFormWrapper.openFileDialog();
		},
		
		onFileInputChange: function() {
			var files = this.fileFormWrapper.getSelectedFiles();
			if (files) {
				var f = files[0];
				if (f) {
					this.initLoadData(f);
					
					this.pendingLoadData.loader.prepare();
				}
			}
		},

		initLoadData: function(sourceFile) {
			var d = this.pendingLoadData;
			var app = this.getOwnerApp();
			var layer = app.addNewGridLayer();

			d.layer = layer;
			d.loader = new mobmap.GridCSVLoader(layer, sourceFile);

			layer.setLoader(d.loader);
			return d;
		}
	};

	// base classes
	mobmap.installBaseMethods(  GridDataLoadController.prototype, mobmap.AppOwnedBase  );

	pkg.GridDataLoadController = GridDataLoadController;
});