mmDefineModule(function(pkg) {
	'use strict';
	
	// quick qccess
	var kDIR_FWD  = 1;
	var kDIR_BACK = 2;

	function GateOperationjob(targetMovingData, gateSensor) {
		this.targetMovingData = targetMovingData;
		this.gate = gateSensor;
		this.directionEnabled = this.getDefaultDirectionOption(gateSensor.type);
		this.tester = this.selectTester(gateSensor.type);

		this.idList = this.buildTargetIdList(targetMovingData);
		this.entireIdDount = this.idList.length;
		this.doNextClosure = this.doNext.bind(this);

		this.chunkSize = 150;
		this.thenFunc = null;
		this.userData1 = null;

		this.resultBuffer = [];
		this.targetLayerId = null;
		
		this.partIndex  = null;
		this.partsCount = null;
	}
	
	GateOperationjob.Event = {
		WillStart: 'mm-gatejob-event-willstart',
		Progress:  'mm-gatejob-event-progress',
		Finish:    'mm-gatejob-event-finish'
	};
	
	GateOperationjob.prototype = {
		getSensorId: function() {
			return this.gate.seqId;
		},

		setTargetLayerId: function(layerId) {
			this.targetLayerId = layerId;
		},
		getTargetLayerId: function() {
			return this.targetLayerId;
		},

		buildTargetIdList: function(movData) {
			var result_list = [];

			var m = movData.getIdMap();
			// push IDs to list
			for (var i in m) {
				if (Object.prototype.hasOwnProperty.call(m, i)) {
					result_list.push(i);
				}
			}
			
			return result_list;
		},

		start: function() {
			this.fire(GateOperationjob.Event.WillStart, this);

			if (this.tester) {
				window.setTimeout(this.doNextClosure, 1);
			}
		},

		resolve: function() {
			this.fire(GateOperationjob.Event.Finish, this);

			if (this.thenFunc) {
				this.thenFunc();
			}
			
			this.eventDispatcher().off();
		},
		
		then: function(f) {
			this.thenFunc = f;
		},

		doNext: function() {
			var mdat = this.targetMovingData;
			var hasMore = false;
			var dir = 0;
			
			if (this.directionEnabled) {
				dir = this.gate.getDirection();
			}

			var i;
			for (i = 0;i < this.chunkSize;++i) {
				if (this.idList.length < 1) { break; }

				var pid = this.idList.shift();
				var tl = mdat.getTimeListOfId(pid);

				this.testPointsInRecordList(tl, this.gate, pid);

				if (tl.hasMoreTwoEnds()) {
					this.testEdgesInRecordList(tl, this.gate, pid, dir);
				} 
			}
			
			this.fire(GateOperationjob.Event.Progress, [this, 1.0 - (this.idList.length / this.entireIdDount)]);
			
			if (this.idList.length > 0) {
				hasMore = true;
			}

			if (hasMore) {
				window.setTimeout(this.doNextClosure, 1);
			} else {
				this.resolve();
			}
		},
		
		testEdgesInRecordList: function(tl, gate, callbackParam, dirFilter) {
			var nTrjVertices = tl.countTrajectoryVertices();
			var nSegments = nTrjVertices - 1;
			for (var i = 0;i < nSegments;++i) {
				var r1 = tl.getTrajectoryVertexAt(i  , tempRec1, null);
				var r2 = tl.getTrajectoryVertexAt(i+1, tempRec2, null);
				
				this.tester.checkBetweenRecords(this, this.gate, r1, r2, i, callbackParam, dirFilter);
			}
			
		},
		
		testPointsInRecordList: function(tl, gate, callbackParam) {
			var nTrjVertices = tl.countTrajectoryVertices();
			for (var i = 0;i < nTrjVertices;++i) {
				var lastResult = null;
				if (this.resultBuffer.length > 0) {
					lastResult = this.resultBuffer[ this.resultBuffer.length - 1 ];
				}


				var r1 = tl.getTrajectoryVertexAt(i, tempRec1, null);
				this.tester.checkSingleRecord(this, this.gate, r1, i, callbackParam, lastResult);
			}
		},
		
		selectTester: function(sensorType) {
			switch(sensorType) {
			case mobmap.LandSensorTypes.LineGate:
				return LineGateTester;
				break;

			case mobmap.LandSensorTypes.PolygonGate:
				return PolygonGateTester;
				break;
			}
			
			return null;
		},

		getDefaultDirectionOption: function(sensorType) {
			return (sensorType === mobmap.LandSensorTypes.LineGate);
		},

		notifyGateTestResult: function(reportParam, callbackParam) {
			//console.dir(reportParam);
			this.resultBuffer.push(reportParam);
		},
		
		getResultBuffer: function() {
			return this.resultBuffer;
		}
	};

	var GateResultType = {
		LineGatePassed: 'line-gate-passed',
		PolygonGateEdgePassed: 'polygon-gate-edge-passed',
		PolygonGateInOutChanged: 'polygon-gate-in-out-changed'
	};

	var LineGateTester = {
		checkBetweenRecords: function(receiver, gate, rec1, rec2, r1Index, callbackParam, dirFilter) {
			var n = gate.getVertexCount();
			if (n < 2) { return false; }
			var g1 = gate.getVertexAt(0);
			var g2 = gate.getVertexAt(1);

			var cross_res = testSegmentCross(g1.lng, g1.lat, g2.lng, g2.lat, rec1.x, rec1.y, rec2.x, rec2.y, true, tempCrossDetail);
			//console.log(g1.lng, g1.lat, g2.lng, g2.lat,"\n", rec1.x, rec1.y, rec2.x, rec2.y);
			if (cross_res !== null) {
				
				// direction filtering
				if (dirFilter === kDIR_FWD  && cross_res < 0) { return false; }
				if (dirFilter === kDIR_BACK && cross_res > 0) { return false; }
				
				if (receiver) {
					receiver.notifyGateTestResult(
						{
							type: GateResultType.LineGatePassed,
							gate: gate,
							userParam: callbackParam,
							firstRecordIndex: r1Index,
							firstRecord: rec1,
							secondRecord: rec2,
							ratio: tempCrossDetail.midPosition,
							direction: cross_res
						},
						callbackParam
					);
				}
			}
		},

		checkSingleRecord: function(receiver, gate, rec1, r1Index, callbackParam, lastResult) {
			return false;
		}
	};
	
	var PolygonGateTester = {
		checkBetweenRecords: function(receiver, gate, rec1, rec2, r1Index, callbackParam) {
			var n = gate.getVertexCount();
			if (n < 2) { return false; }
			
			// Test edges
			
			var nEdges = n;
			for (var i = 0;i < nEdges;++i) {
				var g1 = gate.getVertexAt(i             );
				var g2 = gate.getVertexAt((i+1) % nEdges);

				var cross_res = testSegmentCross(g1.lng, g1.lat, g2.lng, g2.lat, rec1.x, rec1.y, rec2.x, rec2.y, true, tempCrossDetail);
				if (cross_res !== null) {
					if (receiver) {
						receiver.notifyGateTestResult(
							{
								type: GateResultType.PolygonGateEdgePassed,
								gate: gate,
								userParam: callbackParam,
								firstRecordIndex: r1Index,
								firstRecord: rec1,
								secondRecord: rec2,
								ratio: tempCrossDetail.midPosition,
								direction: cross_res
							},
							callbackParam
						);
					}
				}
			}
			
		},

		checkSingleRecord: function(receiver, gate, rec1, r1Index, callbackParam, lastResult) {
			var g_polygon = gate.getGoogleMapsGeometory();
			if (g_polygon && receiver) {
				var is_inside = google.maps.geometry.poly.containsLocation(new google.maps.LatLng(rec1.y, rec1.x), g_polygon);
				var should_ignore = false;
				if (lastResult) {
					if (lastResult.type == GateResultType.PolygonGateInOutChanged &&
						lastResult.firstRecord.id === rec1.id &&
						lastResult.inside === is_inside) {
						should_ignore = true;
					}
				}
				
				if (!should_ignore) {
					receiver.notifyGateTestResult({
						type: GateResultType.PolygonGateInOutChanged,
						gate: gate,
						userParam: callbackParam,
						firstRecordIndex: r1Index,
						firstRecord: rec1,
						inside: is_inside
					}, callbackParam);
				}
			}
		}
	};

	var tempRec1 = mobmap.MovingData.createEmptyRecord();
	var tempRec2 = mobmap.MovingData.createEmptyRecord();
	var tempCrossDetail = {midPosition: 0};

	pkg.calcPassedTimeFromGateResult = function(resultEntry) {
		var r1 = resultEntry.firstRecord;
		var r2 = resultEntry.secondRecord;

		var t = (1.0 - resultEntry.ratio) * r1.time  +  resultEntry.ratio * r2.time;
		var date = new Date( t * 1000.0 );
		return date;
	};

	// base classes
	mobmap.installBaseMethods(  GateOperationjob.prototype, mobmap.PseudoEventNodeBase  );

	pkg.GateResultType   = GateResultType;
	pkg.GateOperationjob = GateOperationjob;
});