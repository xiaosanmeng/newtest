mmDefineModule(function(pkg) {
	'use strict';

	function AutoplayController() {
		this.dateTime = null;
		this.playctrlUI = null;

		this.frameDuration = 16;
		this.currentPlaySpeed = 0;
		this.previousRenderedTime = -1;
		this.animationClosure = this.doAnimation.bind(this);
		
		this.speedPreset = mobmap.PlayerController.TestPreset;
		this.selectedSpeedFactor = this.speedPreset[4];
		
		this.validTimeRange = {
			min:0,max:0
		};
	}

	AutoplayController.prototype = {
		observeGlobalEvents: function(ed) {
			ed.bind( mobmap.LayerEvent.DataTimeRangeChange, this.onDataTimeRangeChange.bind(this) );
		},

		onDataTimeRangeChange: function(e) {
			var app = this.getOwnerApp();
			if (app) {
				var pj = app.getCurrentProject();
				if (pj) {
					this.validTimeRange.min = pj.calcMinTimeAmongAllLayers();
					this.validTimeRange.max = pj.calcMaxTimeAmongAllLayers();
				}
			}
		},

		setDateTimeModel: function(m) {
			this.dateTime = m;
		},

		setPlayControllerUI: function(pc) {
			this.playctrlUI = pc;
			this.observePlayControllerUIEvents(pc);
			
			this.updateSpeedFromUI();
		},

		setPlaySpeed: function(speed_x) {
			var should_start = (this.currentPlaySpeed === 0);
			
			if (this.currentPlaySpeed !== speed_x) {
				this.currentPlaySpeed = speed_x;
				
				if (speed_x == 0) {
					should_start = false;
				}
			}

			if (should_start) {
				this.launchAnimation();
			}
		},

		stop: function() {
			this.setPlaySpeed(0);
			this.playctrlUI.setPlayButtonSelected(false);
		},

		forceRewind: function() {
			if (this.dateTime) {
				this.dateTime.setCurrentTime( this.validTimeRange.min );
			}
		},

		launchAnimation: function() {
			this.previousRenderedTime = getTick();
			this.doAnimation();
		},
		
		doAnimation: function() {
			var need_next = true;
			
			var t = getTick();
			var dt = t - this.previousRenderedTime;
			this.previousRenderedTime = t;
			
			var shiftTime = dt * this.currentPlaySpeed;
			if (this.dateTime) {
				this.dateTime.shiftTime(shiftTime / 1000.0);
				
				if (this.dateTime.capMax( this.validTimeRange.max )) {
					this.stop();
				}
			}


			if (this.currentPlaySpeed === 0) {
				need_next = false; // STOP
			}

			if (need_next) {
				window.requestAnimationFrame( this.animationClosure );
			}
		},


		observePlayControllerUIEvents: function(pc) {
			var E = mobmap.PlayerController.Event;
			pc.eventDispatcher().bind( E.PlayButtonClick , this.onPlayButtonClick.bind(this) ).
			                     bind( E.StopButtonClick , this.onStopButtonClick.bind(this) ).
			                     bind( E.LiveButtonClick , this.onLiveButtonClick.bind(this) ).
			                     bind( E.SpeedChange     , this.onUISpeedChange.bind(this) );
		},

		onLiveButtonClick: function(e) {
			this.adjustTimeForLive();
			this.playctrlUI.forceSetSpeed(1);
			this.play();
		},

		onPlayButtonClick: function(e) {
			this.play();
		},

		play: function() {
			this.setPlaySpeed(this.selectedSpeedFactor);
			this.playctrlUI.setPlayButtonSelected(true);
		},

		onStopButtonClick: function(e) {
			if (this.currentPlaySpeed === 0) {
				this.forceRewind();
			} else {
				this.stop();
			}
		},
		
		onUISpeedChange: function(e) {
			this.updateSpeedFromUI();
		},
		
		
		updateSpeedFromUI: function() {
			this.selectedSpeedFactor = this.playctrlUI.getPresetMappedValue();
			if (this.currentPlaySpeed !== 0) {
				this.setPlaySpeed(this.selectedSpeedFactor);
			}

			this.playctrlUI.showSpeed(this.selectedSpeedFactor);
		},
		
		// Configure LIVE mode
		adjustTimeForLive: function() {
			var targetLayer = this.findLiveTargetLayer();
			if (targetLayer) {
				var bufferTime = 120;
				var liveData = targetLayer.getLiveModeData();
				if (liveData && liveData.bufferTime) {
					bufferTime = liveData.bufferTime;
				}
				//console.log("****",bufferTime);
				
				var t = targetLayer.dataTimeRange.max - bufferTime;

				var pj = this.getOwnerApp().getCurrentProject();
				pj.currentDateTime.setCurrentTime(t);
			}
		},

		findLiveTargetLayer: function() {
			var selectedLayer = this.getSelectedLayer();

			if ( !selectedLayer ) {
				var ls = this.getLayerList();
				var n = ls.count();
				for (var i = 0;i < n;++i) {
					var lyr = ls.getAt(i);
					if (lyr.getLiveModeData && lyr.getLiveModeData()) {
						return lyr;
					}
				}
			}

			return selectedLayer;
		},
		
		getSelectedLayer: function() {
			var app = this.getOwnerApp();
			if (app) {
				var pj = app.getCurrentProject();
				if (pj) {
					var id = pj.lyrselGetFirstId();
					if (id !== null) {
						return pj.getLayerList().findById(id);
					}
				}
			}

			return null;
		},

		getLayerList: function() {
			var app = this.getOwnerApp();
			if (app) {
				var pj = app.getCurrentProject();
				if (pj) {
					return pj.getLayerList();
				}
			}
		}
	};

	function getTick() { return (new Date()) - 0; }

	// base classes
	mobmap.installBaseMethods(  AutoplayController.prototype, mobmap.AppOwnedBase  );

	pkg.AutoplayController = AutoplayController;
});