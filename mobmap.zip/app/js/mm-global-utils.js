(function(aGlobal) {
	// Ensure package object under the global object
	aGlobal.mmEnsureGlobalPackage = function(packageName) {
		if (!aGlobal[packageName]) {
			aGlobal[packageName] = {};
		}
		
		return aGlobal[packageName];
	};
	
	// Shorthand for mmEnsureGlobalPackage('mobmap')
	aGlobal.mmEnsureMobmapPackage = function() {
		return mmEnsureGlobalPackage('mobmap');
	};
	
	aGlobal.mmDefineModule = function(body) {
		var mobmapPackage = mmEnsureMobmapPackage();
		body(mobmapPackage);
	};


	aGlobal.createCleanHash = function() {
		var o = {__proto__:null};
		delete o.__proto__;

		return o;
	};

	aGlobal.findAttributeTypeFromName = function(name) {
		var t = AttributeTypeNameMap[name];
		if (t === 0 || t) {
			return t;
		}
		
		return AttributeType.STRING;
	};

	// Color
	aGlobal.MMColor = function(r,g,b,a) {
		this.r = r || 0;
		this.g = g || 0;
		this.b = b || 0;
		this.a = (a || a===0) ? a : 255;
		this.stop = 0; // for gradient stop
	};

	aGlobal.MMColor.fromCSS = function(s) {
		if (s.indexOf('#') >= 0) {
			s = s.replace('#', '');
		}
		
		if (s.length === 6) {
			return new MMColor(
				MMColor.parseHex2(s, 0),
				MMColor.parseHex2(s, 2),
				MMColor.parseHex2(s, 4)
			);
		} else if (s.length === 3) {
			return new MMColor(
				MMColor.parseHex1(s, 0),
				MMColor.parseHex1(s, 1),
				MMColor.parseHex1(s, 2)
			);
		} else {
			throw "Can't' parse color!";
		}
	};

	aGlobal.MMColor.parseHex1 = function(s, pos) {
		return parseInt( s.charAt(pos), 16) * 17; // 0 - 255 (0xf * 17)
	};

	aGlobal.MMColor.parseHex2 = function(s, pos) {
		return parseInt( s.charAt(pos) + s.charAt(pos+1) , 16);
	};
	
	aGlobal.MMColor.prototype = {
		toCSSRGBA: function() {
			return 'rgba('+ this.r +','+ this.g +','+ this.b +','+ (this.a / 255.0) +')';
		},

		copyFrom: function(src) {
			this.r = src.r;
			this.g = src.g;
			this.b = src.b;
			this.a = src.a;
		},
		
		addRGB: function(dR, dG, dB) {
			this.r += dR;
			this.g += dG;
			this.b += dB;

			this.r = Math.min(255, Math.max(0, this.r));
			this.g = Math.min(255, Math.max(0, this.g));
			this.b = Math.min(255, Math.max(0, this.b));
		},
		
		blendRGB: function(r, g, b, factor) {
			var _f = 1.0 - factor;
			
			this.r = Math.floor(this.r * _f  +  r * factor);
			this.g = Math.floor(this.g * _f  +  g * factor);
			this.b = Math.floor(this.b * _f  +  b * factor);
			
			this.r = Math.min(255, Math.max(0, this.r));
			this.g = Math.min(255, Math.max(0, this.g));
			this.b = Math.min(255, Math.max(0, this.b));
		},
		
		equalsRGBA: function(c) {
			return this.r === c.r && this.g === c.g && this.b === c.b && this.a === c.a;
		}
	};

	aGlobal.hsvToRGB = function(aHSV) {
		var hue = aHSV[0] % 360;
		var sat = aHSV[1];
		var v = aHSV[2];
		var r, g, b;
		
		var h = hue / 60.0;
		var i = Math.floor(h);
		var f = h - i;
		var p = v * (1.0 - sat);
		var q = (i%2) ? v * (1.0 - f * sat) : v * (1.0 - (1.0 - f) * sat);
		
		switch(i) {
		case 0:
	 		r = v;
			g = q;
			b = p;
			break;
		case 1:
 			r = q;
			g = v;
			b = p;
			break;
		case 2:
			r = p;
			g = v;
			b = q;
			break;
		case 3:
			r = p;
			g = q;
			b = v;
			break;
		case 4:
			r = q;
			g = p;
			b = v;
			break;
		case 5:
			r = v;
			g = p;
			b = q;
			break;
		}
		
		aHSV[0] = Math.floor(r * 255);
		aHSV[1] = Math.floor(g * 255);
		aHSV[2] = Math.floor(b * 255);
	};


	aGlobal.mmAddEventDispatcherMethod = function(target, element) {
		target.jEventDispatcherElement = $(element);
		target.eventDispatcher = (function() {
			return this.jEventDispatcherElement;
		}).bind(target);
		
		if (!target.fire) {
			target.fire = (function(eventType, arg1) {
				this.eventDispatcher().trigger(eventType, arg1);
			}).bind(target);
		}
	};

	aGlobal.isNumbersNear = function(a, b) {
		var d = a - b;
		return (d > -0.000001 && d < 0.000001);
	};
	
	aGlobal.deleteAllProperties = function(h) {
		for (var i in h) if (h.hasOwnProperty(i)) {
			delete h[i];
		}
	};

	aGlobal.absoluteTimeToPrettyString = function(t) {
		var _2 = aGlobal.padding_02;
		if (t < 315360000) {
			var hr  = Math.floor(t / 3600);
			var min = Math.floor(t / 60) % 60;
			var sec = t % 60;
			
			return _2(hr) +':'+ _2(min) +':'+ _2(sec);
		} else {
			var dt = new Date(t * 1000);
			return dt.getFullYear() +'-'+ _2(dt.getMonth()+1) +'-'+ _2(dt.getDate()) +' '+
			       _2(dt.getHours()) +':'+ _2(dt.getMinutes()) +':'+ _2(dt.getSeconds());
		}
	};
	
	aGlobal.padding_02 = function(v) {
		if (v < 10) {  return '0' + v; }
		return v.toString();
	};

	// $ shorthands
	
	aGlobal.$px = function(px) { return Math.floor(px) + 'px'; };
	
	aGlobal.$H = function(tag, cls, id) {
		var el = document.createElement(tag);

		if (cls) {
			el.setAttribute("class", cls);
		}

		if (id) {
			el.id = id;
		}
		
		return el;
	};

	aGlobal.$T = function(s) {
		return document.createTextNode(s);
	};
	
	// ====== Color utilities ======
	aGlobal.makeStyleSheetRGB_BlendBlack = function(r, g, b) {
		return aGlobal.makeStyleSheetRGB(r >> 1, g >> 1, b >> 1);
	};
	
	aGlobal.makeStyleSheetRGB = function(r, g, b) {
		return 'rgb(' +r+ ',' +g+ ',' +b+ ')';
	};

	aGlobal.makeStyleSheetRGBA = function(r, g, b, a) {
		return 'rgba(' +r+ ',' +g+ ',' +b+ ',' +a+ ')';
	};
	// ==============================
	

	var _tmpPt1 = {x:0,y:0};
	aGlobal.convertGMapScreenCoordToLatLng = function(gmap, x, y, outLL) {
		var pj = gmap.getProjection();
		var mapBounds = gmap.getBounds();
		var SW = mapBounds.getSouthWest();
		var NE = mapBounds.getNorthEast();

		var pSW = pj.fromLatLngToPoint(SW);
		var pNE = pj.fromLatLngToPoint(NE);
		var entireSize = Math.pow(2, gmap.getZoom());

		var x1 = pSW.x * entireSize; // omits  /256 *256
		var y1 = pNE.y * entireSize;

		var px = x1 + x;
		var py = y1 + y;

		_tmpPt1.x = px / entireSize;
		_tmpPt1.y = py / entireSize;
		var ll = pj.fromPointToLatLng(_tmpPt1);
		
		outLL.lat = ll.lat();
		outLL.lng = ll.lng();
		return outLL;
	};

	aGlobal.MMLatLng = function(lat, lng) {
		this.lat = lat || 0;
		this.lng = lng || 0;
	};
	
	aGlobal.generateInputWithLabel = function(options) {
		var label = $H('label', options.labelClass);
		var input = $H('input', options.inputClass);
		var t = $T(options.text);
		if (options.type) {
			input.setAttribute('type', options.type);
		}
		
		if (options.reverse) {
			label.appendChild(input);
			label.appendChild(t);
		} else {
			label.appendChild(t);
			label.appendChild(input);
		}
		
		if (options.container) {
			options.container.appendChild(label);
		}

		return {label: label, input:input};
	};
	
	aGlobal.calcDistanceFromLatLng = function(x1, y1, x2, y2) {
		var DEG2RAD = Math.PI / 180.0;
		x1 *= DEG2RAD;
		y1 *= DEG2RAD;
		x2 *= DEG2RAD;
		y2 *= DEG2RAD;
		var dx = Math.abs(x2-x1);
		var dy = Math.abs(y2-y1);
		var phi = dy*0.5 + y1;

		var S = Math.sin(phi);
		var M = 6335439.0 / (Math.sqrt( Math.pow( (1- 0.006674*S*S) , 3) ));
		var N = 6378137.0 / Math.sqrt( 1- 0.006674*S*S );

		return Math.sqrt( Math.pow(M*dy, 2) + Math.pow(N*Math.cos(phi)*dx ,2) );
	};
	
	aGlobal.testSegmentCross = (function() {
		function matchDir(x1, y1, x2, y2, x3, y3, x4, y4, timeDir) {
			// Rotate x/y
			var dx1 = -(y2 - y1);
			var dy1 = x2 - x1;

			var dx2 = x4 - x3;
			var dy2 = y4 - y3;

			var dp = dx1 * dx2 + dy1 * dy2;
			if (!timeDir) { dp = -dp; }

			return dp;
		}


		//                             Gate           | Traj
		function calcPtLineRelDistance(x3, y3, x4, y4,  x1, y1, x2, y2) {
			//                  |Gate vector
			// Point vec.       |
			// .________________* <- x3,y3 
			// x1,y1                  
			
			var xP  = x1 - x3;
			var yP  = y1 - y3;
			var xP2 = x2 - x3;
			var yP2 = y2 - y3;
			
			var xG = x4 - x3;
			var yG = y4 - y3;
			
			// Cross product indicates area of the parallelogram
			var CP  = xP  * yG - yP * xG;
			var CP2 = xP2 * yG - yP2 * xG;

			var blen = Math.sqrt(xG*xG + yG*yG);
			// ... and the height is (area / bottom length)
			var A1 = Math.abs(CP  / blen);
			var A2 = Math.abs(CP2 / blen);
			
			return A1 / (A1+A2);
		}
		
		// parameters:
		//            x3,y3
		//             |
		//  x1,y1 -----+----- x2,y2
		//             |
		//             |
		//            x4,y4
		return function (x1, y1, x2, y2, x3, y3, x4, y4, timeDir, detailOut) {
		//console.log(x1, y1, x2, y2, x3, y3, x4, y4)
			if (
					((x1 - x2) * (y3 - y1) + (y1 - y2) * (x1 - x3)) *
					((x1 - x2) * (y4 - y1) + (y1 - y2) * (x1 - x4)) <= 0
				) {

				if (
						((x3 - x4) * (y1 - y3) + (y3 - y4) * (x3 - x1)) *
		            	((x3 - x4) * (y2 - y3) + (y3 - y4) * (x3 - x2)) <= 0
				) {
					if (detailOut) {
						// Detail information for cross point is required.
						
						detailOut.midPosition = calcPtLineRelDistance(x1, y1, x2, y2, x3, y3, x4, y4);
					}
					
					return matchDir(x1, y1, x2, y2, x3, y3, x4, y4, timeDir);
				}
			}

			return null;
		} ;
	})();

})(window);