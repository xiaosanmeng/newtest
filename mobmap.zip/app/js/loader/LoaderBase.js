mmDefineModule(function(pkg) {
	'use strict';

	var LINE_ERR = -1;
	var DELM = 0x2c;
	var temp_chars = [];
	var temp_fields = [];

	pkg.LoaderBase = {
		initBaseProperties: function(listener, inputFile) {
			this.cachedLineCount = -1;
			this.rerunCount = 0;
			this.listener = listener;
			this.inputFile = inputFile;
			this.inputBytes = null;

			this.ignoreFirstLineEnabled = false;
			this.advanceClosure = this.advance.bind(this);

			this.alternativeReader = null;


			this.loadJob = {
				prefetchPos: 0,
				currentPos: 0,
				step: 5000,
				lineno: 0
			};
		},
		
		setFixedLineCount: function(n) {
			this.cachedLineCount = n;
		},
		
		setAlternativeReader: function(r) {
			this.alternativeReader = r;
		},

		setIgnoreFirstLine: function(b) {
			this.ignoreFirstLineEnabled = b;
		},

		setListener: function(listener) {
			this.listener = listener;
		},
		
		getBytes: function() {
			return this.inputBytes;
		},

		getSourceDescription: function() {
			if (this.inputFile.name) {
				return this.inputFile.name;
			} else {
				return 'Unknown blob';
			}
		},

		prepare: function() {
			var reader = new FileReader();
			reader.onloadend = this.onReaderLoadEnd.bind(this);
			reader.onerror   = this.onReaderPreloadError.bind(this);
			
			reader.readAsArrayBuffer(this.inputFile);
		},

		onReaderLoadEnd: function(e) {
			var abuf = e.target.result;
			this.setSourceUint8Array( new Uint8Array(abuf, 0) );
		},

		setSourceUint8Array: function(a) {
			this.inputBytes = a;

			if (this.listener && this.listener.csvloaderOnReaderLoadEnd) {
				this.listener.csvloaderOnReaderLoadEnd(this);
			}
		},

		onReaderPreloadError: function(e) {
			console.log("******ERROR******", e);
		},

		countLines: function() {
			if (this.cachedLineCount >= 0) {
				return this.cachedLineCount;
			}
			
			var buf = this.inputBytes;
			var len = buf.length;
			var lc = 0;
			
			for (var i = 0;i < len;i++) {
				if (buf[i] === 0x0a) {
					++lc;
				} else {
					// last line?
					if (i === (len - 1) && i > 1) {
						if (buf[i  ] !== 0x0a && buf[i  ] !== 0x0d && 
							buf[i-1] !== 0x0a && buf[i-1] !== 0x0d) {
							++lc;
						}
					}
				}
			}

			this.cachedLineCount = lc;
			return this.cachedLineCount;
		},


		advance: function(fullMode) {
			var i;
			var limit = this.loadJob.step;
			if (limit > 10 && !fullMode) {limit=10;}

			for (i = 0;i < limit;i++) {
				var hasMore = this.readLine();
				if (!hasMore || hasMore === LINE_ERR) {break;}
			}

			if (hasMore === LINE_ERR) { return;}

			if (this.listener.csvloaderReportProgress) {
				this.listener.csvloaderReportProgress(this, this.loadJob.lineno);
			}

			if (hasMore && fullMode) {
				var intv_ms = ((++this.rerunCount % 25) === 0) ? 80 : 1;
				setTimeout(this.advanceClosure, intv_ms, fullMode);
			} else {
				this.listener.csvloaderLoadFinish(this);
			}
		},

		readLine: function() {
			var buf = null;
			var eofPos = 0;
			var needMore = false;

			if (this.alternativeReader) {
				// skip
			} else {
				buf = this.inputBytes;
				eofPos = buf.length - 1;
			}

			var pos = this.loadJob.currentPos;
			var k;

			temp_fields.length = 0;
			temp_chars.length = 0;
			
			if (this.alternativeReader) {
				// Read from alternative reader
				var alt_err = this.alternativeReader.getError(this.inputFile);
				if (alt_err && this.listener && this.listener.csvloaderLineError) {
					this.listener.csvloaderLineError(alt_err);
					return LINE_ERR;
				}

				needMore = this.alternativeReader.readLine(temp_fields, this.inputFile, this.loadJob);
			} else {
				// Read from internal buffer
				for (;pos <= eofPos;++pos) {
					k = buf[pos];

					if (k === DELM || k === 0x0a || k === 0x0d || pos === eofPos) {
						if (pos === eofPos) {
							if (k !== 0x0a && k !== 0x0d) {
								temp_chars.push(k);
							}
						}

						temp_fields.push(pkg.utf8bytesToString(temp_chars));
						temp_chars.length = 0;
					} else {
						temp_chars.push(k);
					}


					if (k === 0x0a || k === 0x0d || pos === eofPos) {
						++this.loadJob.lineno;
						break;
					}
				}

				// CRLF
				k = buf[pos+1];
				if (k === 0x0a || k === 0x0d) { ++pos; }
				this.loadJob.currentPos = ++pos;


				needMore = (pos <= eofPos);
			}
			
			var listener = this.listener;
//			console.log(pos);
			try {
				if (this.ignoreFirstLineEnabled && this.loadJob.lineno === 1) {
					// Ignored line
					if (listener.csvloaderReadIgnoredLine) {
						listener.csvloaderReadIgnoredLine(temp_fields, this.loadJob.lineno-1)
					}
				} else {
					if (temp_fields.length > 1 || (temp_fields[0] && temp_fields[0].indexOf('@') >= 0)) { // ignore empty line
						listener.csvloaderReadLine(this, temp_fields, this.loadJob.lineno-1);
					}
				}
			} catch(e) {
				console.log(e, this.loadJob.lineno)
				
				if (listener.csvloaderLineError) {
					listener.csvloaderLineError(e);
				}
				return LINE_ERR;
			}

			return needMore;
		},

		fullLoad: function(from_current_pos) {
			if (!from_current_pos) {
				this.rewind();
			}

			this.advance(true);
		},

		rewind: function() {
			this.loadJob.currentPos = 0;
			this.loadJob.lineno = 0;
		}
	};

	// Listener methods
	// csvloaderOnReaderLoadEnd(loader):void
	// csvloaderReadLine(loader, fieldsArray, lineNumber):void



	pkg.utf8bytesToString = (function() {
		var chars_temp = [];
		
		return function(buf) {
			chars_temp.length = 0; // Clear
			
			var len = buf.length;
			for (var i = 0;i < len;i++) {
				var c1 = buf[i];
				if (c1 <= 0x7f) {
					// latin
					chars_temp.push( String.fromCharCode(buf[i]) );
				} else {
					// 2bytes
					var c2 = buf[i+1] | 0;
					if (c1 >= 0xc2 && c1 <= 0xdf) {
						chars_temp.push(String.fromCharCode(  (c2 & 0x3f) | ((c1 & 0x1f) << 6)  ));
					} else {
						// 3bytes
						var c3 = buf[i+2] | 0;
						if (c1 >= 0xe0 && c1 <= 0xef) {
							var w = (c3 & 0x3f) | ((c2 & 0x3f) << 6) | ((c1 & 0x0f) << 12);
							chars_temp.push( String.fromCharCode(w) );
						}
					}
				}
			}
		
			return chars_temp.join('');
		};
	})();
	
});