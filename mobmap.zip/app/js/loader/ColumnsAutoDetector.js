mmDefineModule(function(pkg) {
	'use strict';

	function ColumnsAutoDetector() {
		this.success = false;
		this.colmap = {};
	}

	ColumnsAutoDetector.RE_ID = /^[0-9 \t]+$/
	ColumnsAutoDetector.RE_COORD = /^[-+.0-9 \t]+$/

	ColumnsAutoDetector.RE_TIME1 = /[0-9]+:[0-9]+/

	ColumnsAutoDetector.CheckCoordVal = function(fieldRaw, min, max) {
		if (!ColumnsAutoDetector.RE_COORD.test(fieldRaw)) {
			return false;
		}
	
		var val = parseFloat(fieldRaw);
		return (val >= min && val <= max);
	};

	ColumnsAutoDetector.prototype = {
		detect: function(records) {
			var targetRow = records[1] || records[0];
			if (!targetRow) {
				return;
			}
		
			this.detectTime1(targetRow);
			this.detectId(targetRow);
			this.detectX(targetRow);
			this.detectY(targetRow);
		
			// look header cols (overwrite)
			var headRow = records[0];
			if (headRow) {
				this.detectXHeader(headRow);
				this.detectYHeader(headRow);
			}
		
			//console.log(this.colmap)
			this.success = true;
		},
	
		detectId: function(targetRow) {
			this.findColumnByCondition(
				targetRow,
				'id',
				function(field) {
					return ColumnsAutoDetector.RE_ID.test(field);
				}
			);
		},

		detectX: function(targetRow) {
			this.findColumnByCondition(
				targetRow,
				'x',
				function(field) {
					return ColumnsAutoDetector.CheckCoordVal(field, 100, 180);
				}
			);
		},

		detectY: function(targetRow) {
			this.findColumnByCondition(
				targetRow,
				'y',
				function(field) {
					return ColumnsAutoDetector.CheckCoordVal(field, 10, 80);
				}
			);
		},
	
		detectTime1: function(targetRow) {
			this.findColumnByCondition(
				targetRow,
				'time',
				function(field) {
					return ColumnsAutoDetector.RE_TIME1.test(field);
				}
			);
		},
	
		findColumnByCondition: function(targetRow, attr_name, cond_func) {
			var len = targetRow.length;
			for (var i = 0;i < len;++i) {
				if (this.colmap[i]) {continue;}
			
				if (cond_func(targetRow[i])) {
					this.colmap[i] = attr_name;
					return i;
				}
			}
		
			return -1;
		},
		
		// header detection - - - - - - -
		
		detectXHeader: function(targetRow) {
			this.selectColumnWithRegexp(targetRow, /^[xX]$|([lL][oO]?[nN][gG])/, 'x');
		},

		detectYHeader: function(targetRow) {
			this.selectColumnWithRegexp(targetRow, /^[yY]$|([lL][aA][tT])/, 'y');
		},
		
		selectColumnWithRegexp: function(targetRow, re, attr_name) {
			var len = targetRow.length;
			for (var i = 0;i < len;++i) {
				if (re.test( targetRow[i] )) {
					this.colmap[i] = attr_name;
					return i;
				}
			}
			
			return -1;
		},
		
		// - - - - - - - - - - - - - - -
	
		getIdColumnIndex: function()   { return this.getColumnIndexByName('id'); },
		getTimeColumnIndex: function() { return this.getColumnIndexByName('time'); },
		getXColumnIndex: function()    { return this.getColumnIndexByName('x'); },
		getYColumnIndex: function()    { return this.getColumnIndexByName('y'); },
	
		getColumnIndexByName: function(name) {
			for (var i in this.colmap) {
				if (this.colmap[i] === name) {
					return (i-0);
				}
			}
		
			return -1;
		}
	};

	pkg.ColumnsAutoDetector = ColumnsAutoDetector;
});
