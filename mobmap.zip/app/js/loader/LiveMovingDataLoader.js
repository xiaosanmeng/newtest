mmDefineModule(function(pkg) {
	'use strict';

	// LIVE listener APIs:
	//  liveOnInitialLoadSuccess
	//  liveOnInitialLoadFail
	//  liveOnUpdateSuccess

	function LiveMovingDataLoader(listener, baseURL, originTime, accessToken) {
		this.liveBaseURL = baseURL;
		this.accessToken = accessToken;
		this.originTime  = originTime;
		this.lastTime    = originTime;
		this.headerParameters = liveDataDefaultParams();
		this.downloadedSchemeData = null;
		
		this.atHeaderMode = true;
		
		this.networkStatusListener = null;
		this.initBaseProperties(listener, null);
	}
	
	function liveDataDefaultParams() {
		return {
			layerName: 'Live movement',
			bufferTime: 20,
			refreshInterval: 10
		};
	}

	LiveMovingDataLoader.prototype = {
		parseMovingObjectFields: mobmap.MovingDataCSVLoader.parseMovingObjectFields_Base,
		
		getRecommendedBufferTime:      function() { return this.headerParameters.bufferTime; },
		getRecommendedRefreshInterval: function() { return this.headerParameters.refreshInterval; },
		
		setNetworkStatusListener: function(listener) {
			this.networkStatusListener = listener;
		},
		
		start: function() {
			var u = this.generateInitialURL();
			this.sendRequest(u, 'init', this.originTime);
		},

		update: function() {
			var u = this.generateRealtimeURL();
			this.sendRequest(u, 'rt', this.lastTime);
		},

		// internal --------------------------
		generateInitialURL: function() {
			var header_param = '';
			if (this.atHeaderMode) {
				header_param = '&header=1'
			}
			
			return this.liveBaseURL + 'init?t=' + this.originTime + header_param;
		},
		
		generateRealtimeURL: function() {
			return this.liveBaseURL + 'rt?after=' + this.lastTime;
		},
		
		generateTokenParam: function() {
			return '&token='+this.accessToken;
		},

		generateHttpHeader: function() {
			// Include access token
			return {
				Authorization: 'Bearer ' + this.accessToken
			};
		},

		sendRequest: function(url, handlerPrerix, requestedTime) {
			var suc_f  = this[handlerPrerix + 'Succeeded'];
			var fail_f = this[handlerPrerix + 'Failed'];
			
			$.ajaxSetup({
				headers: this.generateHttpHeader()
			});

			$.ajax({
				url: url,
				type: 'GET',
				dataType: 'text',
				processData: false
			}).
			done( suc_f.bind(this, requestedTime) ).
			fail( fail_f.bind(this, requestedTime) );
		},
		
		initSucceeded: function(requestedTime, data) {
			var that = this;
			
			if (this.atHeaderMode) {
				this.setIgnoreFirstLine(false);
				data = this.processAtmarkHeaders(data, this.headerParameters);
			} else {
				this.setIgnoreFirstLine(true);

				var lineEndPos = data.indexOf('\n');
				if (lineEndPos >= 0) {
					if (this.listener && this.listener.csvloaderReadHeaderLine) {
						var headerLine = data.substring(0, lineEndPos);
						this.listener.csvloaderReadHeaderLine( headerLine.split(/ *, */) );
					}
				}
			}

			var blob = new Blob([data], {type : 'text/plain'});
			var fr = new FileReader();
			fr.onloadend = function() {
				var bytes = fr.result;
				that.setSourceUint8Array( new Uint8Array(bytes)  );
				// -> layer#csvloaderOnReaderLoadEnd
			};
			fr.readAsArrayBuffer(blob);
			
			var li = this.networkStatusListener;
			if (li && li.liveOnInitialLoadSuccess) {
				li.liveOnInitialLoadSuccess(this);
			}
		},

		processAtmarkHeaders: function(dataBody, outParams) {
			var handlerObject = this;
			
			var HeadPattern = /^[\t ]*@([^,]+)/ ;
			for (var i = 0;i < 9999;++i) {
				if (HeadPattern.test(dataBody)) {
					var headerType = RegExp['$1'];

					var headerLine = dataBody;
					var lineEndPos = dataBody.indexOf('\n');
					if (lineEndPos >= 0) {
						headerLine = dataBody.substring(0, lineEndPos);
						dataBody = dataBody.substring(lineEndPos + 1);
					}
					
					var h_args = headerLine.split(',');
					var handlerName = 'processATH_' + headerType;
					if (handlerObject[handlerName]) {
						handlerObject[handlerName](outParams, h_args);
					} else {
						console.log("** Unknown header ** ", i, headerType)
					}
				} else {
					break;
				}
			}

			return dataBody;
		},

		// @@@ ATHEADER HANDLERS @@@
		processATH_mobmap_layer_name: function(outMap, headerArgs) {
			if (headerArgs[1]) {
				outMap.layerName = headerArgs[1];
			}
		},
		
		processATH_mobmap_buffer_time: function(outMap, headerArgs) {
			if (headerArgs[1]) {
				outMap.bufferTime = parseInt(headerArgs[1], 10);
			}
		},

		processATH_mobmap_refresh_interval: function(outMap, headerArgs) {
			if (headerArgs[1]) {
				outMap.refreshInterval = parseInt(headerArgs[1], 10);
			}
		},

		processATH_mobmap_columns: function(outMap, headerArgs) {
			if (this.listener && this.listener.csvloaderReadHeaderLine) {
				headerArgs.shift(); // Remove header type
				this.listener.csvloaderReadHeaderLine(headerArgs);
			}
		},
		
		// -------------------------
		
		
		initFailed: function(requestedTime, e) {
			console.log("**** AJAX FAIL ****");
			console.log(e);

			var li = this.networkStatusListener;
			if (li && li.liveOnInitialLoadFail) {
				li.liveOnInitialLoadFail(this, e);
			}
		},
		
		rtSucceeded: function(requestedTime, data) {
			var li = this.networkStatusListener;
			if (li && li.liveOnUpdateSuccess) {
				li.liveOnUpdateSuccess(this, requestedTime, data);
			}

			console.log("[SUCCESS] Related time:", requestedTime - this.originTime);
		},
		
		rtFailed: function(requestedTime, e) {
			console.log("**** AJAX FAIL (2) ****");
			console.log(e);

			var li = this.networkStatusListener;
			if (li && li.liveOnUpdateFail) {
				li.liveOnUpdateFail(this, e);
			}
		},
		
		updateMaxFetchedTime: function(t) {
			if (t > this.lastTime) {
				this.lastTime = t;
				console.log("UP> ", t, this.lastTime);
			}
		}
	};

	mobmap.installBaseMethods(  LiveMovingDataLoader.prototype, mobmap.LoaderBase  );
	LiveMovingDataLoader.prototype.getSourceDescription = function() { return this.headerParameters.layerName; }
	
	pkg.LiveMovingDataLoader = LiveMovingDataLoader;
});