mmDefineModule(function(pkg) {
	'use strict';

	function GridCSVLoader(listener, inputFile) {
		this.initBaseProperties(listener, inputFile);
		this.gridCSVPhase = GridCSVLoader.PHASE_META;
	}

	GridCSVLoader.PHASE_META = 0;
	GridCSVLoader.PHASE_BODY = 1;

	GridCSVLoader.Base = {
		getPhase: function() {
			return this.gridCSVPhase;
		},

		finishMetaLines: function() {
			this.gridCSVPhase = GridCSVLoader.PHASE_BODY;
		}
	};

	GridCSVLoader.prototype = {
		getPhase: GridCSVLoader.Base.getPhase,
		finishMetaLines: GridCSVLoader.Base.finishMetaLines
	};

	var JapanMeshCodeDecoder = {
		calcLatIndexFromMeshCode: function(meshCode, level) {
			var index = 0;
			switch (level) {
			case 4:
				index = this.calcLv4LatitudeIndexFromCode(meshCode);
				break;

			case 3:
				var i1 = Math.floor(meshCode / 1000000);
				var yx2 = Math.floor(meshCode / 100) % 100;
				var i2  = Math.floor(yx2 / 10);
				var yx3 = meshCode % 100;
				var i3  = Math.floor(yx3 / 10);
		
				index = i1 * 80 + i2 * 10 + i3;
				break;
				
			case 2:
				var i1 = Math.floor(meshCode / 10000);
				var yx2 = meshCode % 100;
				var i2  = Math.floor(yx2 / 10);
			
				index = i1 * 8 + i2;
			
				break;

			default:
				index = Math.floor(meshCode / 100); break;
			}
		
			return index;
		},
	
		calcLv4LatitudeIndexFromCode: function(meshCode) {
			// Example: 533923431
			// Pick:    ^^  ^ ^ ^
		
			var i1 = Math.floor(meshCode / 10000000);

			var yx2 = Math.floor(meshCode / 1000) % 100;
			var i2  = Math.floor(yx2 / 10);

			var yx3 = Math.floor(meshCode / 10) % 100;
			var i3  = Math.floor(yx3 / 10);

			var yx4 = meshCode % 10;
			var i4 = (yx4 < 3) ? 0 : 1;

			return i1 * 160 + i2 * 20 + i3 * 2 + i4;
		},
	
		calcLngIndexFromMeshCode: function(meshCode, level) {
			var index = 0;
			switch (level) {
			case 4:
				index = this.calcLv4LongitudeIndexFromCode(meshCode);
				break;

			case 3:
				var i1 = Math.floor(meshCode / 10000) % 100;
				var i2 = Math.floor(meshCode / 100) % 10;
				var i3 = meshCode % 10;

				index = i1 * 80 + i2 * 10 + i3;
				break;
			
			case 2:
				var i1 = Math.floor(meshCode / 100) % 100;
				var i2 = meshCode % 10;
			
				index = i1 * 8 + i2;
			
				break;

			default:
				index = meshCode % 100; break;
			}

			return index;
		},

		calcLv4LongitudeIndexFromCode: function(meshCode) {
			// Example: 533923431
			// Pick:      ^^ ^ ^^

			var i1 = Math.floor(meshCode / 100000) % 100;
			var i2 = Math.floor(meshCode / 1000) % 10;
			var i3 = Math.floor(meshCode / 10) % 10;

			var yx4 = meshCode % 10;
			var i4 = (yx4 === 2 || yx4 === 4) ? 1 : 0;

			return i1 * 160 + i2 * 20 + i3 * 2 + i4;
		},
		
		setCellStep: function(md, meshLevel) {
			switch(meshLevel) {
			case 4:
			// 4-ji (2x2 div of 3-ji)
				md.stepLat = (1.0 / 1.5) / 160.0;
				md.stepLng = (1.0      ) / 160.0;
				break;

			case 3:
			// 3-ji (1/10 of 2-ji)
				md.stepLat = (1.0 / 1.5) / 80.0;
				md.stepLng = (1.0      ) / 80.0;
				break;
				
			case 2:
			// 2-ji (1/8 of 1-ji)
				md.stepLat = (1.0 / 1.5) / 8.0;
				md.stepLng = (1.0      ) / 8.0;
				break;
				
			default:
			// 1-ji
				md.stepLat = 1.0 / 1.5;
				md.stepLng = 1.0;
				break;
			}
		}
	};

	mobmap.installBaseMethods(  GridCSVLoader.prototype, mobmap.LoaderBase  );
	pkg.GridCSVLoader = GridCSVLoader;
	pkg.JapanMeshCodeDecoder = JapanMeshCodeDecoder;
});