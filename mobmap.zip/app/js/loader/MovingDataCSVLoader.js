mmDefineModule(function(pkg) {
	'use strict';

	function MovingDataCSVLoader(listener, inputFile) {
		this.initBaseProperties(listener, inputFile);
	}
	
	// can be used on other class
	MovingDataCSVLoader.parseMovingObjectFields_Base = function(attributeList, fieldsArray, lineNumber) {
		var outRecord = mobmap.MovingData.createEmptyRecord();

		var nCols = fieldsArray.length;
		for (var i = 0;i < nCols;++i) {
			var val = fieldsArray[i];
			attributeList.convertToColumnType(i, val, outRecord);
		}
		
		return outRecord;
	}

	MovingDataCSVLoader.prototype = {
		parseMovingObjectFields: MovingDataCSVLoader.parseMovingObjectFields_Base
	};
	

	mobmap.installBaseMethods(  MovingDataCSVLoader.prototype, mobmap.LoaderBase  );
	pkg.MovingDataCSVLoader = MovingDataCSVLoader;
});