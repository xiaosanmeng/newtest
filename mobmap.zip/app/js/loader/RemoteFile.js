mmDefineModule(function(pkg) {
	'use strict';


	function RemoteFile(sourceURL) {
		this.sourceURL = sourceURL;
		this.rxFinished = false;
		this.hasError = false;
		this.responseText = '';
		this.name = null;

		var that = this;
		$.ajax({
			type: 'get',
			url: sourceURL,
			
			xhrFields: {
				onloadstart: function() {
					var xhr = this;
					xhr.onreadystatechange = that.onReadyStateChange.bind(that, xhr);
				}
			},
			
			success: that.onXHRSuccess.bind(that),
			error:   that.onXHRFail.bind(that)
		});
	}
	
	RemoteFile.prototype = {
		setName: function(name) {
			this.name = name;
		},
		
		onXHRSuccess: function(data, dataType) {
			this.responseText = this.addTailNewlineIf( data );
			this.rxFinished = true;
		},

		onXHRFail: function() {
			this.hasError = true;
			this.rxFinished = true;
		},
		
		onReadyStateChange: function(xhr) {
//			this.responseText = xhr.responseText;
//			console.log('>>', xhr, xhr.readyState)
		},
		
		addTailNewlineIf: function(source) {
			if (source.length < 1) { return "\n"; }
			var k = source.charCodeAt(source.length - 1);
			
			if (k !== 0x0a && k !== 0x0d) {
				return source + "\n";
			} else {
				return source;
			}
		},
		
		isCompleted: function() {
			return this.rxFinished;
		}
	};
	
	// ----------------------------------------------------------------------------
	
	function RemoteFileReader() {
		this.charBuffer = [];
	}
	
	RemoteFileReader.prototype = {
		getError: function(inputFile) {
			if (inputFile.hasError) {
				return "Failed to download.";
			}
			
			return null;
		},
		
		readLine: function(fieldList, inputFile, loadJob) {
			// inputFile.simulateRx();
			// console.log(inputFile.responseText)
			
			if (this.findNewLine(inputFile, loadJob)) {
				++loadJob.lineno;
				loadJob.currentPos = loadJob.prefetchPos;
				
				this.copyFields(fieldList);
				
				this.charBuffer.length = 0; // clear
			}
			

			if (inputFile.isCompleted()) {
				var finLength = inputFile.responseText.length;
				if (loadJob.currentPos >= finLength) {
					return false;
				}
			}
			
			return true;
		},
		
		findNewLine: function(inputFile, loadJob) {
			var cbuf = this.charBuffer;

			var str = inputFile.responseText;
			var endPos = str.length;
			
			for (var i = loadJob.prefetchPos;i < endPos;++i) {
				var chr = str.charCodeAt(i);
				if (chr === 0x0a || chr === 0x0d) {
					loadJob.prefetchPos = i+1;
					return true;
				} else {
					cbuf.push(str.charAt(i));
				}
			}
			
			loadJob.prefetchPos = i;
			return false;
		},

		copyFields: function(outList) {
			var inList = this.charBuffer.join('').split(',');
			for (var i = 0;i < inList.length;++i) {
				outList.push(inList[i]);
			}
		}
	};
	
	
	function RemoteFileAttrSetting(attrList) {
		this.attrList = attrList;
	}
	
	RemoteFileAttrSetting.prototype = {
		getColumnIndexOfAttrName: function(name) {
			var ls = this.attrList;
			for (var i = 0;i < ls.length;++i) {
				var a = ls[i];
				if (a.name === name) {
					return a.columnIndex;
				}
			}
			
			return null;
		},
		
		eachAditionalAttribute: function(func) {
			var ls = this.attrList;
			for (var i = 0;i < ls.length;++i) {
				var a = ls[i];
				if (kRequiredMovingObjectAttributeQuickMap[a.name]) { continue; }
				
				func(a.columnIndex, a);
			}
		}
	}

	pkg.RemoteFile = RemoteFile;
	pkg.RemoteFileReader = RemoteFileReader;
	pkg.RemoteFileAttrSetting = RemoteFileAttrSetting;
});