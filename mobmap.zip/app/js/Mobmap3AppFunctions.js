mmDefineModule(function(pkg) {
	'use strict';
	
	var Mobmap3AppFunctionBase = {
		getMapPane: function() {
			return this.mainUI.getMapPane();
		},
		
		putNewLineGate: function(lat, lng, lat2, lng2) {
			return this.putNewGateWithType(mobmap.LandSensorTypes.LineGate,
				lat, lng,
				lat2, lng2
			);
		},

		putNewPolygonGate: function(lat, lng) {
			return this.putNewGateWithType(mobmap.LandSensorTypes.PolygonGate, lat, lng);
		},

		putNewGateWithType: function(gateType, lat, lng, lat2, lng2) {
			var proj = this.getCurrentProject();
			if (proj) {
				return proj.addLandSensor(gateType, lat, lng, lat2, lng2);
			}
			
			return null;
		},

		addLayerWithConstructor: function(Ctor) {
			var proj = this.getCurrentProject();
			if (!proj) { return null; }
			var lyr = new Ctor();

			proj.getLayerList().add(lyr);
			return lyr;
		},

		addNewMovingObjectLayer: function() {
			return this.addLayerWithConstructor( mobmap.MovingObjectLayer );
		},
		
		loadMovingDataCSVFile: function(inFile, columnMapping) {
			var layer = this.addNewMovingObjectLayer();
			if (columnMapping) {
				layer.applyColumnMapping(columnMapping);
			}
			
			var loader = new mobmap.MovingDataCSVLoader(layer, inFile);
			layer.setLoader(loader);
			layer.enableAutoLoad();
			
			loader.prepare();
		},


		addNewGridLayer: function() {
			return this.addLayerWithConstructor( mobmap.GridLayer );
		},


		redrawMapPane: function() {
			var mp = this.mainUI.getMapPane();
			if (mp) {
				mp.redraw( this.getCurrentProject() );
				mp.updateClock( this.getCurrentProject() );
			}
		},

		getSelectedLayer: function() {
			var pj = this.getCurrentProject();
			if (pj) {
				var targetId = pj.lyrselGetFirstId();
				if (targetId !== null) {
					return pj.getLayerList().findById(targetId);
				}
			}

			return null;
		},
		
		clearSelectedLayerSelection: function() {
			var pj = this.getCurrentProject();
			if (pj) {
				pj.lyrselEach(function(layer) {
					var selp = layer.getSelectionPool();
					if (selp) {
						selp.clear();
					}
				});
			}
		},

		createGateSensorJob: function(gateLandSensor) {
			var layer = this.getSelectedLayer();
			var md = layer.movingData;
			if (layer && md) {
				gateLandSensor.updateGoogleMapsGeometories();
				var job = new mobmap.GateOperationjob(md, gateLandSensor);
				
				var EV = mobmap.GateOperationjob.Event;
				job.eventDispatcher().
				 bind(EV.WillStart, this.onGateJobWillStart.bind(this)).
				 bind(EV.Progress,  this.onGateJobProgress.bind(this)).
				 bind(EV.Finish,    this.onGateJobFinish.bind(this));

				job.setTargetLayerId(layer.layerId);
				return job;
			}
			
			return null;
		},

		onGateJobWillStart: function(e, senderJob) {
			this.mainUI.showProgressScreen();
		},

		onGateJobProgress: function(e, senderJob, progress) {
			this.mainUI.setProgressScreenPercentage( progress * 100.0, senderJob.partIndex, senderJob.partsCount );
		},

		onGateJobFinish: function(e, senderJob) {
			if (senderJob.partsCount && senderJob.partIndex < (senderJob.partsCount-1)) {
				// coming next
				return;
			}
			
			this.mainUI.hideProgressScreen();
		},


		openCSVLoaderScreen: function() {
			return this.mainUI.openCSVLoaderScreen();
		},

		openGridCSVLoaderScreen: function() {
			if (this.gridDataLoadController) {
				this.gridDataLoadController.openFileDialog();
			}
		},

		openLiveMovSetupScreen: function(parameters) {
			var c = this.ensureLiveMovLoadController();
			c.start(parameters);
		},

		openLiveGridSetupScreen: function() {
			var layer = this.addNewGridLayer();

			var loader = new mobmap.RemoteProgressiveLoader(layer);
			layer.setLoader(loader);
			loader.prepare();

			return layer;
		},

		ensureLiveMovLoadController: function() {
			if (!this.liveMovLoadController) {
				this.liveMovLoadController = new mobmap.LiveMovingDataLoadController();
				this.liveMovLoadController.setOwnerApp(this);
			}
			
			return this.liveMovLoadController;
		},

		selectObjectsOnLayer: function(layerId, idmap, operation) {
			var pj = this.getCurrentProject();
			var layer = pj.getLayerList().findById(layerId);
			if (layer) {
				if (layer.isSelectable()) {
					//----------------------------------------------  v- fire event
					layer.getSelectionPool().selectWithIdMap(idmap, false,        operation);
				}
			} 
		},

		executeRectangleSelection: function(minLat, minLng, maxLat, maxLng,  toggleToolButton) {
			if (toggleToolButton) {
				this.deactivateRectSelectButton();
			}

			var layer = this.getSelectedLayer();
			if (layer) {
				var selp = layer.getSelectionPool();
				if (selp) {
					var targetTime = this.getCurrentProject().currentDateTime;
					var pickTime = targetTime.getCurrentTimeAsInt();

					this.selectionController.
					 doRectSelection(layer, selp, pickTime, minLat, minLng, maxLat, maxLng);
				}
			}
		},

		aimMapToId: function(objId) {
			var layer = this.getSelectedLayer();
			if (layer.type === mobmap.LayerType.MovingObject) {
				var md = layer.movingData;
				if (!this.tempPickRec) {
					this.tempPickRec = mobmap.MovingData.createEmptyRecord();
				}
				
				var tl = md.getTimeListOfId(objId);
				if (tl) {
					var targetTime = this.getCurrentProject().currentDateTime;
					var pickTime = targetTime.getCurrentTimeAsInt();

					tl.pickAt(null, this.tempPickRec, pickTime);
					this.getMapPane().aim(this.tempPickRec.y, this.tempPickRec.x);
				}
			}
		},

		isAnySelectedOnCurrentLayer: function() {
			var layer = this.getSelectedLayer();
			if (layer) {
				var sp = layer.getSelectionPool();
				if (sp) {
					return sp.isAnySelected();
				}
			}

			return false;
		},

		// SAMPLE DATA MODE
		checkSampleDataViewerMode: function() {
			var re = /\?load=opf[^/]*$/ ;
			if ( re.test( document.URL ) ) {
				window.setTimeout( (function(e) {
					var scr = this.mainUI.ensureSampleDataScreen( this.autoLoadSampleData.bind(this) );
					scr.show();
				}).bind(this), 250 );
			}
		},
		
		autoLoadSampleData: function() {
			var attrs = new mobmap.RemoteFileAttrSetting([
				{name: 'id'  , columnIndex: 0, type: AttributeType.INTEGER},
				{name: 'time', columnIndex: 1, type: AttributeType.DATETIME},
				{name: 'x'   , columnIndex: 2, type: AttributeType.CFLOAT},
				{name: 'y'   , columnIndex: 3, type: AttributeType.CFLOAT},
				{name: 'mode', columnIndex: 4, type: AttributeType.INTEGER},
				{name: 'mag' , columnIndex: 5, type: AttributeType.FLOAT}
			]);
			
			var remoteFile = new mobmap.RemoteFile('data/op-sample.csv');
			remoteFile.setName('Open PFLOW');
			var remoteFileReader = new mobmap.RemoteFileReader();
			var ld = this.dataLoadController.initLoadData(remoteFile);
			
			ld.layer.setInitialSettings({
				numOfMarkers: 6,
				boundAttribute: 'mode',
				coloring: {
					preset: 'Hue',
					reversed: true
				},
				composition: mobmap.MarkerOptionModelProxy.Composition_Add,
				autoSizing: mobmap.MarkerOptionModelProxy.Sizing.ToSmall,
				mapType: 'LiteDark',
				mapZoom: 10,
				
				autoPlay: {
					delay: 700,
					speed: 3600
				},
				
				showClock: true,
				showGateDock: false,
				
				inMapContent: {
					markerIndices: [1, 2, 3, 4, 99],
					html: '<div class="mm-inmap-legend-outer mm-inmap-legend-onlyfor-mode"><h3>Open PFLOW<span>Transportation modes</span></h3>'+
					      ' <span class="mm-inmap-legend-marker-1">●</span> 1 WALK<br>'+
					      ' <span class="mm-inmap-legend-marker-2">●</span> 2 VEHICLE<br>'+
					      ' <span class="mm-inmap-legend-marker-3">●</span> 3 TRAIN<br>'+
					      ' <span class="mm-inmap-legend-marker-4">●</span> 4 BICYCLE<br>'+
					      ' <span class="mm-inmap-legend-marker-99">●</span> 99 STAY<br>'+
					      '</div>'
				}
			});
			
			ld.loader.setFixedLineCount(394129);
			ld.loader.setAlternativeReader(remoteFileReader);

			this.dataLoadController.startFullLoad(false, attrs);
		},

		// Auto action
		executeLayerInitialAction: function(layer) {
			var s = layer.getInitialSettings();
			if (!s) { return; }
			
			var ap = s.getAutoPlay();
			if (ap) {
				var that = this;
				setTimeout( function() { that.autoplayController.play(); } , ap.delay || 1 );
				
				if (ap.speed) {
					this.mainUI.getToolPane().getPlayControllerUI().forceSetSpeed(ap.speed);
				}
			}
			
			this.forceClockVisibility( s.getShowClock() );
			this.forceGateDockVisibility( s.getShowGateDock() );
		},

		// Custom gradients(marker coloring)
		renewCustomGradient: function(provider) {
			var i;
			mobmap.clearMarkerSetPresetCustomList();

			var n = provider.gradientsCount();
			for (i = 0;i < n;++i) {
				var data = provider.gradientsGetAt(i);
				mobmap.addToMarkerSetPresetCustomList( data );
			}
			
			mobmap.saveMarkerSetPresetCustomList();
			
			var pj = this.getCurrentProject();
			var ll = pj.getLayerList();
			var numLayers = ll.count();
			for (i = 0;i < numLayers;++i) {
				var mo = ll.getAt(i).getMarkerOption();
				if (mo) {
					mo.fireGradientSetChange();
				}
			}
		},

		// Shape importer
		ensureShapeImporterScreen: function() {
			return this.mainUI.ensureShapeImporterScreen();
		},

		// Outer commands

		sendOuterMessage: function(command, params) {
			var msg = {
				command: command,
				params: params
			} ;

			window.parent.postMessage(msg, '*');
		},
		
		openReportWindow: function(templateName, contentData, pluginId) {
			this.popupManager.open(pluginId, "plugins/" +pluginId+ "/" + templateName, contentData);
		},
		
		saveSmallTextAsLocalFile: function(content) {
			this.sendOuterMessage('saveSmallTextAsLocalFile', {
				content: content
			});
		},

		sendMessageToPlugin: function(pluginId, command, params) {
			var ep = this.mainUI.getExtPane();
			if (ep) {
				ep.sendMessage(pluginId, command, params);
			}
		}
	};
	
	pkg.Mobmap3AppFunctionBase = Mobmap3AppFunctionBase;
});
