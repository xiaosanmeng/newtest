mmDefineModule(function(pkg) {
	'use strict';

	function SelectionController() {
		this.mapPane = null;
		this.gmap = null;
		this.currentSession = {
			type: null,
			vertices: []
		};
		
		this.rectSelectionOverlay = null;
		this.rectSelectionVertices = [0,0,0,0];
	}
	
	SelectionController.prototype = {
		setMap: function(mapPane) {
			this.mapPane = mapPane;
			this.gmap = mapPane.getGoogleMaps();

			this.observeMapEvents(mapPane);
		},

		initSessionForRectSelection: function() {
			this.currentSession.type = SelectionSession.Rect;
			this.currentSession.vertices.length = 0;
		},

		clearSession: function() {
			this.currentSession.type = null;
			this.currentSession.vertices.length = 0;
		},

		observeMapEvents: function(mapPane) {
			var E = mobmap.MapPane.PointingEvent;

			mapPane.eventDispatcher().
			 bind(E.Begin, this.onMapPointingBegin.bind(this)).
			 bind(E.Move , this.onMapPointingMove.bind(this)).
			 bind(E.End  , this.onMapPointingEnd.bind(this));
		},

		beginRectSelection: function() {
			this.initSessionForRectSelection();
			this.setMapSelectionMode();
		},

		endSelection: function() {
			if (this.hasSession) {
				this.clearSession();
				this.leaveMapSelectionMode();
			}
		},
		
		// Rect selection feedback -------------------
		setRectSelectionFirstLocation: function(loc) {
			if (!(this.hasRectSelSession)) { return; }
			
			if (this.currentSession.vertices.length < 1) {
				this.currentSession.vertices.push(loc)
			} else {
				this.currentSession.vertices[0] = loc;
			}
		},

		setRectSelectionEndLocation: function(loc) {
			if (!(this.hasRectSelSession)) { return; }
			
			if (this.currentSession.vertices.length < 2) {
				this.currentSession.vertices.push(loc)
			} else {
				this.currentSession.vertices[1] = loc;
			}
		},

		showRectSelectionOverlay: function() {
			if (!this.rectSelectionOverlay) {
				this.rectSelectionOverlay = new google.maps.Polygon({
				 strokeColor: '#20abff',
				    strokeOpacity: 0.8,
				    strokeWeight: 2,
				    fillColor: '#20abff',
				    fillOpacity: 0.4
				});
			}
			
			this.rectSelectionOverlay.setMap(this.gmap);
		},

		hideRectSelectionOverlay: function() {
			if (this.rectSelectionOverlay) {
				this.rectSelectionOverlay.setMap(null);
			}
		},

		updateRectSelectionOverlay: function() {
			if (!(this.hasRectSelSession)) { return; }
			if (this.currentSession.vertices.length < 2) { return; }
			
			var src = this.currentSession.vertices;
			var vs = this.rectSelectionVertices;
			vs[0] = src[0];
			vs[2] = src[1];
			
			// Make diagonal vertices
			vs[1] = new google.maps.LatLng(src[0].lat(), src[1].lng());
			vs[3] = new google.maps.LatLng(src[1].lat(), src[0].lng());

			if (this.rectSelectionOverlay) {
				this.rectSelectionOverlay.setPath(vs);
			}
		},
		
		sendRectSelectionRequest: function() {
			var app = this.getOwnerApp();
			var ls = this.currentSession.vertices;
			
			app.executeRectangleSelection(
				Math.min( ls[0].lat(), ls[1].lat() ),
				Math.min( ls[0].lng(), ls[1].lng() ),
				Math.max( ls[0].lat(), ls[1].lat() ),
				Math.max( ls[0].lng(), ls[1].lng() ),
				true); 
		},
		// ----------------------------------------------
		doRectSelection: function(layer, selectionPool, pickTime, minLat, minLng, maxLat, maxLng) {
			var md = layer.movingData;
			var pickPool = layer.ensurePickPoolForSelection();
			
			pickPool.clear();
			md.pickAt(pickPool, pickTime);
			
			this.filterRect(pickPool, selectionPool, false, minLat, minLng, maxLat, maxLng);
			selectionPool.fireChange();
		},

		filterRect: function(sourcePickPool, targetSelPool, useAndOp, ymin,xmin, ymax,xmax) {
			
			var sourceCount = sourcePickPool.pickedCount;
			var src_array = sourcePickPool.getArray();
			for (var i = 0;i < sourceCount;++i) {
				var sourceRecord = src_array[i];
				var objId = sourceRecord.id;

				var ox = sourceRecord.x;
				var oy = sourceRecord.y;
				if (ox >= xmin && oy >= ymin && ox <= xmax && oy <= ymax) {
					// AND mode: Don't select new objects.
					// Other   : Add new
					if (!useAndOp) {
						targetSelPool.addId(objId, true);
					}
				} else {
					// AND mode: remove if the id is out of new selection
					if (useAndOp) {
						targetSelPool.removeId(objId, true);
					}
				}
			}
		},

		// ----------------------------------------------



		hasSession: function() {
			return !!(this.currentSession.type);
		},

		hasRectSelSession: function() {
			return (this.currentSession.type === SelectionSession.Rect);
		},

		setMapSelectionMode: function() {
			// disable grab scroll
			this.mapPane.setPointingMode(mobmap.MapPane.PointingMode.Drawing);
		},

		leaveMapSelectionMode: function() {
			this.mapPane.setPointingMode(mobmap.MapPane.PointingMode.Default);
		},


		onMapPointingBegin: function(e, originalEvent) {
			var pointedLocation = this.mapPane.latLngFromClick(originalEvent);
			if (pointedLocation) {
				if (this.hasRectSelSession()) {
					this.setRectSelectionFirstLocation(pointedLocation);
				}
			}
		},

		onMapPointingMove: function(e, originalEvent) {
			var pointedLocation = this.mapPane.latLngFromClick(originalEvent);
			if (pointedLocation) {
				if (this.hasRectSelSession()) {
					this.setRectSelectionEndLocation(pointedLocation);
					this.updateRectSelectionOverlay();
					this.showRectSelectionOverlay();
				}
			}
		},

		onMapPointingEnd: function(e, originalEvent) {
			var pointedLocation = this.mapPane.latLngFromClick(originalEvent);
			if (pointedLocation) {
				if (this.hasRectSelSession()) {
					this.hideRectSelectionOverlay();
					this.setRectSelectionEndLocation(pointedLocation);
					this.sendRectSelectionRequest();
				}
			}
		}
	};

	// base classes
	mobmap.installBaseMethods(  SelectionController.prototype, mobmap.AppOwnedBase  );

	pkg.SelectionController = SelectionController;
});