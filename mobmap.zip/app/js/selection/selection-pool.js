mmDefineModule(function(pkg) {
	'use strict';
	
	function SelectionPool(owner) {
		this.owner = owner || null;
		this.idmap = {};
	}
	
	SelectionPool.CHANGE_EVENT = "selection-pool-change";
	
	SelectionPool.prototype = {
		getOwner: function() {
			return this.owner;
		},

		addToArray: function(arr) {
			var m = this.idmap;
			for ( var i in m )  if (m.hasOwnProperty(i))  {
				arr.push(i);
			}
		},

		selectWithIdMap: function(idmap, suppress_event, operation) {
			// [AND]
			if (operation === kBooleanOpNames.And) {
				this.applyBooleanAND(idmap, suppress_event);
				return;
			}

			// [NOT]
			if (operation === kBooleanOpNames.Not) {
				this.applyBooleanNOT(idmap, suppress_event);
				return;
			}
			
			// [OR] [NEW]
			if (operation !== kBooleanOpNames.Or) {
				this.clear();
			}
			// If operation is OR, remain previous selection
			
			
			for (var i in idmap) if (idmap.hasOwnProperty(i)) {
				this.idmap[  idmap[i]  ] = idmap[i];
			}

			if (!suppress_event) { this.fireChange(); }
		},

		applyBooleanAND: function(dest_idmap, suppress_event) {
			var m = this.idmap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				if ( !(dest_idmap.hasOwnProperty(i)) ) {
					delete m[i];
				}
			}

			if (!suppress_event) { this.fireChange(); }
		},
		
		applyBooleanNOT: function(dest_idmap, suppress_event) {
			var m = this.idmap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				// Remove if ID is in given map
				if ( dest_idmap.hasOwnProperty(i) ) {
					delete m[i];
				}
			}

			if (!suppress_event) { this.fireChange(); }
		},

		addId: function(objId, suppress_event) {
			this.idmap[objId] = objId;
			
			if (!suppress_event) { this.fireChange(); }
		},

		removeId: function(objId, suppress_event) {
			if (this.idmap.hasOwnProperty(objId)) {
				delete this.idmap[objId];

				if (!suppress_event) { this.fireChange(); }
			}
		},

		clear: function(suppress_event) {
			if (!this.isAnySelected()) {
				return false;
			}
			
			var m = this.idmap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				delete m[i];
			}

			if (!suppress_event) { this.fireChange(); }
			return true;
		},
		
		isAnySelected: function() {
			var m = this.idmap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				return true;
			}
			
			return false;
		},

		count: function() {
			var m = this.idmap;
			var n = 0;
			
			for (var i in m) if (m.hasOwnProperty(i)) { ++n; }
			return n;
		},

		pushIDsToArray: function(outArray) {
			var m = this.idmap;
			for (var i in m) {
				outArray.push(i);
			}
		},

		isIDSelected: function(objId) {
			return this.idmap.hasOwnProperty(objId);
		},

		fireChange: function() {
			this.fire(SelectionPool.CHANGE_EVENT, this);
		}
	};

	mobmap.installBaseMethods(  SelectionPool.prototype, mobmap.PseudoEventNodeBase  );

	pkg.SelectionPool = SelectionPool;
});