mmDefineModule(function(pkg) {
	'use strict';
	
	function DateTime() {
		this.currentTime = 0;
	}
	
	DateTime.CURRENT_TIME_CHANGE_EVENT = "mm-datetime-current-time-change";
	
	DateTime.prototype = {
		// get and set
		getCurrentTime: function() { return this.currentTime; },
		getCurrentTimeAsInt: function() { return this.currentTime | 0; },
		setCurrentTime: function(t, suppress_event) {
			if (this.currentTime !== t) {
				this.currentTime = t;
				if (!suppress_event) {	
					this.fire(DateTime.CURRENT_TIME_CHANGE_EVENT, this);
				}
			}
		},

		// Utilities
		capMax: function(maxSec) {
			if (this.currentTime > maxSec) {
				this.currentTime = maxSec;
				return true;
			}
			
			return false;
		},
		
		capMin: function(minSec) {
			if (this.currentTime < minSec) {
				this.currentTime = minSec;
				return true;
			}
			
			return false;
		},
		
		shiftTime: function(dSec) {
			this.setCurrentTime( this.currentTime + dSec );
		},

		makeCurrentPrettyDate: function() {
			return DateTime.makePrettyDateFromSeconds(this.currentTime);
		},

		makeCurrentPrettyTime: function() {
			return DateTime.makePrettyTimeFromSeconds(this.currentTime);
		}
	};

	DateTime.makePrettyDateFromSeconds = function(t) {
		return DateTime.makePrettyDateFromDateObj( new Date(t * 1000.0) );
	};

	DateTime.makePrettyDateFromDateObj = function(d) {
		return d.getFullYear() + '-' + padding_02(d.getMonth()+1) + '-' + padding_02(d.getDate());
	};
	
	DateTime.makePrettyTimeFromSeconds = function(t) {
		return DateTime.makePrettyTimeFromDateObj( new Date(t * 1000.0) );
	};
	
	DateTime.makePrettyTimeFromDateObj = function(d) {
		return padding_02(d.getHours()) +':' + padding_02(d.getMinutes()) +':' + padding_02(d.getSeconds());
	};

	// base classes
	mobmap.installBaseMethods(  DateTime.prototype, mobmap.PseudoEventNodeBase  );
	
	// Export - - - - - - - -
	pkg.DateTime = DateTime;
});