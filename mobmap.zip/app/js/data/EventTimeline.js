mmDefineModule(function(pkg) {
	'use strict';

	function EventTimeline() {
		this.configuration = new EventTimeline.Configuration();
		
		this.timeToValHash = {};
		this.timeToMapHash = {};
		this.defaultColor = '#692';
		this.contentDirty = true;
		this.contentIncomplete = true;
		this.progress = 0;
		
		this.remainEnabled = false;

		this.timeListTemp = [];
		this.volumeListTemp = [];
		this.timeListDirty = true;

		this.visualCache = null;
		this.stripePattern = null;
		this.stripePosition = 0;
		this.currentVisualWidth = 8;
		this.visualCacheHeight = 25;
		
		this.cachedTimeMin = null;
		this.cachedTimeMax = null;
		
		this.ensureVisualizedCanvas( this.currentVisualWidth );
	}

	EventTimeline.prototype = {
		clean: function() {
			var i, m;
			
			m = this.timeToValHash;
			for (i in m) if (m.hasOwnProperty(i)) { delete m[i]; }

			m = this.timeToMapHash;
			for (i in m) if (m.hasOwnProperty(i)) { delete m[i]; }

			this.timeListDirty = true;
			this.invalidateContent();
		},
		
		setRemainEnabled: function(b) {
			this.remainEnabled = b;
		},

		invalidateContent: function() {
			this.contentDirty = true;
			this.invalidateCache();
		},

		invalidateCache: function() {
			this.currentVisualWidth = -1;
		},

		setContentCompleteFlag: function(b, prog) {
			this.contentIncomplete = b;
			this.progress = prog || 1;
		},

		markContentUpdated: function() {
			this.contentDirty = false;
			this.invalidateCache();
		},

		addValue: function(unixtime, value, objId) {
			var m = this.timeToValHash;
			if (!( m.hasOwnProperty(unixtime) )) {
				m[unixtime] = 0;
			}
			m[unixtime] += value;

			// remain mode only
			if (this.remainEnabled) {
				var l = this.timeToMapHash;
				if (!( l.hasOwnProperty(unixtime) )) {
					l[unixtime] = {};
				}

				if (objId !== undefined) {
					l[unixtime][objId] = value;
				}
			}

			this.timeListDirty = true;
		},

		ensureVisualizedCanvas: function(width) {
			if (!this.visualCache) {
				this.visualCache = document.createElement('canvas');
				
				var img = generateStripePattern();
				this.stripePattern = this.visualCache.getContext('2d').createPattern(img, 'repeat-x');
			}

			if ( (this.visualCache.width - 0) !== width ) {
				this.visualCache.width = width;
				this.visualCache.height = this.visualCacheHeight;
			}
			
			return this.visualCache;
		},

		updateVisualizedImage: function(width, timeRangeMin, timeRangeMax) {
			if (width < 8) {width = 8;}
			
			if (width === this.currentVisualWidth &&
				this.cachedTimeMin === timeRangeMin &&
				this.cachedTimeMax === timeRangeMax) {
				return this.visualCache;
			}
			
			// RENEW
			this.currentVisualWidth = width;
			this.cachedTimeMin = timeRangeMin;
			this.cachedTimeMax = timeRangeMax;

			var cv = this.ensureVisualizedCanvas(width);
			cv.style.backgroundColor = '#000';
			var g = cv.getContext('2d');

			this.renderVisualization(g, width, this.visualCacheHeight, timeRangeMin, timeRangeMax);
			return this.visualCache;
		},
		
		renderVisualization: function(g, w, h, timeRangeMin, timeRangeMax) {
			g.clearRect(0, 0, w, h);
			
			if (!this.contentIncomplete) {
				var tlen = timeRangeMax - timeRangeMin;
				var tList = this.updateTimeList();
				var vList = this.volumeListTemp;
				vList.length = 0; // CLEAR

				if (!this.remainEnabled) {
					// �����V���b�g���[�h�̃����_�����O
					// - ���ԕ��͉�ʏ�̃s�N�Z������ɂ���
					// - �^�C�����C�����1px�ɂ������Ԃō��v�l���W�v���ĕ`�悷��
					this.generateDisplayValueList(vList, tList, timeRangeMin, tlen, w);
				} else {
					// �����C�����[�h
					// - ���ԕ��͉�ʏ�̃s�N�Z������ɂ���
					// - ID���ƂɍŏI�l���L�^���Ȃ���i�߂�
					this.generateRemainModeValueList(vList, tList, timeRangeMin, tlen, w);
				}
			
				this.renderValues(g, h, vList, this.findMax(vList) );
				vList.length = 0; // �g���I������璼���Ƀ��X�g���N���A
			}

			if (this.contentIncomplete) {
				this.renderStripe(g, w, h);
			}
		},

		generateDisplayValueList: function(outVList, timeList, timeRangeMin, timeRangeLength, pixelsWidth) {
			this.sumUp(null);
			this.sumUp(timeList, timeRangeMin);

			for (var x = 0;x < pixelsWidth;++x) {
				var rel2 = (x+1) / pixelsWidth;
				var t2 = timeRangeMin + (timeRangeLength * rel2);
			
				// �O��Ăяo������t����t2�ȑO�̊Ԃ��W�v
				var volume = this.sumUp(timeList, t2);
				outVList.push(volume);
			}

			return outVList;
		},

		generateRemainModeValueList: function(outVList, timeList, timeRangeMin, timeRangeLength, pixelsWidth) {
			this.remainCount(null);
		
			for (var x = 0;x < pixelsWidth;++x) {
				var relPos = x / pixelsWidth;
				var curT   = timeRangeMin + (timeRangeLength * relPos);
				
				var volume = this.remainCount(timeList, curT);
				outVList.push(volume);
			}
		},

		findMax: function(vList) {
			var max = 0.001;
			var n = vList.length;
			for (var i = 0;i < n;++i) {
				if (vList[i] > max) { max = vList[i]; }
			}

			return max;
		},
		
		renderStripe: function(g, width, height) {
			g.save();
				var cw = Math.floor(width * this.progress);
				if (this.progress < 0.999) {
					g.beginPath();
					g.moveTo(-1, 0);
					g.lineTo(cw, 0);
					g.lineTo(cw, height);
					g.lineTo(-1, height);
					g.clip();
				}
	
				g.fillStyle = this.stripePattern;
				g.translate(-this.stripePosition, 0);
				if (cw > 0) {
					g.fillRect(-STRIPE_WIDTH, 0, width +STRIPE_WIDTH+STRIPE_WIDTH, height);
				}
			g.restore();
			
			this.stripePosition = (this.stripePosition+1) % STRIPE_WIDTH;
		},
		
		renderValues: function(g, height, vList, valMax) {
			g.fillStyle = this.defaultColor;
			var n = vList.length;
			for (var i = 0;i < n;++i) {
				var volume = vList[i];
				var iH = Math.floor((volume * height / valMax) + 0.99);
				g.fillRect(i, height - iH, 1, iH);
			}
		},

		sumUp: (function() {
			var position = 0;
			
			return function(targetList, beforeThisTime) {
				if (!targetList) {
					position = 0;
					return 0;
				}
				
				var sum = 0;
				for (var i = 0;i < targetList.length;++i) {
					if (position < targetList.length) {
						if (targetList[position] >= beforeThisTime) {
							break;
						}
						sum += this.timeToValHash[ targetList[position] ];
						++position;
					} else {
						break;
					}
				}
				
				return sum;
			};
		})(),
		
		remainCount: (function() {
			var position = 0;
			var idmap = {};
			
			function clear_idmap() {
				for (var i in idmap) if (idmap.hasOwnProperty(i)) {
					delete idmap[i];
				}
			}
			
			function sum_in_map(m) {
				var sum = 0;
				for (var i in idmap) if (idmap.hasOwnProperty(i)) {
					sum += idmap[i];
				}
				return sum;
			}

			return function(targetList, untilThisTime) {
				// RESET
				if (!targetList) {
					clear_idmap();
					position = 0;
					return 0;
				}
				
				// NEXT
				var tm = this.timeToMapHash;
				for (var i = 0;i < targetList.length;++i) {
					if (position < targetList.length) {
						var target_time = targetList[position];
						if (target_time > untilThisTime) {
							break;
						}
						
						var source_idmap = tm[target_time];
						if (source_idmap) {
							for (var oid in source_idmap) if (source_idmap.hasOwnProperty(oid)) {
								// ID���ƂɍŐV(�ł���)�̒l��ێ����Ă���
								idmap[oid] = source_idmap[oid];
							}
						}


						++position;
					} else {
						break;
					}
				}
				
				// ����idmap�ɓ����Ă���l���W�v���Ԃ�
				return sum_in_map(idmap);
			}
		})(),

		updateTimeList: function() {
			var arr = this.timeListTemp;
			if (this.timeListDirty) {
				arr.length = 0;
			
				var m = this.timeToValHash;
				for (var i in m) if (m.hasOwnProperty(i)) {
					arr.push(i);
				}
			
				arr.sort(function(a, b) { return a - b; });
				this.timeListDirty = false;
			}
			
			return arr;
		}
	};

	var STRIPE_WIDTH = 15;
	function generateStripePattern() {
		var w = STRIPE_WIDTH;
		var h = 30;
		var cv = document.createElement('canvas');
		cv.width = w;
		cv.height = h;
		
		var g = cv.getContext('2d');
		g.fillStyle   = 'rgba(185,185,185,0.25)';
		g.strokeStyle = 'rgba(185,185,185,0.25)';
		g.fillRect(0, 0, w, h);
		g.lineWidth = 4;
		g.moveTo(12, -2);
		g.lineTo(3, h+2);
		g.stroke();
		
		return  cv;
	}

	EventTimeline.Configuration = function() {
		this.type = EventTimeline.Types.RecordCount;
		this.targetAttribute = null;
		this.numLimit = 100;
	};
	
	EventTimeline.Types = {
		RecordCount: 0,
		AttributeSum: 1,
		AttributeRemainSum: 2
	};
	
	EventTimeline.Configuration.prototype = {
		reset: function() {
			this.type = EventTimeline.Types.RecordCount;
			this.targetAttribute = null;
			this.numLimit = 100;
		},
		
		copyFrom: function(src) {
			this.type = src.type;
			this.targetAttribute = src.targetAttribute;
			this.numLimit = src.numLimit;
		},
		
		equals: function(dest) {
			return ( dest.type === this.type ) && 
			       ( dest.targetAttribute === this.targetAttribute ) &&
			       ( dest.numLimit === this.numLimit );
		},

		setNumLimit: function(n) {
			if (n < 0) { n = 0; }
			this.numLimit = n;
		},

		setTargetAttribute: function(attrName) {
			if (attrName !== null && attrName.length < 1) {
				// empty -> null
				attrName = null;
			}
			
			this.targetAttribute = (this.type > 0) ? attrName : null;
		},
		
		shouldUseAttribute: function() {
			return (this.type !== EventTimeline.Types.RecordCount) && !!(this.targetAttribute);
		},
		
		shouldRemainValues: function() {
			return this.shouldUseAttribute() && (this.type === EventTimeline.Types.AttributeRemainSum);
		}
	};

	// Export - - - - - - - -
	pkg.EventTimeline = EventTimeline;
});