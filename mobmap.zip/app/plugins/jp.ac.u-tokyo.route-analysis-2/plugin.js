(function() {
	'use strict';
	var pluginHost = null;
	var thePluginInstance = null;
	var kSelfId = "jp.ac.u-tokyo.route-analysis-2";

	var kGateCategoryOD    = 1;
	var kGateCategoryWay   = 2;

	var kResultCategoryOrigin = 100;
	var kResultCategoryDest   = 200;
	var kResultCategoryMid    = 300;
	
	var kGateSetType_MidOnly    = 0x0;
	var kGateSetType_OrgAndMid  = 0x1;
	var kGateSetType_DestAndMid = 0x2;
	var kGateSetType_Complete   = 0x3;

	function loadPlugin(panelContainer) {
		thePluginInstance = mobmap.PluginUtil.activatePlugin(
			pluginHost,
			panelContainer,
			RouteAnalysis2,
			thePluginInstance,
			mobmap.PluginUtil.InitOption.OBSERVE_GROUP);
	}

	function unloadPlugin() {
		mobmap.PluginUtil.deactivatePlugin(thePluginInstance);
	}

	function RouteAnalysis2() {
		this.lastResultSummary = null;
		this.gateJobs = [];
		this.finishedJobs = [];

		this.groupChooser = null;
		this.routeDisplay = null;
		this.jExecButton = null;
		this.jOpenReportBigButton = null;
		this.element = this.createElementWithTitle('Route Analysis');
		this.jElement = $(this.element);
		this.jErrorBox = null;
		this.welcomeScreenElement = null;
		this.currentGateSet = null;
		this.currentGateSetType = kGateSetType_Complete;

		this.buildForm(this.element);
		this.showWelcomeScreen(this.element);
	}

	RouteAnalysis2.prototype = {
		// Build 'WELCOME' screen = = =
		showWelcomeScreen: function(containerElement) {
			var el = $H('div', 'mm-plugin-welcome');
			
			var content = 
			 '<h3> 経路分析プラグイン</h3>'+
			 '<p>本プラグインは、東京大学柴崎研究室とパシフィックコンサルタンツ株式会社が共同で開発したものです。</p>'+
			 '<ul>'+
			 ' <li>本プラグインを利用した成果物を論文やWebサイト、プレスリリース等一般に公開する資料に掲載する場合「東京大学柴崎研究室およびパシフィックコンサルタンツ株式会社が共同開発したMobmap用経路分析プラグインを利用した」旨を明記して下さい</li>'+
			 ' <li>本プラグインは無保証であり損害賠償等はいたしかねます</li>'+
			 ' <li>この規定は本プラグインを利用した場合のみ適用されます。Mobmap本体のみを利用した場合は、上記の表示は必要ありません</li>'+
			 '</ul>';
			
			var holder = $H('div', 'accept-button-holder');
			var btn = $H('button');
			btn.innerHTML = '以上の条件に同意します';
			$(btn).click( this.onWelcomeButtonClick.bind(this) );
			
			el.innerHTML = content;			
			holder.appendChild(btn);
			el.appendChild(holder);
			containerElement.appendChild(el);
			this.welcomeScreenElement = el;
			return el;
		},

		removeWelcomeScreen: function() {
			var el = this.welcomeScreenElement;
			if (el && el.parentNode) {
				el.parentNode.removeChild(el);
			}
		},

		onWelcomeButtonClick: function() {
			this.removeWelcomeScreen();
			this.showForm();
		},

		// Build main screen = = = = = =
		buildForm: function(containerElement) {
			var formContainer = $H('div', 'mm-routeplugin-after-agreement');
			containerElement.appendChild( formContainer );
			
			this.buildErrorBox(formContainer);
			
			this.groupChooser = mobmap.PluginUtil.createAnalysisItemGroupChooser(
				pluginHost,
				formContainer,
				this,
				'Route'
			);

			var resContainer = $H('div', 'mm-routeplugin-after-agreement mm-routeplugin-result-container');
			containerElement.appendChild(resContainer);
			
			this.routeDisplay = new RouteDisplay();
			resContainer.appendChild( this.routeDisplay.getElement() );
			this.routeDisplay.hide();

			this.jExecButton = $( mobmap.PluginUtil.createBigButton('Execute', formContainer) );
			this.jExecButton.click( this.onExecuteButtonClick.bind(this) );

			this.jOpenReportBigButton = $( mobmap.PluginUtil.createBigButton('Open report', resContainer) );
			this.jOpenReportBigButton.hide();
			this.jOpenReportBigButton.click( this.openReport.bind(this) );

this.debug_putTestButton(containerElement);

			formContainer.style.display = 'none';
			resContainer.style.display = 'none';
		},
		
		showForm: function() {
			this.jElement.find('.mm-routeplugin-after-agreement').show();
		},

		buildErrorBox: function(containerElement) {
			var el = $H('div', 'mm-routeplugin-error-display');
			this.jErrorBox = $(el).text('No error');
			this.jErrorBox.hide();
			
			containerElement.appendChild(el);
		},
		
		showError: function(messageId) {
			this.jErrorBox.show().text( kErrorMessages[messageId] );
		},
		
		hideError: function() {
			this.jErrorBox.hide();
		},


		// Toggle visibility of execute button automatically
		// 実行ボタンが押せる状況であればボタンを表示する
		toggleExecuteButtonVisibility: function() {
			this.jExecButton;
		},

		checkCanExecute: function() {
			
		},



		debug_putTestButton: function(containerElement) {
			var btn = $H('button');
			$(btn).text("Report window test").click( this.openReportTestWindow.bind(this) );
			containerElement.appendChild(btn);
			
// ***************
btn.style.display = 'none';
		},
		
		openReport: function() {
			this.openReportTestWindow();
		},

		openReportTestWindow: function() {
			var dat = ResultTestData;
			if (this.lastResultSummary) {
				dat = this.lastResultSummary.export( this.currentGateSetType === kGateSetType_MidOnly );
			}
			pluginHost.openReportWindow('report/sroute-report.html', dat, kSelfId);
		},

		onGroupAdded: function(sensorPool, addedItem) { this.groupChooser.onGroupAdded(sensorPool, addedItem); },
		onGroupTitleChanged: function(changedItem) { this.groupChooser.onGroupTitleChanged(changedItem); },

		clearPreviousResult: function() {
			this.lastResultSummary = null;
			this.routeDisplay.hide();

			this.gateJobs.length = 0;
			this.finishedJobs.length = 0;
			this.currentGateSet = null;
		},

		onExecuteButtonClick: function() {
			var U = mobmap.PluginUtil;
			this.clearPreviousResult();
			this.jOpenReportBigButton.hide(); // toggle visibility
			
			var groupConditionList = [
				{
					numOfRoutes: 4,
					form: mobmap.ALGroupItem.GroupForm.Stack_141,
					conditions: [
						U.kGourpFilterPolygon | U.kGourpFilterOptional,
						U.kGourpFilterLine,
						U.kGourpFilterLine,
						U.kGourpFilterLine,
						U.kGourpFilterLine,
						U.kGourpFilterPolygon | U.kGourpFilterOptional,
					]
				},
				{
					numOfRoutes: 3,
					form: mobmap.ALGroupItem.GroupForm.Stack_131,
					conditions: [
						U.kGourpFilterPolygon | U.kGourpFilterOptional,
						U.kGourpFilterLine,
						U.kGourpFilterLine,
						U.kGourpFilterLine,
						U.kGourpFilterPolygon | U.kGourpFilterOptional,
					]
				},
				{
					numOfRoutes: 2,
					form: mobmap.ALGroupItem.GroupForm.Stack_121,
					conditions: [
						U.kGourpFilterPolygon | U.kGourpFilterOptional,
						U.kGourpFilterLine,
						U.kGourpFilterLine,
						U.kGourpFilterPolygon | U.kGourpFilterOptional,
					]
				}
			];
			
			this.showError('no_sel');

			if (!this.validateSelectedLayer()) {
				return;
			}

			var foundType = this.validateSelectedGroup(groupConditionList);
			if (foundType < 0) {
				console.log("BAD FORM");
			} else {
				this.hideError();
				
				console.log("index " + foundType + "\n", "routes:" + groupConditionList[foundType].numOfRoutes);
				this.currentGateSet = this.buildGateSet( groupConditionList[foundType].numOfRoutes );
				// +++++++  MID ONLY  or  COMPLETE ?  +++++++
				this.currentGateSetType = this.determineGateSetType( this.currentGateSet );
				
				// Check gate-set type (and show error)
				if (this.currentGateSetType !== kGateSetType_Complete && 
					this.currentGateSetType !== kGateSetType_MidOnly  ) {
					this.showError('incmp_set');
				} else {
					this.routeDisplay.initFromGroutSet(this.currentGateSet);
				
					this.buildJobList(this.currentGateSet);
					this.startFirstJobInList();
				}
			}
		},

		validateSelectedLayer: function() {
			var lyr = pluginHost.getOwnerApp().getSelectedLayer();
			if (!lyr) { return false; }
			
			return !!(lyr.movingData);
		},

		validateSelectedGroup: function(groupConditionList) {
			var groupId = this.groupChooser.getValue();
			if (groupId === null) {
				// bad selection
			} else {
				return mobmap.PluginUtil.validateGroupItems(pluginHost, groupId, groupConditionList);
			}
			
			return -1;
		},

		getGroupItemOfId: function(groupId) { return mobmap.PluginUtil.getGroupItemOfId(pluginHost, groupId); },

		buildGateSet: function(numOfRoutes) {
			var addsub = this.setSubGroupIfExist;
			var groupId = this.groupChooser.getValue();
			var gr = this.getGroupItemOfId(groupId);

			var gs = {
				origins: [],
				destinations: [],
				routesList: []
			};
			
			addsub(gs.origins, gr, 0);
			addsub(gs.destinations, gr, numOfRoutes+1);

			for (var i = 0;i < numOfRoutes;++i) {
				var subgIndex = i + 1;
				var aRoute = [];
				addsub(aRoute, gr, subgIndex);

				gs.routesList.push(aRoute);
			}
			
			return gs;
		},

		determineGateSetType: function(gateSet) {
			var hasOrigin = gateSet.origins.length > 0;
			var hasDest   = gateSet.destinations.length > 0;
			
			var t = kGateSetType_MidOnly;
			if (hasOrigin) { t |= kGateSetType_OrgAndMid; }
			if (hasDest) { t |= kGateSetType_DestAndMid; }
			
			return t;
		},

		setSubGroupIfExist: function(outList, group, subGroupIndex) {
			outList.length = 0;
			var ls = group.getSubGroupAt(subGroupIndex);
			if (!ls) {
				return 0;
			}
			
			var len = ls.length;
			for (var i = 0;i < len;++i) {
				outList.push( ls[i] );
			}
			
			return len;
		},
		
		// JOB BUILDER AND RUNNER - - - - - - - - - - -
		buildJobList: function(gateSet) {
			var rls     = gateSet.routesList;
			var nRoutes = rls.length;

			for (var i = 0;i < nRoutes;++i) {
				var midSubGroup = rls[i];
				this.appendJobFromList(midSubGroup, kGateCategoryWay);
			}

			var sgOrigin = gateSet.origins;
			var sgDest   = gateSet.destinations;

			this.appendJobFromList(sgOrigin, kGateCategoryOD);
			this.appendJobFromList(sgDest, kGateCategoryOD);
			
			mobmap.PluginUtil.setJobSequenceIndices( this.gateJobs );
		},

		appendJobFromList: function(gateList, gateCategory) {
			mobmap.PluginUtil.createJobFromList(
				pluginHost,
				this.gateJobs,
				gateList,
				this.whenAJobFinished, this, gateCategory); 
		},

		startFirstJobInList: function() {
			mobmap.PluginUtil.startFirstJobInList(this.gateJobs);
		},
		
		whenAJobFinished: function(finishedJob) {
			mobmap.PluginUtil.moveJobToFinishedList(finishedJob, this.gateJobs, this.finishedJobs);
			
			if (this.gateJobs.length > 0) {
				this.startFirstJobInList();
			} else {
				this.allJobsFinished();
			}
		},
		
		// FINISH ***********************************************
		allJobsFinished: function() {
			var queryNumRoutes = this.currentGateSet.routesList.length;
			
			console.log("Done.", queryNumRoutes);
			
			var tripList = this.extractTrips( this.currentGateSet );
			var resultSummary = new ResultSummary(tripList);
			
			this.showResultSummary(resultSummary, queryNumRoutes);
//			console.log(JSON.stringify(resultSummary.export() , null, '\t'));
			this.lastResultSummary = resultSummary;
			
			this.jOpenReportBigButton.show(); // toggle visibility
			this.openReport();
		},
		
		showResultSummary: function(resultSummary, numOfRoutes) {
			this.routeDisplay.show();
			var disp = this.routeDisplay;
			disp.initAllRoutes(numOfRoutes);

			var nAll = resultSummary.count();

			resultSummary.eachRoute(function(routeIndex, tripCount) {
				disp.setRouteTripCount(routeIndex, tripCount, Math.floor(0.5 + 100.0 * tripCount / nAll));
			});
		},

		// Analyze and Report ======================================================
		extractTrips: function(gateSet) {
			var resultTimeline = [];
			var IDmap = {};
			var nRoutes = gateSet.routesList.length;
			
			// Pick up gate results and build timeline - - - - -
			
			this.gatherODGateMatches(IDmap, resultTimeline, gateSet.origins, kResultCategoryOrigin);
			this.gatherODGateMatches(IDmap, resultTimeline, gateSet.destinations, kResultCategoryDest);
			
			for (var i = 0;i < nRoutes;++i) {
				var r = gateSet.routesList[i];
				this.gatherMidGateMatches(IDmap, resultTimeline, r, i);
			}
			
			// Extract trips from the timeline - - - - -

			var tripList = [];
			this.sortResultTimeline(resultTimeline);
			this.traceTimeline(tripList, IDmap, resultTimeline);
			
			return tripList;
		},
		
		gatherODGateMatches: function(outIDmap, outTimeline, gateList, resultCategory) {
			var len = gateList.length;
			for (var i = 0;i < len;++i) {
				var gate = gateList[i];
				var job = this.findJobFromGate(gate);
				
				this.addODResult(outIDmap, outTimeline, job.resultBuffer, resultCategory);
			}
		},

		gatherMidGateMatches: function(outIDmap, outTimeline, gateList, routeIndex) {
			var len = gateList.length;
			for (var i = 0;i < len;++i) {
				var gate = gateList[i];
				var job = this.findJobFromGate(gate);
				
				this.addMidResult(outIDmap, outTimeline, job.resultBuffer, routeIndex, i);
			}
		},

		findJobFromGate: function(gate) {
			var ls = this.finishedJobs;
			var len = ls.length;
			for (var i = 0;i < len;++i) {
				var j = ls[i];
				
				if (j.gate === gate) {
					return j;
				}
			}
			
			return null;
		},
		
		addODResult: function(outIDmap, outTimeline, resultBuffer, resultCategory) {
			var len = resultBuffer.length;
			for (var i = 0;i < len;++i) {
				var item = resultBuffer[i];
				if (item.type === mobmap.GateResultType.PolygonGateEdgePassed) {
					var r1 = item.firstRecord;
					var pid = r1.id;
					if (!item.passedDate) {
						item.passedDate = calcPassedTime(item);
					}

					item.ownerId = pid;
					item.resultCategory = resultCategory;
					outTimeline.push(item);

					// Register found ID
					if (!outIDmap[ pid ]) {
						outIDmap[ pid ] = 0;
					}
					outIDmap[ pid ] += 1;
				}
			}
		},

		addMidResult: function(outIDmap, outTimeline, resultBuffer, routeIndex, midGateIndex) {
			var len = resultBuffer.length;
			for (var i = 0;i < len;++i) {
				var item = resultBuffer[i];
				if (item.type === mobmap.GateResultType.LineGatePassed) {
					var r1 = item.firstRecord;
					var pid = r1.id;
					if (!item.passedDate) {
						item.passedDate = calcPassedTime(item);
					}

					item.ownerId = pid;
					item.routeIndex = routeIndex;
					item.midGateIndex = midGateIndex;
					item.resultCategory = kResultCategoryMid;
					outTimeline.push(item);

					// Register found ID
					if (!outIDmap[ pid ]) {
						outIDmap[ pid ] = 0;
					}
					outIDmap[ pid ] += 1;
				}
			}
		},

		sortResultTimeline: function(tl) {
			tl.sort(function(a,b) {
				return a.passedDate - b.passedDate;
			});
		},


		traceTimeline: function(outTripList, idmap, tl) {
			for (var pid in idmap) if (idmap.hasOwnProperty(pid)) {
				this.traceTimelineOfId(outTripList, tl, pid);
			}
		},
		
		// traceTimeline -> traceTimelineOfId
		
		traceTimelineOfId: function(outTripList, tl, pid) {
			// console.log(this.currentGateSetType)
			
			if (this.currentGateSetType === kGateSetType_Complete) {
				this.traceTimelineOfId_with_CompleteGateSet(outTripList, tl, pid);
			} else if (this.currentGateSetType === kGateSetType_MidOnly) {
				this.traceTimelineOfId_with_MidOnly(outTripList, tl, pid);
			} else if (this.currentGateSetType === kGateSetType_DestAndMid) {
				this.traceTimelineOfId_with_DestAndMid(outTripList, tl, pid);
			}
		},

		// TRIP EXTRACTION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

		traceTimelineOfId_with_CompleteGateSet: function(outTripList, tl, pid) {
			var nFoundItems = 0;
			
			var ctx = {
				prevODcat: null,
				prevODindex: -1
			};
			
			var len = tl.length;
			for (var i = 0;i < len;++i) {
				var resultEntry = tl[i];
				if (resultEntry.ownerId == pid) {
					var cat = resultEntry.resultCategory;
					if (cat === kResultCategoryDest || cat === kResultCategoryOrigin) {
						if (ctx.prevODcat) {
							var count = (i - ctx.prevODindex) + 1;
							// check: is O->D or D->O change?
							
							// prev=O and current=D  or 
							// prev=D and current=O
							
							if (ctx.prevODcat !== resultEntry.resultCategory) {
								var passmap = this.traceTimelineBetweenOD(tl, pid, ctx.prevODindex, count);
								// Check reversed trip
								if (ctx.prevODcat === kResultCategoryDest && 
									          cat === kResultCategoryOrigin) {
									passmap.reversed = true;
								}

								this.generateTripFromPassMap(outTripList, passmap);
							}
						} 

						ctx.prevODcat = resultEntry.resultCategory;
						ctx.prevODindex = i;
					}

					++nFoundItems;
				}
			}
		},

		traceTimelineBetweenOD: function(tl, pid, startIndex, count) {
			var passedMap = new RoutePassedMap(pid);
			var tripItemList = [];
			
			var prevDestIndex = -1;
			
			for (var i = 0;i < count;++i) {
				var itemIndex = startIndex + i;
				var item = tl[itemIndex];
				if (item.ownerId == pid) {
					if (item.type === mobmap.GateResultType.LineGatePassed) {
						passedMap.mark(item);
					}
					
					tripItemList.push(item);
				}
			}
			
			passedMap.setTripItemList(tripItemList);
			return passedMap;
		},


		traceTimelineOfId_with_DestAndMid: function(outTripList, tl, pid) {
			var len = tl.length;
			for (var i = 0;i < len;++i) {
				var resultEntry = tl[i];
				if (resultEntry.ownerId == pid) {

					var cat = resultEntry.resultCategory;

				}
			}
		},

		// MID GATE(Route) ONLY | | | | | | | | | | | | | | | | | | | | |
		traceTimelineOfId_with_MidOnly: function(outTripList, tl, pid) {
			var currentRouteContext = null;

			var len = tl.length;

			for (var i = 0;i < len;++i) {
				var resultEntry = tl[i];
				if (resultEntry.ownerId == pid) {

					var cat = resultEntry.resultCategory;
					if (cat === kResultCategoryMid) {
						var midg_RouteIndex = resultEntry.routeIndex;
						var numMidGates = this.getCurrentRouteMidGatesCount(midg_RouteIndex);
						//console.log(resultEntry.midGateIndex, "  R=", midg_RouteIndex, " N=", numMidGates);

						if (!currentRouteContext) {
							// new route
							currentRouteContext = {
								pid:  pid,
								passedItem: [resultEntry],
								routeIndex: midg_RouteIndex,
								gateMap: {} // <- Put indices of passed gate
							};
							
							currentRouteContext.gateMap[ resultEntry.midGateIndex ] = 1; // MARK (1st result)
						} else {
							
							// check same route?
							if (midg_RouteIndex !== currentRouteContext.routeIndex) {
								// Route changed!
								// v v v v v v v
								// CHECK PASSED GATES
								this.addMidOnlyTripIf(outTripList, currentRouteContext, numMidGates);
								currentRouteContext = null; // remove old route
							} else {
								// same route (next result)
								currentRouteContext.passedItem.push( resultEntry ); // add item
								currentRouteContext.gateMap[ resultEntry.midGateIndex ] = 1; // MARK
							}
						}
						
					}

				}
			}
			
			// CHECK PASSED GATES(FIN)
			if (currentRouteContext) {
				this.addMidOnlyTripIf(outTripList, currentRouteContext, numMidGates);
			}
		},

		addMidOnlyTripIf: function(outTripList,  routeContext, numOfMidGates) {
			if (this.checkMidOnlyGatesCompleted(routeContext, numOfMidGates)) {
				console.log("PASSED")
				
				// Create new ResultTrip object
				
				var trip = new ResultTrip(
						routeContext.pid,
						routeContext.passedItem,
						routeContext.routeIndex,
						false // not used
					);

				outTripList.push(trip);
				return true;
			} else {
//				console.log("-- incomplete --")
				
			}
			
			return false;
		},

		checkMidOnlyGatesCompleted: function(routeContext, numOfMidGates) {
			var m = routeContext.gateMap;
			for (var i = 0;i < numOfMidGates;++i) {
				if ( !(m[i]) ) {
					return false;
				}
			}
			
			return true;
		},


		// Trip generator for COMPLETE mode
		generateTripFromPassMap: function(outTripList, pmap) {
			var nRoutes = this.getCurrentRoutesCount();
			var i;

			for (i = 0;i < nRoutes;++i) {
				var numMidGates = this.getCurrentRouteMidGatesCount(i);
				var passed = pmap.validateAllPassed(i, numMidGates);
				
				if (passed) {
					var trip = new ResultTrip(pmap.pid, pmap.tripItemList, i, pmap.reversed);
					outTripList.push(trip);
					console.log(i, pmap.pid, pmap.tripItemList.length, pmap.reversed ? '<=' : '->');
				}
			}
			
		},

		// Trip generator for MID-ONLY mode
		generateTripFromTripItemList: function(outTripList,  pid, tripItemList, routeIndex) {
			//                                                        vvv  not used
			var trip = new ResultTrip(pid, tripItemList, routeIndex, false);
			outTripList.push(trip);
		},


		getCurrentRoutesCount: function() {
			return this.currentGateSet.routesList.length;
		},
		
		getCurrentRouteMidGatesCount: function(routeIndex) {
			var r = this.currentGateSet.routesList[routeIndex];
			if (!r) { return 0; }
			
			return r.length;
		}
	}
	
	function RoutePassedMap(pid) {
		this.tripItemList = null;
		this.reversed = false;
		this.pid = pid;
		this.m = {};
	}

	RoutePassedMap.prototype = {
		mark: function(resultItem) {
			this.m[ this.makeKey(resultItem.routeIndex, resultItem.midGateIndex) ] = 1;
		},
		
		setTripItemList: function(ls) {
			this.tripItemList = ls;
		},

		validateAllPassed: function(routeIndex, numGates) {
			for (var i = 0;i < numGates;++i) {
				var k = this.makeKey( routeIndex, i );
				if (!(this.m[k])) {
					return false;
				}
			}
			
			return true;
		},

		makeKey: function(routeIndex, gateIndex) {
			return (routeIndex * 1000) + gateIndex;
		}
	};


	function ResultTrip(pid, tripItemList, routeIndex, reversed) {
		this.pid = pid;
		this.routeIndex = routeIndex;
		this.tripItemList = tripItemList;
		this.reversed = reversed;
	}
	
	ResultTrip.prototype = {
		export: function() {
			var xobj = {
				pid:          this.pid,
				routeIndex:   this.routeIndex,
				reversed:     this.reversed,
				tripItemList: []
			};

			var srcList = this.tripItemList;
			for (var i = 0;i < srcList.length;++i) {
				var s = srcList[i];
				xobj.tripItemList.push({
					passedDate: s.passedDate - 0,
					resultCategory: s.resultCategory 
				});
			}
			
			return xobj;
		}
	};


	function ResultSummary(tripList) {
		this.tripCountMap = {};
		this.traverse(tripList);
		
		this.tripList = tripList;
	}

	ResultSummary.prototype = {
		count: function() {
			return this.tripList.length;
		},
		
		export: function(midOnly) {
			var xobj = {
				midOnly: !!midOnly ,
				numOfRoutes: this.getNumOfRoutes(),
				tripList:[]
			};
			
			var src = this.tripList;
			for (var i = 0;i < src.length;++i) {
				xobj.tripList.push( src[i].export() );
			}
			
			return xobj;
		},
		
		traverse: function(tripList) {
			var len = tripList.length;
			for (var i = 0;i < len;++i) {
				var trip = tripList[i];
				var ri = trip.routeIndex;
				
				if (!this.tripCountMap[ri]) {
					this.tripCountMap[ri] = 1;
				} else {
					this.tripCountMap[ri] += 1;
				}
			}
		},
		
		eachTrip: function(callback) {
			var ls = this.tripList;
			for (var i = 0;i < ls.length;++i) {
				callback(i, ls[i]);
			}
		},
		
		eachRoute: function(callback) {
			var m = this.tripCountMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				callback(i-0, m[i]);
			}
 		},

		getNumOfRoutes: function() {
			var m = 0;
			this.eachRoute(function(index, usage) {
				m = Math.max(m, index+1);
			});
			
			return m;
		},
		
		getRatioList: function() {
			var nRoutes = this.getNumOfRoutes();
			var resArray = new Array(nRoutes);
			var i;
			var sum = 0;
			
			for (i = 0;i < nRoutes;++i) {
				sum += this.tripCountMap[i];
			}

			if (sum === 0) { sum = 1; }

			for (i = 0;i < nRoutes;++i) {
				resArray = this.tripCountMap[i] / sum;
			}
			
			return resArray;
		}
	};

	// RouteDisplay =============================================================
	function RouteDisplay() {
		this.element = $H('table', 'mm-routeplugin-route-table');
		
		this.counterBoxList = [];
	}

	RouteDisplay.prototype = {
		show: function() {
			this.element.style.display = '';
		},
		
		hide: function() {
			this.element.style.display = 'none';
		},
		
		
		getElement: function() {
			return this.element;
		},

		clear: function() {
			this.counterBoxList.length = 0;
			this.element.innerHTML = '';
		},
		
		initFromGroutSet: function(gs) {
			this.clear();

			var rls = gs.routesList;
			var nRoutes = rls.length;
			
			this.addTermRow('ORIGIN', gs.origins, nRoutes, 'mm-routeplugin-org-cell');
			var mid_tr = $H('tr', 'mm-routeplugin-mid-row mm-routeplugin-mid-row-' +nRoutes+ 'routes');
			this.element.appendChild(mid_tr);
			this.addTermRow('DEST', gs.destinations, nRoutes, 'mm-routeplugin-dest-cell');
			
			for (var i = 0;i < nRoutes;++i) {
				this.addRouteCol(mid_tr, rls[i], i);
			}
			
			// set route count
			this.element.setAttribute('data-num-routes', nRoutes);
		},
		
		addTermRow: function(caption, gateList, nRoutes, addClass) {
			var tr = $H('tr');
			var td = $H('td', addClass);
			td.setAttribute('colspan', nRoutes);
			
			var h = $H('h3');
			h.appendChild( $T(caption) );
			td.appendChild(h);

			td.appendChild( this.generateGateNamesDisp( gateList ) );
			
			tr.appendChild(td);
			this.element.appendChild(tr);
		},
		
		addRouteCol: function(tr, gateList, routeIndex) {
			var routeLetter = mobmap.PluginUtil.indexToAlphabetical(routeIndex);
			var td = $H('td', 'mm-routeplugin-routecol-' + routeLetter);
			var h = $H('h3', 'mm-routeplugin-route-heading');
			h.innerHTML = '<span>route</span>' + routeLetter;
			td.appendChild(h);
			
			var ct = $H('div', 'mm-routeplugin-route-counter');
			h.appendChild(ct);
			this.counterBoxList.push(ct);
			
			td.appendChild( this.generateGateNamesDisp( gateList ) );
			
			tr.appendChild(td);
		},
		
		getCombinedNames: function(gateList) {
			var parts = [];
			for (var i = 0;i < gateList.length;++i) {
				parts.push( gateList[i].getTitle() );
			}
			
			return parts.join(', ');
		},
		
		generateGateNamesDisp: function(gateList) {
			var label = '(None)';
			if (gateList && gateList.length > 0) {
				label = this.getCombinedNames(gateList);
			}
			var s = $H('span', 'mm-routeplugin-route-gate-name');

			s.appendChild($T(label));
			return s;
		},
		
		initAllRoutes: function(n) {
			for (var i = 0;i < n;++i) {
				this.setRouteTripCount(i, 0, 0);
			}
		},
		
		setRouteTripCount: function(routeIndex, usage, percentage) {
			var box = this.counterBoxList[routeIndex];
			if (!box) { return; }
			
			box.innerHTML = '';
			
			var t = $H('span', 'mm-routeplugin-route-counter-amount');
			if (usage === 1) {
				t.appendChild($T( usage + ' trip' ));
			} else {
				t.appendChild($T( usage + ' trips' ));
			}
			box.appendChild(t);

			var ratio = $H('span', 'mm-routeplugin-route-counter-ratio');
			ratio.appendChild($T( percentage + '%' ));
			box.appendChild(ratio);
		}
	};

	function calcPassedTime(resultEntry) {
		var r1 = resultEntry.firstRecord;
		var r2 = resultEntry.secondRecord;

		var t = (1.0 - resultEntry.ratio) * r1.time  +  resultEntry.ratio * r2.time;
		var date = new Date( t * 1000.0 );
		return date;
	}

	// inherit < < < <
	mobmap.PluginUtil.installBaseElementMethods(RouteAnalysis2.prototype);

	// register - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	
	var kPluginIconData = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0'+
	  'NAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAB3RJTUUH4AoNByg0G+w9xAAAAJpJ'+
	  'REFUOMvt0zEOQUEQxvHf8jyJEyg0ruEg7kGldQE3UKmcRkEItc4JJORptnjFytsgqvdPNjvJTL6Z2Zml5R+Uq'+
	  'OIpm4I7v87eCiYJb+wkRYbYHQc8ov1VhRUu2GGD06fPMMQKR2xrvgXOmGKCbo5ggWVscZ/wr/GMdza3WrujWH'+
	  'VAH9faz8ma6ADzjMnOMM5dvV7DioQY08ILNOIZgvlasuYAAAAASUVORK5CYII=';

	pluginHost = mobmap.registerPlugin({
		"id": kSelfId,
		"title": "Route analysis 2",
		"category": mobmap.PluginTypes.AnalysisPanel,
		"tool-icon": kPluginIconData,
		"load": loadPlugin,
		"unload": unloadPlugin,
		"stylesheets": ['sroute.css']
	});
	
	

	var kErrorMessages = {
		'no_sel': "ゲートグループを選択してから実行して下さい。",
		'incmp_set': "出発地、到着地どちらか一方のみの指定はできません。どちらも指定せずに経由地のみで分析を行うことは可能です。"
	};

	// TEST DATA *************************************************************

	var ResultTestData = {
		"midOnly": false,
		"numOfRoutes": 2,
		"tripList": [
			{
				"pid": "341200",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907197405521,
						"resultCategory": 200
					},
					{
						"passedDate": 907197961394,
						"resultCategory": 300
					},
					{
						"passedDate": 907198127921,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "435800",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907200415365,
						"resultCategory": 200
					},
					{
						"passedDate": 907201136884,
						"resultCategory": 300
					},
					{
						"passedDate": 907201352942,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "451500",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907197795891,
						"resultCategory": 100
					},
					{
						"passedDate": 907198173313,
						"resultCategory": 300
					},
					{
						"passedDate": 907199433455,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "481600",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907205803844,
						"resultCategory": 200
					},
					{
						"passedDate": 907206618760,
						"resultCategory": 300
					},
					{
						"passedDate": 907206862873,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "494700",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907195061361,
						"resultCategory": 200
					},
					{
						"passedDate": 907195584877,
						"resultCategory": 300
					},
					{
						"passedDate": 907195741793,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "533500",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907192788433,
						"resultCategory": 200
					},
					{
						"passedDate": 907193542727,
						"resultCategory": 300
					},
					{
						"passedDate": 907193768666,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "540000",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907209384386,
						"resultCategory": 200
					},
					{
						"passedDate": 907210753479,
						"resultCategory": 300
					},
					{
						"passedDate": 907211163512,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "540000",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907220194684,
						"resultCategory": 100
					},
					{
						"passedDate": 907220442696,
						"resultCategory": 300
					},
					{
						"passedDate": 907221270382,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "562800",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907195023200,
						"resultCategory": 200
					},
					{
						"passedDate": 907195444541,
						"resultCategory": 300
					},
					{
						"passedDate": 907195570787,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "576800",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907197608561,
						"resultCategory": 200
					},
					{
						"passedDate": 907198360400,
						"resultCategory": 300
					},
					{
						"passedDate": 907198585687,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "632500",
				"routeIndex": 1,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907214126359,
						"resultCategory": 100
					},
					{
						"passedDate": 907214397377,
						"resultCategory": 300
					},
					{
						"passedDate": 907215503051,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "632900",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907202815710,
						"resultCategory": 100
					},
					{
						"passedDate": 907202995476,
						"resultCategory": 300
					},
					{
						"passedDate": 907203595484,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "642900",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907192971928,
						"resultCategory": 200
					},
					{
						"passedDate": 907193741174,
						"resultCategory": 300
					},
					{
						"passedDate": 907193971549,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "664800",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907195253023,
						"resultCategory": 200
					},
					{
						"passedDate": 907196271189,
						"resultCategory": 300
					},
					{
						"passedDate": 907196576085,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "696500",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907194691077,
						"resultCategory": 100
					},
					{
						"passedDate": 907194902525,
						"resultCategory": 300
					},
					{
						"passedDate": 907195607984,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "698200",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907196172151,
						"resultCategory": 100
					},
					{
						"passedDate": 907196457642,
						"resultCategory": 300
					},
					{
						"passedDate": 907197410650,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "699000",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907200160347,
						"resultCategory": 100
					},
					{
						"passedDate": 907200385191,
						"resultCategory": 300
					},
					{
						"passedDate": 907201135775,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "699900",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907195641064,
						"resultCategory": 100
					},
					{
						"passedDate": 907195913116,
						"resultCategory": 300
					},
					{
						"passedDate": 907196821634,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "700700",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907198632165,
						"resultCategory": 100
					},
					{
						"passedDate": 907198837504,
						"resultCategory": 300
					},
					{
						"passedDate": 907199523194,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "700800",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907195919910,
						"resultCategory": 100
					},
					{
						"passedDate": 907196332613,
						"resultCategory": 300
					},
					{
						"passedDate": 907197643833,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "700900",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907193047095,
						"resultCategory": 100
					},
					{
						"passedDate": 907196392784,
						"resultCategory": 300
					},
					{
						"passedDate": 907198092525,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "701000",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907196559111,
						"resultCategory": 100
					},
					{
						"passedDate": 907196806306,
						"resultCategory": 300
					},
					{
						"passedDate": 907197631252,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "701900",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907198596661,
						"resultCategory": 100
					},
					{
						"passedDate": 907198819066,
						"resultCategory": 300
					},
					{
						"passedDate": 907199612417,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "702300",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907193036787,
						"resultCategory": 100
					},
					{
						"passedDate": 907193232847,
						"resultCategory": 300
					},
					{
						"passedDate": 907193930195,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "702800",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907193269572,
						"resultCategory": 100
					},
					{
						"passedDate": 907193619424,
						"resultCategory": 300
					},
					{
						"passedDate": 907194787698,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "706100",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907205123695,
						"resultCategory": 100
					},
					{
						"passedDate": 907205337536,
						"resultCategory": 300
					},
					{
						"passedDate": 907206051117,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "707800",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907197661613,
						"resultCategory": 100
					},
					{
						"passedDate": 907197946227,
						"resultCategory": 300
					},
					{
						"passedDate": 907199067029,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "715200",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907201861599,
						"resultCategory": 100
					},
					{
						"passedDate": 907202138551,
						"resultCategory": 300
					},
					{
						"passedDate": 907203124033,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "719900",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907198673592,
						"resultCategory": 100
					},
					{
						"passedDate": 907199031326,
						"resultCategory": 300
					},
					{
						"passedDate": 907200225683,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "720600",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907204363009,
						"resultCategory": 100
					},
					{
						"passedDate": 907204566847,
						"resultCategory": 300
					},
					{
						"passedDate": 907205246956,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "721200",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907197622746,
						"resultCategory": 100
					},
					{
						"passedDate": 907197873566,
						"resultCategory": 300
					},
					{
						"passedDate": 907198768124,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "722400",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907196610202,
						"resultCategory": 100
					},
					{
						"passedDate": 907196825847,
						"resultCategory": 300
					},
					{
						"passedDate": 907197545979,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "723200",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907194768068,
						"resultCategory": 100
					},
					{
						"passedDate": 907195065592,
						"resultCategory": 300
					},
					{
						"passedDate": 907196058892,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "723300",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907198260368,
						"resultCategory": 100
					},
					{
						"passedDate": 907198500866,
						"resultCategory": 300
					},
					{
						"passedDate": 907199303598,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "723400",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907201113896,
						"resultCategory": 100
					},
					{
						"passedDate": 907201316860,
						"resultCategory": 300
					},
					{
						"passedDate": 907201994390,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "725400",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907201819695,
						"resultCategory": 100
					},
					{
						"passedDate": 907202081532,
						"resultCategory": 300
					},
					{
						"passedDate": 907202955660,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "726100",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907195966796,
						"resultCategory": 100
					},
					{
						"passedDate": 907196150457,
						"resultCategory": 300
					},
					{
						"passedDate": 907196763779,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "726600",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907200112899,
						"resultCategory": 100
					},
					{
						"passedDate": 907200291187,
						"resultCategory": 300
					},
					{
						"passedDate": 907200885699,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "727800",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907196360667,
						"resultCategory": 100
					},
					{
						"passedDate": 907196625162,
						"resultCategory": 300
					},
					{
						"passedDate": 907197507997,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "728800",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907194039530,
						"resultCategory": 100
					},
					{
						"passedDate": 907194316276,
						"resultCategory": 300
					},
					{
						"passedDate": 907195239991,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "731500",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907201385399,
						"resultCategory": 100
					},
					{
						"passedDate": 907201643803,
						"resultCategory": 300
					},
					{
						"passedDate": 907202506167,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "739100",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907192014358,
						"resultCategory": 100
					},
					{
						"passedDate": 907192218727,
						"resultCategory": 300
					},
					{
						"passedDate": 907192900300,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "741100",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907198916558,
						"resultCategory": 100
					},
					{
						"passedDate": 907199119871,
						"resultCategory": 300
					},
					{
						"passedDate": 907199797921,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "742500",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907197726672,
						"resultCategory": 100
					},
					{
						"passedDate": 907197935111,
						"resultCategory": 300
					},
					{
						"passedDate": 907198630980,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "743000",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907201405149,
						"resultCategory": 100
					},
					{
						"passedDate": 907201682703,
						"resultCategory": 300
					},
					{
						"passedDate": 907202609207,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "763800",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907196991488,
						"resultCategory": 100
					},
					{
						"passedDate": 907197187717,
						"resultCategory": 300
					},
					{
						"passedDate": 907197843053,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "764900",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907202835006,
						"resultCategory": 100
					},
					{
						"passedDate": 907203058294,
						"resultCategory": 300
					},
					{
						"passedDate": 907203803510,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "770800",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907197308322,
						"resultCategory": 100
					},
					{
						"passedDate": 907197557725,
						"resultCategory": 300
					},
					{
						"passedDate": 907198390457,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "771300",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907196602675,
						"resultCategory": 100
					},
					{
						"passedDate": 907196804380,
						"resultCategory": 300
					},
					{
						"passedDate": 907197477802,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "777800",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907200299006,
						"resultCategory": 100
					},
					{
						"passedDate": 907200436094,
						"resultCategory": 300
					},
					{
						"passedDate": 907200893445,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "778200",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907199077182,
						"resultCategory": 100
					},
					{
						"passedDate": 907199304051,
						"resultCategory": 300
					},
					{
						"passedDate": 907200061674,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "778900",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907194279576,
						"resultCategory": 100
					},
					{
						"passedDate": 907194524928,
						"resultCategory": 300
					},
					{
						"passedDate": 907195343848,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "781400",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907194410062,
						"resultCategory": 100
					},
					{
						"passedDate": 907194655234,
						"resultCategory": 300
					},
					{
						"passedDate": 907195473414,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "783400",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907204732559,
						"resultCategory": 100
					},
					{
						"passedDate": 907204903340,
						"resultCategory": 300
					},
					{
						"passedDate": 907205473415,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "783500",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907205865847,
						"resultCategory": 100
					},
					{
						"passedDate": 907206001834,
						"resultCategory": 300
					},
					{
						"passedDate": 907206454665,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "783500",
				"routeIndex": 0,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907217144868,
						"resultCategory": 200
					},
					{
						"passedDate": 907217726125,
						"resultCategory": 300
					},
					{
						"passedDate": 907217900273,
						"resultCategory": 100
					}
				]
			},
			{
				"pid": "783900",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907196686935,
						"resultCategory": 100
					},
					{
						"passedDate": 907196921478,
						"resultCategory": 300
					},
					{
						"passedDate": 907197757463,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "786400",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907196499419,
						"resultCategory": 100
					},
					{
						"passedDate": 907196724434,
						"resultCategory": 300
					},
					{
						"passedDate": 907197475577,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "789600",
				"routeIndex": 0,
				"reversed": false,
				"tripItemList": [
					{
						"passedDate": 907197321307,
						"resultCategory": 100
					},
					{
						"passedDate": 907197580568,
						"resultCategory": 300
					},
					{
						"passedDate": 907198446291,
						"resultCategory": 200
					}
				]
			},
			{
				"pid": "790400",
				"routeIndex": 1,
				"reversed": true,
				"tripItemList": [
					{
						"passedDate": 907202081287,
						"resultCategory": 200
					},
					{
						"passedDate": 907203579763,
						"resultCategory": 300
					},
					{
						"passedDate": 907203936054,
						"resultCategory": 100
					}
				]
			}
		]
	};

})();