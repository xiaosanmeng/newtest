(function() {
	'use strict';
	var pluginHost = null;
	var thePluginInstance = null;
	var kSelfId = "jp.ac.u-tokyo.g-takeout";
	
	// SETUP AND SHUTDOWN ---------------------------
	function loadPlugin(panelContainer) {
		thePluginInstance = mobmap.PluginUtil.activatePlugin(
			pluginHost,
			panelContainer,
			TakeoutImporter,
			thePluginInstance,
			0);
	}

	function unloadPlugin() {
		mobmap.PluginUtil.deactivatePlugin(thePluginInstance);
	}
	
	// -------------------------------
	function TakeoutImporter() {
		this.loader = null;
		this.destLayer = null;
		this.extraPropMap = {};
		
		this.element = this.createElementWithTitle('Timeline importer');
		this.jElement = $(this.element).addClass('gt-importer-plugin');

		this.idNumInput = null;
		this.fileFormContainer = null;
		this.fileInputElement = null;
		this.jFileInput = null;
		
		this.usageContainerElement = null;
		
		this.buildUI(this.element);
	}
	
	TakeoutImporter.prototype = {
		buildUI: function(containerElement) {
			this.usageContainerElement = this.generateUsage();
			containerElement.appendChild(this.usageContainerElement);
			
			var configContainer = document.createElement('div');
			configContainer.className = 'gt-importer-form-section';
			this.buildConfigForm(configContainer);
			containerElement.appendChild(configContainer);
			
			this.fileFormContainer = document.createElement('div');
			this.fileFormContainer.className = 'gt-importer-form-section';
			containerElement.appendChild( this.fileFormContainer );
			
			this.renewFileForm();
		},
		
		buildConfigForm: function(containerElement) {
			var lab = document.createElement('label');
			lab.innerHTML = 'Add ID ';
			
			var idNum = document.createElement('input');
			idNum.type = 'number';
			idNum.min  = 1;
			idNum.max  = 999999;
			idNum.step  = 1;
			idNum.value = 1;
			this.idNumInput = idNum;

			lab.appendChild(idNum);
			containerElement.appendChild(lab);
		},
		
		generateUsage: function() {
			var el = document.createElement('div');
			el.className = 'gt-importer-plugin-usage';
			
			el.innerHTML = 'Please export your location history using Google Takeout.<br>'+
			 'The file must be a <strong>ZIP</strong> which contains location history as <strong>JSON</strong>.';
			
			return el;
		},
		
		renewFileForm: function() {
			if (this.fileInputElement) {
				if (this.fileInputElement.parentNode) {
					this.fileInputElement.parentNode.removeChild( this.fileInputElement );
				}
				
				this.jFileInput.off();

				this.fileInputElement = null;
				this.jFileInput = null;
			}
			
			var input = document.createElement('input');
			input.type = 'file';
			
			this.fileFormContainer.appendChild(input);
			this.fileInputElement = input;
			this.jFileInput       = $(input);
			
			this.jFileInput.change( this.onFileSelect.bind(this) );
			return input;
		},
		
		clearExtraPropMap: function() {
			var m = this.extraPropMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				delete m[i];
			}
		},
		
		onFileSelect: function() {
			var f = this.fileInputElement.files[0];
			this.clearExtraPropMap();
			
			this.jFileInput.hide();
			this.loader = new GoogleTakeoutArchiveLoader(f, this.onZipContentLoad.bind(this));
			this.loader.read();
		},
		
		onZipContentLoad: function(content) {
			if (content && this.loader) {
				var parsedContent = this.loader.parse();
				this.createDestLayer();
				
				this.destLayer.setShortDescription("Google Takeout");
				this.destLayer.invalidateDateTimeRange();
				this.destLayer.ldFireWillStart();
				
				this.loader.startTransfer(
					this.onLoaderSentOne.bind(this),
					this.onLoaderFinished.bind(this)
				);
			} else {
				
			}
		},
		
		createDestLayer: function() {
			var app = pluginHost.getOwnerApp();
			this.destLayer = app.addNewMovingObjectLayer();
			
			return this.destLayer;
		},
		
		onLoaderSentOne: function(sourceEntry, progress) {
			var newRecord = mobmap.MovingData.createEmptyRecord();
			newRecord.id = this.getParamDummyId();
			newRecord.x = sourceEntry.longitude;
			newRecord.y = sourceEntry.latitude;
			newRecord.time = sourceEntry.timestamp;
						
			for (var i in sourceEntry) if ( sourceEntry.hasOwnProperty(i) ) {
				if (this.loader.isExtraMember(i)) {
					newRecord[i] = parseInt(sourceEntry[i], 10);
					this.extraPropMap[i] = 1;
				}
			}

			this.destLayer.ldAddRecord(newRecord);
			this.destLayer.csvloaderReportProgress(null, progress);
		},
		
		onLoaderFinished: function() {
			this.addExtraRecordAttributes();
			this.destLayer.ldFinish();
			console.log("+++ finish", this.extraPropMap);
			
			this.renewFileForm();
		},
		
		addExtraRecordAttributes: function() {
			var colIndex = 4;
			var m = this.extraPropMap;
			for (var i in m) if (m.hasOwnProperty(i)) {
				this.destLayer.addAttribute(i, AttributeType.INTEGER, colIndex);
				++colIndex;
			}
		},
		
		getParamDummyId: function() {
			return parseInt(this.idNumInput.value, 10);
		}
	};

	// -------------------------------------------------------------------------------------
	// inherit < < < <
	mobmap.PluginUtil.installBaseElementMethods(TakeoutImporter.prototype);

	var kPluginIconData = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUAQMAAAC3R49O'+
	 'AAAABlBMVEUAAAAAAAClZ7nPAAAAAXRSTlMAQObYZgAAAClJREFUCNdjQAaMPxgYmFggWP5/AxjLsTcwyPyH4sN'+
	 'A/BmEweJwNUgAAE1TEHs5kdBUAAAAAElFTkSuQmCC';

	pluginHost = mobmap.registerPlugin({
		"id": kSelfId,
		"title": "Timeline importer",
		"category": mobmap.PluginTypes.AnalysisPanel,
		"tool-icon": kPluginIconData,
		"load": loadPlugin,
		"unload": unloadPlugin,
		"stylesheets": ['g-takeout.css'],
		"scripts": ["jszip.js", "gt-loader.js"]
	});

})();