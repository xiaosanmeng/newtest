(function() {
	'use strict';

	function GoogleTakeoutArchiveLoader(inFile, callback) {
		this.callback = callback;
		this.sendFuncs = {
			sendOne: null,
			finish: null
		};
		
		this.inputFile = inFile;
		this.z = new JSZip();
		this.candList = [];
		
		this.extractedContent = null;
		this.parsedContent = null;
		
		this.sentCount = 0;
		this.tx_closure = this.asyncSend.bind(this);
	}
	
	GoogleTakeoutArchiveLoader.prototype = {
		read: function() {
			this.z.loadAsync(this.inputFile).then(
				this.afterZipLoad.bind(this)
			);
		},
		
		afterZipLoad: function() {
			this.findLocFile();
		},
		
		findLocFile: function() {
			var clist = this.candList;
			
			this.z.forEach(function(relPath, zipObject) {
				var re = /\.json$/;
				if (re.test(relPath)) {
					clist.push(zipObject);
				}
			});
			
			this.checkNextFile();
		},
		
		checkNextFile: function() {
			var clist = this.candList;
			if (clist.length < 1) {
				if (this.callback) {
					// FAIL
					this.callback(null);
				}
				
				return;
			}
			
			var zipObject = clist.pop();
			zipObject.async('text').then( this.onExtracted.bind(this) );
		},
		
		onExtracted: function(content) {
			if (this.isValidContent(content)) {
				this.extractedContent = content;
				
				if (this.callback) {
					// SUCCESS
					this.callback(content);
				}

			} else {
				this.checkNextFile();
			}
		},
		
		isValidContent: function(text) {
			return text.indexOf('latitude') >= 0 && text.indexOf('longitude');
		},
		
		parse: function() {
			if (this.extractedContent) {
				this.parsedContent = JSON.parse( this.extractedContent );
			}
			
			this.generateFloatLatLng( this.parsedContent.locations );
			return this.parsedContent;
		},
		
		generateFloatLatLng: function(locList) {
			var n = locList.length;
			for (var i = 0;i < n;++i) {
				var entry = locList[i];
				this.scanProperties(entry);
			}
		},
		
		scanProperties: function(o) {
			var e = 1;
			var reX = /longitudeE([0-9]+)/ ;
			var reY = /latitudeE([0-9]+)/ ;
			for (var i in o) if (o.hasOwnProperty(i)) {
				if (reX.test(i)) {
					e = parseInt(RegExp['$1'], 10);
					o.longitude = this.expToFloat(o[i], e);
				} else if (reY.test(i)) {
					e = parseInt(RegExp['$1'], 10);
					o.latitude = this.expToFloat(o[i], e);
				}
			}
			
			if (o.timestampMs) {
				o.timestamp = Math.floor(parseFloat(o.timestampMs) / 1000.0);
			}
		},

		isExtraMember: function(name) {
			if ( name.indexOf('latitude') === 0 ||
			     name.indexOf('longitude') === 0 ||
			     name.indexOf('timestamp') === 0) {
				return false;
			}
			
			return true;
		},

		expToFloat: function(raw, e) {
			return raw / Math.pow(10, e);
		},
		
		startTransfer: function(oneFunc, finishFunc) {
			this.sentCount = 0;
			this.sendFuncs.sendOne = oneFunc;
			this.sendFuncs.finish = finishFunc;
			this.asyncSend();
		},
		
		asyncSend: function() {
			var remain = true;
			for (var i = 0;i < 80;++i) {
				if ( !this.sendIfRemain() ) {
					remain = false;
					break;
				}
			}

			if (remain) {
				setTimeout(this.tx_closure, 1);
			}
		},
		
		sendIfRemain: function() {
			var ls = this.parsedContent.locations;
			var i = this.sentCount;
			
			if (i >= ls.length) {
				if (this.sendFuncs.finish) {
					this.sendFuncs.finish();
				}
				return false;
			} else {
				if (this.sendFuncs.sendOne) {
					this.sendFuncs.sendOne( ls[i] , i/ls.length );
				}
				
				++this.sentCount;
				return true;
			}
		}
	};
	
	window.GoogleTakeoutArchiveLoader = GoogleTakeoutArchiveLoader;
})();